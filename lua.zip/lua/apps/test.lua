--[[
tmp = 'kostas nikos'
gg = '%w+'
tmp1 = ''
for i = 1, 3 do
    tmp1 = tmp1 .. gg 
end
tmp = string.match(tmp, tmp1, 1)

print(tmp)
--]]
--[[
local  ff = {data = {kostas = 5}}

function ff:new()
local proxy = {}

setmetatable(proxy, {
    __index = self,
})

return proxy
end

function ff:add(t, v)
    self.data.kostas = self.data.kostas + v
end

function ff:getKostas()
    return self.data.kostas
end

local testme = ff:new()
testme:add(testme, 1)
print(testme:getKostas())
--]]

local AccountProxy = {}

-- Internal table mapping proxies to actual Account tables
local accounts = {}

function AccountProxy:new()
 local proxy = {}
 local account = {balance = 0}
 accounts[proxy] = account

 setmetatable(proxy, {   
    __index = self,
 })

 return proxy
end

function AccountProxy:withdraw(v)
   accounts[self].balance = (accounts[self].balance or 0) - v
end

function AccountProxy:deposit(v)    
    accounts[self].balance = (accounts[self].balance or 0) + v     
end

function AccountProxy:getBalance()
   return accounts[self].balance or 0
end

-- Example usage
local acc_1 = AccountProxy:new() -- acc_1 is the proxy
 
acc_1:deposit(100.0) 
print(acc_1:getBalance())  -- 100.0
acc_1:withdraw(50.0)
print(acc_1:getBalance())  -- 50.0


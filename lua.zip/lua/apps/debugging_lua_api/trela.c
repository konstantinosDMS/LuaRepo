#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

int main(void) {
    lua_State *L = luaL_newstate();
    if (L == NULL) {
        fprintf(stderr, "Failed to create Lua state\n");
        return 1;
    }

    luaL_openlibs(L);

    // Step 2: Load the Lua file
    if (luaL_dofile(L, "test_lua_trela.lua") != LUA_OK) {
        fprintf(stderr, "Error loading Lua file: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return 1;
    }

    lua_getglobal(L, "ggg");

    lua_Debug ar;
    if (lua_getstack(L, 0, &ar) != LUA_OK) {
        fprintf(stderr, "Error getting stack: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return 1;       
    }                   
    
    lua_pushstring(L, "local x = 10");

    lua_pcall(L, 1,0,0);
    

    printf("Result: %lld\n", lua_tointeger(L, -1));



    // Close Lua state
    lua_close(L);
    return 0;
}

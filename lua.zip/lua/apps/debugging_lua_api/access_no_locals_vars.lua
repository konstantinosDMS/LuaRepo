function getvarvalue (name, level, isenv)
	local value
	local found = false
	level = (level or 1) + 1

	for i = 1, math.huge do
		local n, v = debug.getlocal(level, i)
		if not n then break end
		if n == name then
			value = v
			found = true
		end
	end

	if found then return "local", name, value end -- try non-local variables
	local func = debug.getinfo(level, "f").func -- upvalues from the _ENV environment
	for i = 1, math.huge do
		local n, v = debug.getupvalue(func, i)
		if not n then break end
		if n == name then return "upvalue", name, v; end
	end

	if isenv then return "noenv", nil, nil; end -- if not upvalues, or local vars and isenv = true then return to avoid _ENV._ENV._ENV ... recursion

	-- avoid loop
	-- not found; get value from the environment
	local _, name_1, env = getvarvalue("_ENV", level, true)
	if env then
		return "global", env[name], nil
	else -- no _ENV available
		return "noenv", nil, nil
	end
end


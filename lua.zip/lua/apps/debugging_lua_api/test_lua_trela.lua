function ggg()
    print(x)
    return x
end

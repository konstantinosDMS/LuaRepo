function foo (a, b)
	local c = a + b
    print(c)
    return c 
end
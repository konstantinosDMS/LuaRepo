#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "luaconf.h"

/**
void debug_local_vars(lua_State *L, char *filename) {
    int res;

    res = luaL_loadfile(L, filename);
    if (res != LUA_OK) luaL_error(L, "cannot load %s: %s", filename, lua_tostring(L, -1));

    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));   
    
    int a = 5, b = 3;
    lua_getglobal(L, "foo");
    lua_pushinteger(L, a);
    lua_pushinteger(L, b);

    res = lua_pcall(L, 2, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));
}

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    debug_local_vars(L, "access_local_vars.lua");

    lua_close(L);
    return 0;
}
**/

/**
static void stackDump (lua_State *L) {
    int i;
    int top = lua_gettop(L); // depth of the stack 
    for (i = 1; i <= top; i++) { // repeat for each level 
        int t = lua_type(L, i);
        switch (t) {
            case LUA_TSTRING: { // strings 
                printf("LUA_TSTRING: '%s'", lua_tostring(L, i));
                break;
            }
            case LUA_TBOOLEAN: { // Booleans 
                printf("LUA_TBOOLEAN: %s", (lua_toboolean(L, i) ? "true" : "false"));
                break;
           }
            case LUA_TNUMBER: { // numbers
                if (lua_isinteger(L, i)){ 
                    printf("LUA_TNUMBER INTEGER: %lld", lua_tointeger(L, i));
                    break;
                }
                printf("LUA_TNUMBER FLOAT: %g", lua_tonumber(L, i));
                break;
            }
            default: { // other values 
                printf("Default Case: %s", lua_typename(L, t));
                break;
            }
        }   
        printf(" "); // put a separator 
    }
    printf("\n"); // end the listing 
}

void debug_local_vars(lua_State *L, char *filename) {

    //Need to debug the stack values
    int res;

    res = luaL_loadfile(L, filename);
    if (res != LUA_OK) luaL_error(L, "cannot load %s: %s", filename, lua_tostring(L, -1));

    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));   
    
    int a = 5, b = 3;
    lua_getglobal(L, "foo");
    lua_pushinteger(L, a);
    lua_pushinteger(L, b);

    stackDump(L);

    res = lua_pcall(L, 2, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));
}

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    debug_local_vars(L, "access_local_vars_1.lua");

    lua_close(L);
    return 0;
}
*/

int main() {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    // Load and execute the Lua script
    const char *luaScript = "local x = 5; print(x); return x;";
    int res = luaL_dostring(L, luaScript);
    if (res != LUA_OK) {
        printf("Error executing Lua script: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return 1;
    }

    // Load the getvarvalue function
    res = luaL_loadfile(L, "access_no_locals_vars.lua"); // Assuming getvarvalue.lua contains the function definition
    if (res != LUA_OK) {
        printf("Error loading getvarvalue.lua: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return 1;
    }
    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) {
        printf("Error executing getvarvalue.lua: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return 1;
    }

    res = luaL_dostring(L, "x = 15;");
    if (res != LUA_OK) {
        luaL_error(L, "error while loading string x!");
        lua_close(L);
        return 0;
    }

    lua_pop(L, 1);
    // Call the getvarvalue function with the desired variable name and level
    
    lua_getglobal(L, "getvarvalue");
    lua_pushstring(L, "x"); // Variable name
    lua_pushinteger(L, 0); // Level (assuming the script was executed in a function)
    lua_pushboolean(L, 0); // isenv (false)
    res = lua_pcall(L, 3, 3, 0);
    if (res != LUA_OK) {
        printf("Error calling getvarvalue: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return 1;
    }

    // Handle the returned values
    const char *type = lua_tostring(L, -3);
    
    if (type) {
        printf("type: %s, name: %s, value: %s\n", type, lua_tostring(L, -2), lua_tostring(L, -1));
    } else {
        printf("Error getting variable type\n");
    }

    lua_close(L);
    return 0;
}

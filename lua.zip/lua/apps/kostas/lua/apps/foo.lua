local f = {}

function foo(x)
    print(x)
end

return { foo = foo }
function foo(x)
   print(x)
end
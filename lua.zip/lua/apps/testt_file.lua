local f = function(str, t, n)
    print(str)
    print(t)
    print(n)
end

t = {}
t.x = 155

a = f("how", t.x, 14);


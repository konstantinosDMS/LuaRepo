#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

/**
int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    int ff = luaL_loadfile(L, "extend_ur_app_utility_1.lua");
    if (ff == LUA_OK) {
        int gg = lua_pcall(L, 0, LUA_MULTRET, 0); // Execute Lua code
        if (gg == LUA_OK){
            printf("ok\n");

            lua_getglobal(L, "prprpr"); // Push the function onto the Lua stack
            if (lua_isfunction(L, -1)) { // Check if the top of the stack is a function
                int call_result = lua_pcall(L, 0, 1, 0); // Call the function with 0 arguments
                if (call_result == LUA_OK) {
                    if (!lua_isboolean(L, -1)) {
                        printf("Return value is not a boolean\n");
                    } else {
                        int kk = lua_toboolean(L, -1); // Retrieve boolean value
                        printf("%d\n", kk);
                    }
                } else {
                    printf("Error calling Lua function\n");
                }
            } else {
                printf("Function 'prprpr' not found in Lua script\n");
            }
        } else {
            printf("not ok\n");
        }
    } else {
        lua_error(L);
    }

    lua_close(L);
    return 0;
}
**/

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    /**
    const char *my_key;
    lua_newtable(L); // Create a new Lua table to represent the environment
    //printf("%s\n", lua_typename(L, 1));
    //printf("%d\n", lua_toboolean(L, 1));
    lua_pushstring(L, "value_1"); // Push a string onto the stack
    //printf("%s\n", lua_tostring(L, -1));
    lua_setfield(L, -2, "key_1"); // Set the field "key_1" in the table to the string "value_1"
    //printf("%s\n", lua_tostring(L, -1));

    // Retrieve the value associated with "key_1" from the table and store it in the variable my_key
    int dds = lua_getfield(L, -1, "key_1");
    //printf("%d\n", dds);
    if (dds == LUA_INT_TYPE) printf("ffffffffff\n");
    my_key = lua_tostring(L, -1); // Convert the Lua value to a C string
    printf("%s\n", my_key); // Print the value

    // Pop the value from the stack
    lua_pop(L, 1);
    **/

   int tload1 = luaL_dofile(L, "window.lua");
   if (tload1 == LUA_OK) { 
        //printf("%d\n", lua_gettop(L));
        //lua_pcall(L, 0, 0, 0);   
        //lua_pushstring(L, "width");
        //printf("asasasasasasa %lld\n", lua_tointegerx(L, -1, NULL));
   }


    int tload = luaL_loadfile(L, "extend_ur_app_utility_1.lua");
    if (tload == LUA_OK) {
        lua_pushstring(L, "width");
        int ppcall = lua_pcall(L, 1, 1, 0);
        if (ppcall == LUA_OK) {
            //printf("%d\n", lua_gettop(L));
            //printf("%d\n", lua_toboolean(L, -1));
            lua_getglobal(L, "checkEnv");
            lua_pushstring(L, "width");
            lua_pcall(L, 1, 1, 0);
            //printf("%d\n", lua_gettop(L));
            printf("%d\n", lua_toboolean(L, -1));
        }
        //printf("%s\n", lua_tostring(L, -1));
        lua_pop(L, 1);
    } else lua_error(L);

    lua_close(L);
    return 0;
}
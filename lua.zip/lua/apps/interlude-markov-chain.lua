local nn = 3
local MAXGEN = 200
local NOWORD = "\n" -- build table
local w1, w2 = '', NOWORD  -- w1 = '\n', w2 = '\n'
local statetab = {}
local fillTheWord
local ptrn = ''
local wrd = '%w+'

function allwords ()
    local line = io.read() -- current line
    local pos = 1 -- current position in the line
    return function () -- iterator function
        while line do -- repeat while there are lines
        local w, e = string.match(line, "(%w+[,;.:]?)()", pos) 
        if w then -- found a word?
            pos = e -- update next position
            return w -- return the word
        else
            return nil
        end
    end
    return nil -- no more lines: end of traversal
    end
end

function prefix (w1, w2)
    return w1 .. ' ' .. w2
end

function insert (prefix, value)
    local list = statetab[prefix]
    if list == nil then
        statetab[prefix] = {value}
    else
        list[#list + 1] = value
    end
end

fillTheWord = function(word, nn)
    for i = 1, nn - 1 do
        if word == '' then 
             if i ~= nn -1 then word = word .. NOWORD .. ' '
            else word = word .. NOWORD end
        else 
            if i ~= nn -1 then word = word .. ' ' .. NOWORD .. ' '
            else word = word .. NOWORD end     
        end
    end    
    return word
end

w1 = fillTheWord(w1, nn)

for nextword in allwords() do
    if nextword == nil then break end
    local tmp = prefix(w1, w2) 
    insert(tmp, nextword)
    
    local the_start, the_end = string.find(tmp, "(\n%s)", 1)
    if (the_end ~= nil and the_start ~= nil) then
        tmp = string.sub(tmp, the_end + 1, #tmp)
    else
        the_start, the_end = string.find(tmp, "%w+", 1)
        if the_start ~= nil and the_end ~= nil then
            tmp = string.sub(tmp, the_end + 2, #tmp)
        end
    end
    w1 = tmp w2 = nextword
end

insert(prefix(w1, w2), NOWORD) -- generate text
w1 = ''; w2 = NOWORD -- reinitialize
local flg = false

for i = 1, MAXGEN do
    if not flg then w1 = fillTheWord(w1, 3) flg = true end
    prfx = prefix(w1, w2)
    local list = statetab[prfx] -- choose a random item from list
    local r = math.random(#list)
    local nextword = list[r]
    if nextword == NOWORD then return end
    io.write(nextword, " ")
    w1 = w2; w2 = nextword
end

#include <stdio.h>
#include <string.h>

int main()
{
	char *tp = "kostas";
	if (strcmp(tp, "kostas")==0) printf("fffffff");
	return 0;
} 

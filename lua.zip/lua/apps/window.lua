-- define window size
width = 200
height = 300
background_red = 110
background_green = 120
background_blue = 0
BLUE = {red = 0, green = 0, blue = 1.0}
RED = {red = 1.0, green = 0, blue = 0}
GREEN = {red = 0, green = 1.0, blue = 0}
background = BLUE
--background = "WHITE"
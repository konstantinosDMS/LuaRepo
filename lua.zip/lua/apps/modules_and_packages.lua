--[[
local m = require "math"
print(m.sin(3.14)) --> 0.0015926529164868
--]]

--[[ already called from withing standard lua 
math = require "math"
string = require "string"
--]]

--[[
local mod = require "mod"
mod.foo()

local m = require "mod"
local f = m.foo
f()

local f = require "mod".foo -- (require("mod")).foo
f()
--]]

--[[
-- All expressions are equivalent --
local m = require('math')
local modname = 'math'
local m = require(modname)
--]]
--[==[
--Figure 17.1. A homemade package.searchpath
function search (modname, path)
    modname = string.gsub(modname, "%.", "/")
    local msg = {}
    for c in string.gmatch(path, "[^;]+") do
        local fname = string.gsub(c, "?", modname)
        local f = io.open(fname)
        if f then
            f:close()
            return fname
        else
            msg[#msg + 1] = string.format("\n\tno file '%s'", fname);
        end
    end
    return nil, table.concat(msg) -- not found
end

print(search("kostas.lua", "/home/konstantinos/Downloads/lua/apps/?;"))
--]==]

--[[
local M = require ("module_complex_1")

local c1 = M.new(5, 3)
local c2 = M.new(3, 8) 
local c3 = M.add(c1, c2)
print(M.tostring(c3))

local c4 = M.add(M.i, c2)
print(M.tostring(c4))
--]]

--[[
local M = require('module_complex_2')
local c1 = M.new(1, 2)
local c2 = M.new(3, 4)
local c3 = M.add(c1, c2)
print(M.tostring(c3))
--]]
--[[
local M = require('module_complex_3')
local c1 = M.new(1, 2)
local c2 = M.new(3, 4)
local c3 = M.add(c1, c2)
print(M.tostring(c3))
--]]
--[[
-- Exercise 17.1 --
local deqm = require ('double_ended_queues_module')
local lst = deqm.listNew()

deqm.pushFirst(lst, 8)
deqm.toString(lst)
print("=============")
deqm.pushLast(lst, 9)
deqm.toString(lst)
print("=============")
deqm.popFirst(lst)
deqm.toString(lst)
print("=============")
deqm.popLast(lst)
deqm.toString(lst)
--]]

--[[ 
-- Exercise 17.2 --
local grm = require('geometric_region_module')

c1 = grm.disk(0, 0, 1)
grm.plot(grm.difference(c1, grm.translate(c1, 0.3, 0)), 500, 500)
--]]
--[===[
-- Exercise 17.3 --

local path = "/home/konstantinos/Downloads/lua/apps/kostas/lua/apps/?.lua"
local tmp = package.path
package.path = "/home/konstantinos/Downloads/lua/apps/kostas/lua/apps/foo.lua"
local libname = "foo"
local fullpath = path:gsub("?", libname)

local success, module = pcall(require, fullpath)

if success then
    print("Module loaded successfully")
else
    print("Error loading module:", module)
end

package.path = tmp
--]===]
--[[
if package.searchers then
    print("Inspecting package.searchers:")
    for _, searcher in ipairs(package.searchers) do
        -- print(tostring(searcher))
        local dbgInfo = debug.getinfo(searcher, "S")
        print(dbgInfo.source, dbgInfo.short_src, dbgInfo.what, dbgInfo.linedefined, dbgInfo.lastlinedefined)
    end
end
--]]
--[===[
-- Exercise 17.4 --
-- Custom searcher that searches for Lua files and C libraries
local custom_searcher = function(module_name)
    local lua_path = "./?.lua"
    local so_path = "./?.so;/usr/lib/lua5.2/?.so;/usr/share/lua5.2/?.lua;./?/?/?.lua"

    -- Attempt to find a Lua file
    local lua_file = package.searchpath(module_name, lua_path)
    if lua_file then
        return loadfile(lua_file)
    end

    -- Attempt to find a C library
    local so_file = package.searchpath(module_name, so_path)
    if so_file then
        local loader = package.loadlib(so_file, "luaopen_" .. module_name)
        if loader then
            return loader
        end
    end

    -- Module not found
    return nil
end

-- Insert the custom searcher at the beginning of package.searchers
table.insert(package.searchers, 1, custom_searcher)

-- Example usage
local success, module = pcall(require, "kostas.lua.apps.foo")

if success then
    print("Module loaded successfully")
else
    print("Error loading module:", module)
end

custom_searcher('kostas.lua.apps.foo')
--]===]
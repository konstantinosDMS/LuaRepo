function f(x)
    for i = 1, #x do
        x[i] = x[i] + 10
    end
    return x
end


-- Lua code in myscript.lua
my_userdata = { value = 42 }
    
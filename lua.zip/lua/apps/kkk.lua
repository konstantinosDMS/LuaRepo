for i = 274,352 do
	print('break ',i)
end

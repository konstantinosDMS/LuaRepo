local a = {1, 2}
local b = {1, 2, 3}

-- Check if a is a subset of b
if isSubset(a, b) then
    print("a is a subset of b")
else
    print("a is not a subset of b")
end

-- Check if b is a proper subset of a
if isProperSubset(b, a) then
    print("b is a proper subset of a")
else
    print("b is not a proper subset of a")
end

-- Helper functions
function isSubset(setA, setB)
    for _, element in ipairs(setA) do
        if not contains(setB, element) then
            return false
        end
    end
    return true
end

function isProperSubset(setA, setB)
    return isSubset(setA, setB) and not isSubset(setB, setA)
end

function contains(set, element)
    for _, value in ipairs(set) do
        if value == element then
            return true
        end
    end
    return false
end

for i = 1,1000,1 do
	print('fffff')
end

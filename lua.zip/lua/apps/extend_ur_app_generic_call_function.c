#include <stdarg.h>
#include <string.h>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

void call_va (lua_State *L, const char *func, const char *sig, ...) {
    va_list vl;
    int narg, nres; /* number of arguments and results */
    va_start(vl, sig);
    lua_getglobal(L, func); /* push function */
    nres = strlen(sig); /* number of expected results */
    if (lua_pcall(L, narg, nres, 0) != 0) /* do the call */
        luaL_error(L, "error calling '%s': %s", func, lua_tostring(L, -1));
    va_end(vl);
}

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);
    int x = 3;
    int y = 3;
    char z = 'k';
    call_va(L, "f", "dd>d", x, y, &z);
}
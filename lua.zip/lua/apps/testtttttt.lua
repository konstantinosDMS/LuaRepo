function a()
    print('aaa')
end

function b()
    print('bbb')
end

local validfunc = {}

function my_hook()
    local info = debug.getinfo(2, "fn")
    if validfunc[info.func] == nil then
        validfunc[info.func] = true
    end
    -- print(info.name)
end

debug.sethook( my_hook, "c")
a()
b()
debug.sethook()

for k, v in pairs(validfunc) do
    print(k, v)
end




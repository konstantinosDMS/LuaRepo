--[[
a = {}
mt = {__mode = "k"}
setmetatable(a, mt)
key = {}
a[key] = 1
key = {}
a[key] = 2
collectgarbage()
for k, v in pairs(a) do
    print(k, v)
end
--]]
--[[
local results = {}
setmetatable(results, {__mode = "kv"})

function mem_loadstring (s)
    local res = results[s]
    if res == nil then
        res = assert(load(s))
        results[s] = res
    end
    return res
end
--]]
--[[
local results = {}
setmetatable(results, {__mode = "v"}) -- make values weak
function createRGB (r, g, b)
    local key = string.format("%d-%d-%d", r, g, b)
    local color = results[key]
    
    if color == nil then
        color = {red = r, green = g, blue = b}
        results[key] = color
    end 
    return color
end
--]]
--[===[
--[[
Given these two implementations for default values, which is best? As usual, it depends. Both have similar
complexity and similar performance. The first implementation needs a few memory words for each table
with a default value (an entry in defaults). The second implementation needs a few dozen memory
words for each distinct default value (a new table, a new closure, plus an entry in the table metas). So, if
your application has thousands of tables with a few distinct default values, the second implementation is
clearly superior. On the other hand, if few tables share common defaults, then you should favor the first
implementation.
--]]
local defaults = {}
setmetatable(defaults, {__mode = "k"})
local mt = {__index = function (t) return defaults[t] end}
function setDefault (t, d)
    defaults[t] = d
    setmetatable(t, mt)
end

local metas = {}
setmetatable(metas, {__mode = "v"})
function setDefault (t, d)
    local mt = metas[d]
    if mt == nil then
        mt = {__index = function () return d end}
        metas[d] = mt
        -- memorize
    end
    setmetatable(t, mt)
end
--]===]

-- A tricky situation occurs when, in a table with weak keys, a value refers to its own key.
-- The reference to v is only strong if there is some other external reference to k. Otherwise, 
-- the collector will eventually collect k and remove the entry from the table, even if v refers 
-- (directly or indirectly) to k.
--[[
do
    local mem = {}
    -- memorization table
    setmetatable(mem, {__mode = "k"})
    function factory (o)
        local res = mem[o]
        if not res then
            res = (function () return o end)
            mem[o] = res
        end
        return res
    end
end
--]]
--[[
o = {x = "hi"} --> hi
setmetatable(o, {__gc = function (o) print(o.x) end})
o = nil
collectgarbage()
--]]
--[[
o = {x = "hi"}
mt = {}
setmetatable(o, mt)
mt.__gc = function (o) print(o.x) end
o = nil
collectgarbage() --> (prints nothing)
--]]
--[[
o = {x = "hi"}
mt = {__gc = true}
setmetatable(o, mt)
mt.__gc = function (o) print(o.x) end
o = nil
collectgarbage() --> hi
--]]

--[===[
mt = {__gc = function (o) print(o[1]) end}
list = nil

for i = 1, 3 do
    list = setmetatable({i, link = list}, mt)
end

list = nil
collectgarbage()
--> 3
--> 2
--> 1
--]===]
--[[
local t = {__gc = function ()
        -- your 'atexit' code comes here
        print("finishing Lua program")
    end}
setmetatable(t, t)
_G["*AA*"] = t
--]]
--[[
do
local mt = {__gc = function (o)
            -- whatever you want to do
            print("new cycle")
            -- creates new object for next cycle
            setmetatable({}, getmetatable(o))
           end}
-- creates first object
setmetatable({}, mt)
end

collectgarbage() --> new cycle
collectgarbage() --> new cycle
collectgarbage() --> new cycle
--]]
--[===[
-- Exercise 23.1 --
do
    local mem = {}
    -- memorization table
    setmetatable(mem, {__mode = "k"})
    function factory (o)
        local res = mem[o]
        if not res then
            res = (function () return o end)
            mem[o] = res
        end
        return res
    end


    local fact = factory{}
    fact = factory{}
    -- fact = nil
    collectgarbage()

    for _,v in pairs(mem) do
        print(v)
    end
end
--]===]
-- Exercise 23.2 -- 
--[[: Consider the first example of the section called “Finalizers”, which creates a table with a
finalizer that only prints a message when activated. What happens if the program ends without a collection
cycle? What happens if the program calls os.exit? What happens if the program ends with an error?

The collector starts the mark phase by marking as alive its root set, which comprises the objects that Lua
has direct access to. In Lua, this set is only the C registry. (As we will see in the section called “The
registry”, both the main thread and the global environment are predefined entries in this registry.)
Any object stored in a live object is reachable by the program, and therefore is marked as alive too. (Of
course, entries in weak tables do not follow this rule.) The mark phase ends when all reachable objects
are marked as alive.
Before starting the sweep phase, Lua performs the cleaning phase, where it handles finalizers and weak
tables. First, it traverses all objects marked for finalization looking for non-marked objects. Those objects
are marked as alive (resurrected) and put in a separate list, to be used in the finalization phase. Then,
Lua traverses its weak tables and removes from them all entries wherein either the key or the value is
not marked.
The sweep phase traverses all Lua objects. (To allow this traversal, Lua keeps all objects it creates in a
linked list.) If an object is not marked as alive, Lua collects it. Otherwise, Lua clears its mark, in preparation
for the next cycle.
Finally, in the finalization phase, Lua calls the finalizers of the objects that were separated in the cleaning
phase.

In Lua, the garbage collector runs during the cleanup phase when the program ends. However, whether the finalizer of an object gets executed or not depends on various factors:

    Program Ends Without a Collection Cycle:
        If the program ends without triggering a garbage collection cycle, the finalizer for the object may not be executed.
        Lua's garbage collector is not guaranteed to run at the end of the program, but it often does during the cleanup phase.

    Program Calls os.exit:
        If the program calls os.exit, it terminates abruptly, and the finalizers may not be executed.
        os.exit is generally used to terminate the Lua program immediately without allowing it to go through the normal cleanup process.

    Program Ends With an Error:
        If the program ends with an error, Lua may still attempt to run finalizers during the garbage collection process.
        However, if an error occurs that prevents the normal cleanup (e.g., due to memory corruption or other severe issues), the finalizers may not run.
--]]
--[===[
Exercise 23.3: Imagine you have to implement a memorizing table for a function from strings to strings.
Making the table weak will not do the removal of entries, because weak tables do not consider strings as
collectable objects. How can you implement memorization in that case?

-- The main memorization table
local memoTable = setmetatable({}, { __mode = "v" })

-- The table to store weak references to string keys
local weakKeyTable = setmetatable({}, { __mode = "k" })

-- The memorizing function
function memoizeFunction(input)
    -- Check if the result is already memoized
    local result = memoTable[input]
    
    if not result then
        -- If not, calculate the result and store it
        result = expensiveCalculation(input)
        memoTable[input] = result
        
        -- Store a weak reference to the input string
        weakKeyTable[input] = true
    end
    
    return result
end

-- A sample expensive calculation function
function expensiveCalculation(input)
    -- Simulated expensive computation
    return "Result for " .. input
end

-- Example usage
print(memoizeFunction("input1"))  -- Expensive calculation
print(memoizeFunction("input1"))  -- Memoized result
-- memoTable["input1"] = nil

-- Trigger a garbage collection cycle to remove unreferenced strings
collectgarbage()

-- Check if the memoTable still contains entries
for k, v in pairs(memoTable) do
    print("MemoTable:", k, v)
end
--]===]
--[===[
-- Exercise 23.3 --
local count = 0
local mt = {__gc = function () count = count - 1 end}
local a = {}
for i = 1, 10000 do
    count = count + 1
    a[i] = setmetatable({}, mt)
end

collectgarbage()
print(collectgarbage("count") * 1024, count) -- memory used by lua, = 10000 bytes
a = nil
collectgarbage()
print(collectgarbage("count") * 1024, count) -- memory used ny lua, = 0
print(collectgarbage("count") * 1024, count) -- memory used ny lua, = 0
--]===]

-- Exercise 23.5 -- 
--[[ 
For this exercise, you need at least one Lua script that uses lots of memory. If you do not
    have one, write it. (It can be as simple as a loop creating tables.)
    • Run your script with different values for pause and stepmul. How they affect the performance and
    memory usage of the script? What happens if you set the pause to zero? What happens if you set the
    Garbage pause to 1000? What happens if you set the step multiplier to zero? What happens if you set the step
    multiplier to 1000000?
    • Adapt your script so that it keeps full control over the garbage collector. It should keep the collector
    stopped and call it from time to time to do some work. Can you improve the performance of your script
    with this approach?
    --]]

--[[
local a = {}

function fillMemory()
    local b = {}
    
    for i = 1, 1000000 do
        b[1] = i
        table.insert(a, b)
    end
end

fillMemory()

local a1 = collectgarbage("step", 0)
print(a1) -- true, Returns true if the step finished a collection cycle.

print(#a) --  1000000

a[1] = nil
a1 = collectgarbage("step", 0)
print(a1) -- false
print(#a) -- 1000000

In Lua, the collectgarbage("step", 0) function call with step equal to 0 is a manual step of the garbage collector, 
but it doesn't force a full garbage collection cycle. It only performs a single step of the garbage collector, and 
whether or not it finishes a collection cycle depends on the amount of garbage collected during that step.

When you set a[1] = nil, it doesn't immediately release the memory occupied by the table b associated with a[1]. The 
memory is marked as collectible, and it will be collected during subsequent garbage collection cycles.

In your code:

    fillMemory() creates a large table a with 1,000,000 references to the same table b.
    After the loop, a contains 1,000,000 references to the same table b.
    collectgarbage("step", 0) performs one step of garbage collection, and since the step finishes a collection cycle, it 
    returns true.
    #a still returns 1,000,000 because the memory associated with the table b is still marked as collectible but not yet 
    collected.

When you set a[1] = nil, it removes the reference to the table b from a[1], and during the subsequent garbage collection 
steps or cycles, the memory associated with the table b will be collected.

If you want to force an immediate garbage collection cycle and reclaim the memory associated with b, you can use:

collectgarbage("collect")

This will force a full garbage collection cycle and immediately reclaim the memory of collectible objects. After this call, 
#a would return 999,999 or a smaller number, depending on how much memory was successfully collected
--]]

-- ============================================================================================================ --
--[[
local a = {}

function fillMemory()
    local b = {}
    for i = 1, 1000000 do
        b[1] = i
        table.insert(a, b)
    end
end

fillMemory()
local a1 = collectgarbage("step", 0)
print(a1) -- true
print(#a) -- 1000000

a = nil 
print(collectgarbage("step", 0)) -- false
print(#a) --  attempt to get length of a nil value (local 'a')
--]]

-- ============================================================================================================ --
--[[
local results = {}
setmetatable(results, {__mode = "v"}) -- make values weak

function createRGB (r, g, b)
    local key = string.format("%d-%d-%d", r, g, b)
    local color = results[key]

    if color == nil then
        color = {red = r, green = g, blue = b}
        results[key] = color
    end 
    return color
end

local color1 = createRGB(1, 1, 1)
color1 = createRGB(1, 1, 1)

print(collectgarbage("step", 0)) -- false
cnt = 0
for k, v in pairs(results) do
    cnt = cnt + 1
end
print(cnt) -- 1

results[color1] = nil
print(collectgarbage("step", 0))
print(#results) -- 0
--]]
--[[
local results = {}
setmetatable(results, {__mode = "k"}) -- make values weak

function createRGB (r, g, b)
    local key = string.format("%d-%d-%d", r, g, b)
    local color = results[key]

    if color == nil then
        color = {red = r, green = g, blue = b}
        results[key] = color
    end 
    return color
end

local color1 = createRGB(1, 1, 1)
color1 = createRGB(1, 1, 1)

print(collectgarbage("step", 0)) -- false
cnt = 0
for k, v in pairs(results) do
    cnt = cnt + 1
end
print(cnt) -- 1

results["1-1-1"] = nil
print(collectgarbage("step", 0)) -- false
print(#results) -- 0
--]]
--[[
-- Lua script that uses lots of memory
local data = {}

for i = 1, 1000000 do
    data[i] = {1, 2, 3, 4, 5}
end

-- Disable automatic garbage collection
collectgarbage("stop")

for i = 1, 1000000 do
    data[i] = {1, 2, 3, 4, 5}
end

-- Perform explicit garbage collection periodically
for i = 1, 10 do
    collectgarbage("collect")
    -- Additional code that performs some operations
end

-- Re-enable automatic garbage collection
collectgarbage("restart")
--]]
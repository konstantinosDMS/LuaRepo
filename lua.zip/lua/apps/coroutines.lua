--[[
local co = coroutine.create(function() print('Hi') end)
print(coroutine.status(co)) -- suspended
coroutine.resume(co)
print(coroutine.status(co)) -- dead
--]]

--[[
-- A coroutine can be in one of four states: suspended, running, normal, and dead.

local co = coroutine.create(function()
    for i = 1, 10 do
        print('Co', i)
        coroutine.yield()
    end
end)

coroutine.resume(co) -- 1
coroutine.resume(co) -- 2
coroutine.resume(co) -- 3
coroutine.resume(co) -- 4
coroutine.resume(co) -- 5
coroutine.resume(co) -- 6
coroutine.resume(co) -- 7
coroutine.resume(co) -- 8
coroutine.resume(co) -- 9
coroutine.resume(co) -- 10
print(coroutine.resume(co)) -- true, (coroutine.resume(co) --> prints nothing)
print(coroutine.resume(co)) -- false
--]]

--[===[
--[[ Note that resume runs in protected mode, like pcall. Therefore, if there is any error inside a coroutine,
Lua will not show the error message, but instead will return it to the resume call. --]]

local co = coroutine.create(function ()
    print(1 + a)
end)

-- print(coroutine.resume(co)) -- attempt to perform arithmetic on a nil value (global 'a')
local c = coroutine.resume(co)
print(c) -- false
--]===]

--[===[
--[[When a coroutine resumes another, it is not suspended; after all, we cannot resume it. However, it is not
running either, because the running coroutine is the other one. So, its own status is what we call the normal
state.--]]

local co2
local co1 = coroutine.create(function() 
    print('Co1')
    print(coroutine.status(co2)) -- normal
    coroutine.yield()
end)

co2 = coroutine.create(function()
    print('Co2')
    coroutine.resume(co1)
    print(coroutine.status(co1)) -- suspended
end)

coroutine.resume(co2)
--]===]

--[[
local co = coroutine.create(function(a, b, c)
    print('co', a, b, c + 2)
end)

coroutine.resume(co, 1, 2, 3)
--]]

--[[
local co = coroutine.create(function(a, b, c)
    while true do
        c = c + 2
        print('co', a, b, c)
        coroutine.yield()
    end
end)

coroutine.resume(co, 1 , 2, 3)
coroutine.resume(co, 4, 5, 6)
--]]

--[[
local co = coroutine.create(function(a, b, c)
    while true do
        print('co', a, b, c)
        coroutine.yield()
        -- print('co', a, b, c + 2)
    end
end)

for i = 1, 10 do
    coroutine.resume(co, 1, 2, i) -- co      1       2       5
end
--]]

--[[
local co = coroutine.create(function(a, b) 
    coroutine.yield(a + b, a - b)
end)

print(coroutine.resume(co, 1, 2)) -- true   3       -1
--]]

--[[
    local co = coroutine.create(function(x) 
    print('co', x)
    print('co', coroutine.yield())
end)

coroutine.resume(co, 'hi') -- co      hi
coroutine.resume(co, 1, 2) -- co      1       2
--]]

--[[
local co = coroutine.create(function(a, b) 
    return a + b
end)

print(coroutine.resume(co, 1, 2)) -- true    3
--]]

--[[
Although the general concept of coroutines is well understood, the details vary considerably. 
So, for those that already know something about coroutines, it is important to clarify these 
details before we go on. Lua offers what we call asymmetric coroutines. This means that it has 
a function to suspend the execution of a coroutine and a different function to resume a 
suspended coroutine. Some other languages offer symmetric coroutines, where there is only one 
function to transfer control from one coroutine to another. Some people call asymmetric 
coroutines semi-coroutines. However, other people use the same term semi-coroutine to denote a 
restricted implementation of coroutines, where a coroutine can suspend its exe-
cution only when it is not calling any function, that is, when it has no pending calls in its 
control stack. In other words, only the main body of such semi-coroutines can yield. (A generator 
in Python is an example of this meaning of semi-coroutines.)
Unlike the difference between symmetric and asymmetric coroutines, the difference between coroutines
and generators (as presented in Python) is a deep one; generators are simply not powerful enough to im-
plement some of the most interesting constructions that we can write with full coroutines. Lua offers full,
asymmetric coroutines. Those that prefer symmetric coroutines can implement them on top of the asym-
metric facilities of Lua (see Exercise 24.6).    
--]]

--[[
function someFunction() 
   return coroutine.yield()
end

-- Define a semi-coroutine
local semiCoroutine = coroutine.create(function()
    print("Start of semi-coroutine")
    
    -- Attempting to yield within a function call, which is not allowed
    someFunction()
     
    coroutine.yield() -- This line will result in an error

    print("End of semi-coroutine")
end)

-- Attempting to resume the semi-coroutine
local success, errorMessage = coroutine.resume(semiCoroutine)

if not success then
    print("Error:", errorMessage)
end

local success, errorMessage = coroutine.resume(semiCoroutine)

if not success then
    print("Error:", errorMessage)
end

local success, errorMessage = coroutine.resume(semiCoroutine)
--]]
--[===[
function someFunction()
    coroutine.yield()
end

local semiCoroutine = coroutine.wrap(function()
    print("Start of semi-coroutine")
    
    -- Attempting to yield within a function call
    someFunction()

    -- This line will not result in an error because it's yielding from the main body
    coroutine.yield()

    print("End of semi-coroutine")
end)

semiCoroutine()  -- Start the semi-coroutine
semiCoroutine()  -- Start the semi-coroutine
semiCoroutine()  -- Start the semi-coroutine
--]===]

--[[
-- Define a semi-coroutine
local semiCoroutine = coroutine.create(function()
    print("Start of semi-coroutine")
    
    -- Attempting to yield within a function call, which is not allowed
    local functionCallResult = function()
        coroutine.yield() -- This line will result in an error
        print("End of semi-coroutine")
    end

    -- Calling the function that attempts to yield
    functionCallResult()
end)

-- Attempting to resume the semi-coroutine
local success, errorMessage = coroutine.resume(semiCoroutine)

if not success then
    print("Error:", errorMessage)
end

local success, errorMessage = coroutine.resume(semiCoroutine)

if not success then
    print("Error:", errorMessage)
end
--]]

--[===[
-- Producer, Consumer Problem --
function send(cons, x) 
    coroutine.yield(x)
end

function recieve(prod) 
    local _,val = coroutine.resume(prod)
    return val
end

function producer (cons)
  return coroutine.create(function()
    local x = io.read()
    send(cons, x)
  end)
end

-- produce new value
-- send it to consumer
function consumer ()
    while true do
       local x = recieve(producer()) -- receive value from producer
       io.write(x, "\n") -- consume it
    end   
end

coroutine.resume(producer(consumer()))
--]===]

--[===[
function consumer(prod)
    while true do
        local x = receive(prod)
        print(x)
    end
end

function receive(prod)
    local status, value = coroutine.resume(prod)
    return value
end

function send(x)
    coroutine.yield(x) -- go back to where resumed
end

function producer()
	return coroutine.create(function()
		while true do
			local x = io.read()
			send(x)
		end
	end)
end

-- consumer-driven design
consumer(producer())
--]===]
--[===[ -- Exercise 24.1 --
function send(cons, x)
    local _, value = coroutine.resume(cons, x)
    return value
end

function recieve(x)
   return coroutine.yield(x)
end

function producer(cons)
    while true do
        local x = io.read()
        send(cons, x)
    end 
end

function consumer()
    return coroutine.create(function(x)   
        while true do
            io.write(x, '\n')
            x = recieve(x)
        end
    end)
end

producer(consumer())
--]==]
--[===[
local co2
local co1 = coroutine.create(function ()
    while true do
        print(coroutine.status(co2))
        print('co1')
        coroutine.resume(co2)
    end
end)

co2 = coroutine.create(function ()
    while true do
        print(coroutine.status(co1))
        print('co2')
        coroutine.resume(co1)
    end
end)

coroutine.resume(co1)
--]===]

--[[
function producer ()
    while true do
        local x = io.read()
        send(x)
    end
end
    -- produce new value
    -- send it to consumer
function consumer ()
    while true do
        local x = receive()
        io.write(x, "\n")
    end
end
--]]
--[===[
     -- For this particular example, it is easy to change the structure of one of the functions, 
     -- unrolling its loop and making it a passive agent.

function recieve(prod, x)
    local _, val = coroutine.resume(prod, x)
    return val
end

function send(x)
    while true do 
        coroutine.yield(x)
    end
end

-- Define the main coroutine
local mainCoroutine = coroutine.create(function()
    while true do
        local x = io.read()
        producerCoroutine = coroutine.create(function()
            send(x)
        end)
        coroutine.resume(producerCoroutine)

        consumerCoroutine = coroutine.create(function()
            local y = recieve(producerCoroutine)
            io.write(y, "\n")
        end)
        coroutine.resume(consumerCoroutine)
    end
end)

-- Start the main coroutine
coroutine.resume(mainCoroutine)
--]===]

--[[
function recieve(prod, x)
    local _, val = coroutine.resume(prod, x)
    return val
end

function send(x)
    coroutine.yield(x)
end

function producer()
    return coroutine.create(function(a, b) 
        while true do
            local x = io.read()
            send(x)
        end
    end)
end

function consumer(prod)
    while true do
        local x = recieve(prod)
        io.write(x, '\n')
    end
end

coroutine.resume(consumer(producer()))
--]]

--[[
function receive (producer)
    local status, value = coroutine.resume(producer)
    return value
end

function send (x)
    coroutine.yield(x)
end

function producer ()
    while true do
        local x = io.read()
        send(x)
    end
end
    
function consumer (producer)
    while true do
        local x = receive(producer)
        io.write(x, "\n")
    end
end
  
producer = coroutine.create(producer)
coroutine.create(consumer(producer))
--]]

--[[
function receive (prod)
    local status, value = coroutine.resume(prod)
    return value
end

function send (x)
    coroutine.yield(x)
end

function producer ()
    return coroutine.create(function ()
        while true do
            local x = io.read()
            send(x)
        end
    end)
end

function filter (prod)
    return coroutine.create(function ()
        for line = 1, math.huge do
            local x = receive(prod)
            x = string.format("%5d %s", line, x)
            send(x)
        end
    end)
end

function consumer (prod)
    while true do
       local x = receive(prod)
        io.write(x, "\n")
    end
end

consumer(filter(producer()))
--]]

--[===[
-- Permutations --
function permgen (a, n)
    n = n or #a -- default for 'n' is size of 'a'
    if n <= 1 then
        -- nothing to change?
        printResult(a)
    else
        for i = 1, n do
            -- put i-th element as the last one
            a[n], a[i] = a[i], a[n]
            -- generate all permutations of the other elements
            permgen(a, n - 1)
            -- restore i-th element
            a[n], a[i] = a[i], a[n]
        end
    end
end

function printResult(a)
    for  i = 1, #a do
        io.write(a[i])
    end
    print('\n')
end

permgen({1, 2, 3, 4})

2341
3241
3421
4321
2431
4231
4312
3412
3142
1342
4132
1432
2413
4213
4123
1423
2143
1243
2314
3214
3124
1324
2134
1234
--]===]
--[[
function permgen (a, n)
    n = n or #a -- default for 'n' is size of 'a'
    if n <= 1 then
        -- nothing to change?
        coroutine.yield(a)
    else
        for i = 1, n do
            -- put i-th element as the last one
            a[n], a[i] = a[i], a[n]
            -- generate all permutations of the other elements
            permgen(a, n - 1)
            -- restore i-th element
            a[n], a[i] = a[i], a[n]
        end
    end
end

function printResult(a)
    for  i = 1, #a do
        io.write(a[i])
    end
    print('\n')
end

function permutations (a)
    local co = coroutine.create(function () permgen(a) end)
    return function ()
        -- iterator
        local code, res = coroutine.resume(co)
        return res
    end
end

for p in permutations{"a", "b", "c"} do
    printResult(p)
end
--]]

--[[
function permgen (a, n)
    n = n or #a -- default for 'n' is size of 'a'
    if n <= 1 then
        -- nothing to change?
        coroutine.yield(a)
    else
        for i = 1, n do
            -- put i-th element as the last one
            a[n], a[i] = a[i], a[n]
            -- generate all permutations of the other elements
            permgen(a, n - 1)
            -- restore i-th element
            a[n], a[i] = a[i], a[n]
        end
    end
end

function printResult(a)
    for  i = 1, #a do
        io.write(a[i])
    end
    print('\n')
end

function permutations (a)
  return coroutine.wrap(function() permgen(a)  end)
end

for p in permutations{"a", "b", "c"} do
    printResult(p)
end
--]]

--[[
lib.runloop();
lib.readline(stream, callback);
lib.writeline(stream, line, callback);
lib.stop();
--]]

--[===[
local cmdQueue = {} -- queue of pending operations

local lib = {}

function lib.readline (stream, callback)
    local nextCmd = function ()
        callback(stream:read())
    end
    table.insert(cmdQueue, nextCmd)
end

function lib.writeline (stream, line, callback)
    local nextCmd = function ()
        callback(stream:write(line))    
    end
    table.insert(cmdQueue, nextCmd)
end

function lib.stop ()
    table.insert(cmdQueue, "stop")
end

function lib.runloop ()
    while true do
        local nextCmd = table.remove(cmdQueue, 1)
        if nextCmd == "stop" then
            break
        else
            nextCmd() -- perform next operation
        end
    end
end

return lib
--]===]
--[===[
local t = {}
local inp = io.input() -- input stream
local out = io.output() -- output stream

for line in inp:lines() do
    t[#t + 1] = line
end

for i = #t, 1, -1 do
    out:write(t[i], "\n")
end
--]===]

--[===[
local t = {}
local inp = io.input()
-- input stream
local out = io.output()
-- output stream
for line in inp:lines() do
t[#t + 1] = line
end
for i = #t, 1, -1 do
out:write(t[i], "\n")
end

local lib = require "async-lib"
local t = {}
local inp = io.input()
local out = io.output()
local i
-- write-line handler
local function putline ()
	i = i - 1
	if i == 0 then -- no more lines?
		lib.stop() -- finish the main loop
	else -- write line and prepare next one
		lib.writeline(out, t[i] .. "\n", putline)
	end
end

-- read-line handler
local function getline (line)
	if line then
		t[#t + 1] = line
		lib.readline(inp, getline)
	else
		i = #t + 1
		putline()
	end
end-- not EOF?

-- save line
-- read next one
-- end of file
-- prepare write loop
-- enter write loop
lib.readline(inp, getline)
lib.runloop() -- ask to read first line
-- run the main loop
--]===]
--[===[
local lib = require "async-lib"
function run (code)
    local co = coroutine.wrap(function ()
    code()
    lib.stop() -- finish event loop when done
    end)
    co() -- start coroutine
    lib.runloop() -- start event loop
end

function putline (stream, line)
    local co = coroutine.running() -- calling coroutine
    local callback = (function () coroutine.resume(co) end)
    lib.writeline(stream, line, callback)
    coroutine.yield()
end

function getline (stream, line)
    local co = coroutine.running() -- calling coroutine
    local callback = (function (l) coroutine.resume(co, l) end)
    lib.readline(stream, callback)
    local line = coroutine.yield()
    return line
end

run(function ()
    local t = {}
    local inp = io.input()
    local out = io.output()
    while true do
        local line = getline(inp)
        if not line then break end
        t[#t + 1] = line
    end
    for i = #t, 1, -1 do
        putline(out, t[i] .. "\n")
    end
end)
--]===]

--[===[
-- Exercise 24.2 --

function combinations(arr, m, result, current, start)
    if m == 0 then
        printResult(current)
        return
    end

    for i = start, #arr - m + 1 do
        table.insert(current, arr[i])
        combinations(arr, m - 1, result, current, i + 1) 
        table.remove(current)
    end
end

function printResult(combination)
    for i = 1, #combination do
        io.write(combination[i])
    end
    print()
end

local arr = {"a", "b", "c", "d"}
local m = 2
local result = {}
combinations(arr, m, result, {}, 1)
--]===]
--[===[
function combinations(arr, m, result, current, start)
    if m == 0 then
        -- printResult(current)
        return coroutine.yield(current)
    end

    for i = start, #arr - m + 1 do
        table.insert(current, arr[i])
        combinations(arr, m - 1, result, current, i + 1)     
        table.remove(current)
    end
end 

function combinationss(arr, m, result, current, start)
    local co = coroutine.create(function(arr, m, result, current, start) combinations(arr, m, result, current, start) end)
    return function()
        local _, val = coroutine.resume(co, arr, m, result, current, start)
        return val
    end
end

for c in combinationss({"a", "b", "c"}, 2, {}, {}, 1) do
    for i = 1, #c do
        io.write(c[i])
    end
end
--]===]
--[===[
-- Exercise 24.3 --
local lib = require "async-lib"
function run (code)
    local co = coroutine.wrap(function ()
        code()
        lib.stop()
    end)
    co()
    lib.runloop()
end

local co 
co = coroutine.running()
local callback = (function () coroutine.resume(co) end)
function putline (stream, line)
    lib.writeline(stream, line, callback)
    coroutine.yield()
end

co = coroutine.running()
local callback = (function (l) coroutine.resume(co, l) end)
function getline (stream, line)
    lib.readline(stream, callback)
    local line = coroutine.yield()
    return line
end

run(function ()
        local t = {}
        local inp = io.input()
        local out = io.output()
        while true do
            local line = getline(inp)
            if not line then break end
            t[#t + 1] = line
        end
        for i = #t, 1, -1 do
            putline(out, t[i] .. "\n")
        end
end)
--]===]
--[===[
-- Exercise 24.4 --
local lib = require "async-lib"
function run (code)
    local co = coroutine.wrap(function ()
        code()
        lib.stop()
    end)
    co()
    lib.runloop()
end

function putline (stream, line)
    local co = coroutine.running()
    local callback = (function () coroutine.resume(co) end)
    lib.writeline(stream, line, callback)
    coroutine.yield()
end

function getline (stream, line)
    co = coroutine.running()
    local callback = (function (l) iter(stream); coroutine.resume(co, l) end)
    lib.readline(stream, callback)
    local line = coroutine.yield()
    return line
end

function iter(fp)
    return function(fp)
        for line in io.lines(fp) do
            return line
        end
    end
end

run(function ()
        local t = {}
        local fp = io.open('test.txt', 'r')
        local out = io.output()
        local inp = fp

        while true do
            local line = getline(inp)
            if not line then break end
            t[#t + 1] = line
        end
        for i = #t, 1, -1 do
            putline(out, t[i] .. "\n")
        end
end)
--]===]
--[===[
-- Exercise 24.5 --
local lib = require "async-lib"

local code = function ()
    local t = {}
    local inp = io.input()
    local out = io.output()
    while true do
        local line = getline(inp)
        if not line then break end
        t[#t + 1] = line
    end
    for i = #t, 1, -1 do
        putline(out, t[i] .. "\n")
    end
end

function run (code)
        local co = coroutine.wrap(function ()
            code()
            lib.stop()
        end)
    co()
    lib.runloop()
end

function putline (stream, line)
    local co = coroutine.running()
    local callback = (function () coroutine.resume(co) end)
    lib.writeline(stream, line, callback)
    run(code)
    coroutine.yield()
end

function getline (stream, line)
    co = coroutine.running()
    local callback = (function (l) coroutine.resume(co, l) end)
    lib.readline(stream, callback)
    local line = coroutine.yield()
    run(code)
    return line
end

run(code)
--]===]
--[===[
-- Exercise 24.6 --
local co

function transfer()
    return coroutine.create(function()
        print('aaa')
        coroutine.yield(co)
    end)
end

function dispatch()
    local co = transfer()
    coroutine.resume(co)
    dispatch()
end

transfer()
dispatch()
--]===]




local Set = {}
local mt = {}

-- Create a new set with the values of a given list
function Set.new(l)
    local set = {}
    setmetatable(set, mt)
    for _, v in ipairs(l) do set[#set + 1] = v end
    return set
end

function Set.union(a, b)
    if getmetatable(a) ~= mt or getmetatable(b) ~= mt then 
        error('attempt to \'add\' a set with a non-set value", 2')
    end
    local flg = false
    local res = Set.new{}
    for k, v in ipairs(a) do
        for p, t in pairs(res) do
            if t == v then flg = true end 
        end
        if flg == false then res[#res + 1] = v end
        flg = false
    end
    for k, v in ipairs(b) do
        for p, t in pairs(res) do
            if t == v then flg = true end 
        end
        if flg == false then res[#res + 1] = v end
        flg = false
    end  
    return res
end

function Set.intersection(a, b)
    local res = Set.new{}
    for k, v in ipairs(a) do
        for j, l in ipairs(b) do
            if v == l then res[#res + 1] = v end
        end
    end  
    return res
end

-- Present a set as a string
function Set.tostring(set)
    local l = {}
    for k, v in pairs(set) do
        l[#l + 1] = tostring(v)
    end
    return "{" .. table.concat(l, ", ") .. "}"
end

mt.__add = Set.union
mt.__mul = Set.intersection

mt.__le = function (a, b)
    -- subset
    for k in pairs(a) do
        if not b[k] then return false end
    end
    return true
end
    
mt.__lt = function (a, b)
    -- proper subset
    return a <= b and not (b <= a)
end

mt.__eq = function(a, b)
    return a <= b and b <= a
end

mt.__tostring = Set.tostring

-- mt.__metatable = 'not your business'

mt.__pairs = function (t)
                return function (_, k)
                    -- iteration function
                    local nextkey, nextvalue = next(t, k)
                    if nextkey ~= nil then
                        -- avoid last value
                        print("*traversing element " .. tostring(nextkey))
                    end
                    return nextkey, nextvalue
                end
            end

return Set

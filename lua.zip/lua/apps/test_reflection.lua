function test_reflection()
    s = "012345678901234567890123456789"
    for i = 1, 100000000 do
        s = s .. s
    end
end


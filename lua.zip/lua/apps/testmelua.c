#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"

int stackDump(lua_State *L) {
    int top = lua_gettop(L);
    for (int i = 1; i <= top; i++) {
        int type = lua_type(L, i);
        switch (type) {
            case LUA_TNUMBER:
                printf("%g", lua_tonumber(L, i));
                break;
            case LUA_TSTRING:
                printf("%s", lua_tostring(L, i));
                break;
            case LUA_TNIL:
                printf("nil");
                break;
            default:
                printf("%s", lua_typename(L, type));
                break;
        }
        printf(" ");
    }
    printf("\n");
}

void *my_alloc(void *ud, void *ptr, size_t osize, size_t nsize) {
    (void)osize;  // Unused in this example

    if (nsize == 0) {
        free(ptr);  // If nsize is 0, free the memory
        return NULL;
    } else {
        // Reallocate or allocate memory
        void *new_ptr = realloc(ptr, nsize);
        if (new_ptr == NULL) {
            // Allocation failed
            fprintf(stderr, "Memory allocation failed\n");
            return NULL;
        }
        return new_ptr;
    }
}

/*
int main() {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    lua_pushinteger(L, 1);
    lua_pushinteger(L, 2);
    lua_pushinteger(L, 3);
    lua_pushinteger(L, 4);

    printf("Before rotation: ");
    stackDump(L);

    lua_rotate(L, 2, -1); // Rotate one element to the right starting from index 2

    printf("After rotation: ");
    stackDump(L);

    lua_close(L);
    return 0;
}
*/  

int main()
{
    int ud[100] = {1,2,3,4};
    lua_State *L = lua_newstate(&my_alloc, ud);
    luaL_openlibs(L);
    // Rest of your code

    lua_close(L);
    return 0;
}

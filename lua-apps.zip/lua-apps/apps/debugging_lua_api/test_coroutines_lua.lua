co = coroutine.create(function ()
    local x = 10
    print(x)
    coroutine.yield()
    print("yes")
end)


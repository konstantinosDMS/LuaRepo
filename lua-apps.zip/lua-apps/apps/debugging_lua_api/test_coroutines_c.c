#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <lua.h>
#include <lauxlib.h>
#include <lualib.h>

/**
int main(void) {
    int res;
    int *nres = NULL;
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    nres = (int *)malloc(10 * sizeof(int));
    if (nres == NULL) {
        printf("Cannot allocate memory for nres.\n");
        exit(1);
    }

    // Load the Lua script
    res = luaL_loadfile(L, "test_coroutines_lua.lua");
    if (res != LUA_OK) {
        printf("cannot load file: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return -1;
    }

    // Run the Lua script
    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) {
        printf("cannot run file: %s\n", lua_tostring(L, -1));
        lua_close(L);
        return -1;
    }

    // Get the global variable "co"
    res = lua_getglobal(L, "co");
    if (!lua_isthread(L, -1)) {
        printf("variable 'co' is not a thread\n");
        lua_close(L);
        return -1;
    }

    // Get the coroutine from the Lua stack
    lua_State *co = lua_tothread(L, -1);
    if (co == NULL) {
        printf("cannot get thread\n");
        lua_close(L);
        return -1;
    }

    // Resume the coroutine
    res = lua_resume(co, L, 0, nres);   
    if (res != LUA_OK && res != LUA_YIELD) {
        printf("cannot resume thread: %s\n", lua_tostring(co, -1));
        lua_close(L);
        return -1;
    }

    printf("Coroutine resumed successfully.\n");

    // Resume the coroutine for the second time
    printf("Resuming coroutine for the second time...\n");
    res = lua_resume(co, L, 0, nres);
    if (res != LUA_OK && res != LUA_YIELD) {
            printf("cannot resume thread: %s\n", lua_tostring(co, -1));
            lua_close(L);
            return -1;
    }

    printf("Coroutine resumed successfully.\n");

    free(nres);
    // Close the Lua state
    lua_close(L);
    return 0;
}
*/

/**
int main(void) {
    lua_State *L = luaL_newstate();
    int *nres;
    
    nres = (int *) malloc(8 * sizeof(int));
    if (nres == NULL) {
        printf("Cannot allcate memory for nres");
        exit(1);
    }
    
    luaL_openlibs(L);

    luaL_dostring(L, "co = coroutine.create(function () local x = 10; coroutine.yield(); error('some error') end)");

    lua_getglobal(L, "co"); // Get the coroutine from the global environment

    int status = lua_resume(lua_tothread(L, -1), L, 0, nres);

    if (status == LUA_OK) {
        printf("Coroutine finished successfully.\n");
    } else if (status == LUA_YIELD) {
        printf("Coroutine yielded.\n");
    } else {
        printf("Coroutine error: %s\n", lua_tostring(L, -1));
    }

    free(nres);
    lua_close(L);
    return 0;
}
*/

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);
    int res;

    lua_State *L1 = lua_newthread(L);

    lua_pushstring(L1, "kostas");
    lua_pushinteger(L1, 5);

    int rres = lua_tointeger(L1, -1); // Retrieve the integer from the stack of L1
    if (rres == 0) {
        printf("Error getting value from stack.\n");
        exit(1);
    }
    printf("%d\n", rres);

    const char *str_rres = lua_tostring(L1, -2); 
    if (str_rres == NULL) {
        printf("Error getting value from stack.\n");
        exit(1);
    }
    printf("%s\n", str_rres);

    res = lua_pushthread(L1);
    if (res != LUA_OK) {
        printf("Error pushing the thread into stack.\n");
        exit(1);
    }

    L1 = lua_tothread(L, -1);
    if (L1 == NULL) {
        printf("Error threading L1 thread into L stack.\n");
        exit(1);
    }

    res = lua_closethread(L1, L);
    if (res != LUA_OK) {
        printf("Error closing stack L1\n.");
        exit(1);
    }

    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) {
        printf("Error calling thread L1\n.");
        exit(1);
    }

    lua_close(L);
    return 0;
}


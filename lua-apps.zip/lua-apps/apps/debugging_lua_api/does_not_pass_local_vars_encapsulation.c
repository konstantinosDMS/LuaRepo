#include <stdio.h>
#include <lua5.4/lua.h>
#include <lua5.4/lualib.h>
#include <lua5.4/lauxlib.h>

int main() {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);
    int res;
    
    // Load the Lua script
    res = luaL_loadfile(L, "access_no_locals_vars.lua");
    if (res != LUA_OK) {
        luaL_error(L, "cannot load %s: %s", "access_no_locals_vars.lua", lua_tostring(L, -1));
    }

    // Execute the Lua script
    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) {
        luaL_error(L, "cannot run %s: %s", "access_no_locals_vars.lua", lua_tostring(L, -1));
    }
    
    // Define the Lua code that sets the local variable within a function
    const char *luaCode = "function aaa() local x = 15 end";
    
    // Execute the Lua code to set the local variable
    res = luaL_dostring(L, luaCode);
    if (res != LUA_OK) {
        luaL_error(L, "Error while setting local variable: %s", lua_tostring(L, -1));
    }

    // Retrieve the value of the local variable 'x'
    lua_Debug ar;
    lua_getstack(L, 0, &ar); // Get the top stack frame (current function)
    lua_getinfo(L, "l", &ar); // Get information about the current function
    
    lua_getlocal(L, NULL, 1); // Get the first local variable of the function (x)
    int x = lua_tointeger(L, -1);
    lua_pop(L, 1); // Pop the value of x from the stack

    // Call the 'getvarvalue' Lua function with the value of 'x'
    res = lua_getglobal(L, "getvarvalue");
    if (res != LUA_TFUNCTION) {
        luaL_error(L, "cannot get function %s: %s", "getvarvalue", lua_tostring(L, -1));
    }
    lua_pushstring(L, "x");
    lua_pushinteger(L, 0);
    lua_pushstring(L, "_ENV");
    res = lua_pcall(L, 3, 3, 0);
    if (res != LUA_OK) {
        luaL_error(L, "Error calling getvarvalue: %s", lua_tostring(L, -1));
    }

    // Handle the returned values from 'getvarvalue'
    const char *type = lua_tostring(L, -3); 
    const char *name = lua_tostring(L, -2);
    const char *value = lua_tostring(L, -1);
    
    printf("type: %s, name: %s, value: %s\n", type, name, value);

    lua_close(L);
    return 0;
}

function ggg(x)
    print(x)
    return x
end

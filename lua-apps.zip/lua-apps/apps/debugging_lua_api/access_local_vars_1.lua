function foo (a, b)
	local c = a + b
    local name = debug.getlocal(1,1)
    print(c)
    return c 
end
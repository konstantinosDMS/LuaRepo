#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "luaconf.h"

/**
void debug_local_vars(lua_State *L, char *filename) {
    int res;

    res = luaL_loadfile(L, filename);
    if (res != LUA_OK) luaL_error(L, "cannot load %s: %s", filename, lua_tostring(L, -1));

    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));   
    
    int a = 5, b = 3;
    lua_getglobal(L, "foo");
    lua_pushinteger(L, a);
    lua_pushinteger(L, b);

    res = lua_pcall(L, 2, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));
}

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    debug_local_vars(L, "access_local_vars.lua");

    lua_close(L);
    return 0;
}
*/

/**
static void stackDump (lua_State *L) {
    int i;
    int top = lua_gettop(L); // depth of the stack 
    for (i = 1; i <= top; i++) { // repeat for each level 
        int t = lua_type(L, i);
        switch (t) {
            case LUA_TSTRING: { // strings 
                printf("LUA_TSTRING: '%s'", lua_tostring(L, i));
                break;
            }
            case LUA_TBOOLEAN: { // Booleans 
                printf("LUA_TBOOLEAN: %s", (lua_toboolean(L, i) ? "true" : "false"));
                break;
           }
            case LUA_TNUMBER: { // numbers
                if (lua_isinteger(L, i)){ 
                    printf("LUA_TNUMBER INTEGER: %lld", lua_tointeger(L, i));
                    break;
                }
                printf("LUA_TNUMBER FLOAT: %g", lua_tonumber(L, i));
                break;
            }
            default: { // other values 
                printf("Default Case: %s", lua_typename(L, t));
                break;
            }
        }   
        printf(" "); // put a separator 
    }
    printf("\n"); // end the listing 
}

void debug_local_vars(lua_State *L, char *filename) {

    //Need to debug the stack values
    int res;

    res = luaL_loadfile(L, filename);
    if (res != LUA_OK) luaL_error(L, "cannot load %s: %s", filename, lua_tostring(L, -1));

    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));   
    
    int a = 5, b = 3;
    lua_getglobal(L, "foo");
    lua_pushinteger(L, a);
    lua_pushinteger(L, b);

    //stackDump(L);
    res = lua_pcall(L, 2, 1, 0);
    if (res != LUA_OK) luaL_error(L, "cannot run %s: %s", filename, lua_tostring(L, -1));

    stackDump(L);
}

int main(void) {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    debug_local_vars(L, "access_local_vars_1.lua");

    lua_close(L);
    return 0;
}
*/

/***************************************************     */
/** Does not pass local vars declared                    */
/** Inside functions, activation records,                */
/** Main lua's environment due to encapsulation reasons  */
/** Better debugging from lua function                   */
/** See does_not_pass_local_vars_encapsulation.c         */
/***************************************************     */
/**
int main() {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);
    int res;
    char *str;

    res = luaL_loadfile(L, "access_no_locals_vars.lua");
    if (res != LUA_OK) 
        luaL_error(L, "cannot load %s: %s", "access_no_locals_vars.lua", lua_tostring(L, -1));

    res = lua_pcall(L, 0, 0, 0);
    if (res != LUA_OK) 
        luaL_error(L, "cannot run %s: %s", "access_no_locals_vars.lua", lua_tostring(L, -1));
    
    str = "y = \"function zz() local x = 5; end zz();\"";
    luaL_dostring(L, str);
    lua_getglobal(L, "y");
    
    //local x = 5;
    luaL_dostring(L, lua_tostring(L, -1));
    lua_Debug *ar;

    const char *tt;
    for (int  i = -5; i < 6; i++) {
        lua_getstack(L, i, ar);
        for (int j = -5; j < 5; j ++) {
            tt = lua_getlocal(L, ar, j);
            printf("i: %d, j: %d, value: %s\n", i, j, tt);
        }
    }    

printf("======================================================\n");
    
    for (int j = -5; j < 6; j ++) {
        tt = lua_getlocal(L, NULL, j);
        printf("j: %d, value: %s\n", j, tt);
    }

printf("======================================================\n");

    res = lua_getglobal(L, "getvarvalue");
    if (res != LUA_TFUNCTION) 
        luaL_error(L, "cannot get function %s: %s", "getvarvalue", lua_tostring(L, -1));
 
    lua_pushstring(L, "x");
    lua_pushinteger(L, 0);
    lua_pushstring(L, "_ENV");

    lua_pcall(L, 3, 3, 0);

    const char *type = lua_tostring(L, -3); 
    
    if (type) {
        printf("type: %s, name: %s, value: %s\n", type, lua_tostring(L, -2), lua_tostring(L, -1));
    } else {
        printf("Error getting variable type\n");
    }

    lua_close(L);
    return 0;
}
*/

int main() {
    lua_State *L = luaL_newstate();
    luaL_openlibs(L);

    const char *luaCode = "function myFunction() \n"
                          "    local x = 42 \n"
                          "    local y = 'Hello' \n"
                          "    return x + 1, y .. ' World!' \n"
                          "end";

    luaL_dostring(L, luaCode);

    lua_getglobal(L, "myFunction");
    lua_pcall(L, 0, 2, 0); // Call myFunction, expecting 2 return values

    // Inspect local variables of myFunction
    for (int i = 1; ; i++) {
        const char *name = lua_getlocal(L, NULL, i); // Get local variable by index
        if (name == NULL) break; // No more locals
        printf("Local variable %d: %s = %s\n", i, name, lua_tostring(L, -1));
        lua_pop(L, 1); // Pop the value from the stack
    }

    lua_close(L);
    return 0;
}

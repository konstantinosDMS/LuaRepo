function getvarvalue(name, level, isenv)
	local value
	local found = false
	level = (level or 1) + 1

	for i = 1, math.huge do
		local n, v = debug.getlocal(level, i)
		if not n then break end
		if n == name then
			value = v
			found = true
		end
	end

	if found then print("local", name, value); return "local", name, value; end
	-- try non-local variables
	local func = debug.getinfo(level, "f").func -- upvalues from the _ENV environment
	for i = 1, math.huge do
		local n, v = debug.getupvalue(func, i)
		if not n then break end
		if n == name then print("upvalue", name, v); return "upvalue", name, v; end
	end

	if isenv then print("noenv", nil, nil); return "noenv", nil, nil; end -- if not upvalues, or local vars and isenv = true then return to avoid _ENV._ENV._ENV ... recursion

	-- avoid loop
	-- not found; get value from the environment
	local _, name_1, env = getvarvalue("_ENV", level, true)
	if env then
        print("global", env[name], nil);
		return "global", env[name], nil;
	else -- no _ENV available
        print("noenv", nil, nil);
		return "noenv", nil, nil;
	end 
end

--like: local x = 15
--      getvarvalue("x")
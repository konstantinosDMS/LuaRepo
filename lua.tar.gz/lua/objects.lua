--[[
Account = {balance = 0}

function Account:withdraw(v)
    Account.balance = Account.balance - v
end

Account:withdraw(100.0)
print(Account.balance) -- -100.0
--]]
--[[
a = Account
a:withdraw(100.00) -- ERROR! attempt to index a nil value (global 'Account')
print(a.balance)
--]]
--[[
function Account:withdraw(self, v)
    self.balance = self.balance - v
end

local a1 = Account;
a1:withdraw(a1, 250.00)
print(a1.balance) -- 250.0

local a2 = {balance = 10.0; withdraw = Account.withdraw}
a2:withdraw(a2, 150.00)
print(a2.balance) -- 140.00
--]]
--[[
function Account:withdraw(v)
    self.balance = self.balance - v
end

local a2 = {balance = 50; withdraw = Account.withdraw}
a2:withdraw(300.00)
print(a2.balance) -- -250.00
--]]
--[[
Account = { balance = 10; withdraw = function(self, v)
                                         self.balance = self.balance - v
                                    end }
local a1 = Account
a1:withdraw(50.00)
print(a1.balance)

local a2 = {balance = 20; withdraw = Account.withdraw}
a2:withdraw(40.00)
print(a2.balance) -- 20.00
--]]
--[[
Account = {balance = 10.0}
Account.withdraw = function(self, v)
    self.balance = self.balance - v
end

local a1 = Account
a1:withdraw(20.00)
print(a1.balance) -- -10.0
--]]
--[[
Account = {balance = 10.00}
function Account:withdraw (v)
    self.balance = self.balance - v
end

local a1 = Account
a1:withdraw(30.00)
print(a1.balance) -- -20.00
--]]
--[[
Account = {balance = 0,
           withdraw = function(self, v)
                self.balance = self.balance - v 
            end}
function Account:deposit(v)
    self.balance = self.balance + v
end

Account.deposit(Account, 30.00)
print(Account.balance) -- 30.00
Account:withdraw(40.00)
print(Account.balance) -- -10.00

local mt = {__index = Account}

function Account.new(o)
    o = o or {}
    setmetatable(o, mt)
    return o
end

local a1 = Account.new{balance = 100.00}
a1:deposit(200.00)
print(a1.balance) -- 300.00
--]]
--[[
getmetatable(a1).__index.deposit(a1, 300.00)
print(a1.balance) -- 600.00
--]]
--[[
function Account:new(o)
    o = o or {}
    self.__index = Account
    setmetatable(o, self)
    return o
end

function Account:deposit(v)
    self.balance = self.balance + v
end

function Account:withdraw (v)
    self.balance = self.balance - v
end

local a2 = Account:new{}
print(a2.balance) -- 0

a2:deposit(100.00)
print(a2.balance) -- 100.0

a2:withdraw(100.00)
print(a2.balance) -- 0.00
--]]
--[[
Account = {balance = 0}

function Account:new(o)
    o = o or {}
    self.__index = self
    setmetatable(o, self)
    return o
end

function Account:deposit(v)
    self.balance = self.balance + v
end

function Account:withdraw(v)
    if v > self.balance then error "insufficient funds - Account" end
    self.balance = self.balance - v
end

SpecialAccount = Account:new{}
local s = SpecialAccount:new{limit = 1000}

function SpecialAccount:withdraw(v)
    if v - self.balance >= self:getLimit() then error "insufficient funds - SpecialAccount" end
    self.balance = self.balance - (v + 1)
end

function Account:getLimit()
    return self.limit or 0
end

s:deposit(100.00)
print(s.balance) -- 100.00

s:withdraw(50.00)
print(s.balance) -- 50.00

function s:getLimit()
    return self.balance * 0.10
end

s:withdraw(20.00)
print(s.balance) -- 28.00
--]]

--[===[
-- Multiple Inheritance --
local function search(k, plist)
    for i = 1, #plist do
        local v = plist[i][k]
        if v then return v end
    end
end

function createClass(...)
    local c = {}
    local parents = {...}

    function setmetame(t,k)
        -- return search(k, parents)
        print(" aaaaaaaaa " , t, k, parents)
        local v = search(k, parents)
        t[k] = v
        return v 
    end

    setmetatable(c, {__index = setmetame })

    c.__index = c

    function c:new(o)
        o = o or {}
        setmetatable(o, c)
        return o
    end

    return c
end

Named = {}

function Named:setName(v)
    self.name = v
end

function Named:getName()
    return self.name
end

Account = {balance = 0}

function Account:new(o)
    o = o or {}
    self.__index = self
    setmetatable(o, self)
    return o
end

function Account:withdraw(v)
    if v > self.balance then error "insuficcient funds - Account" end
    self.balance = self.balance - v
end

function Account:deposit(v)
    self.balance = self.balance + v
end

SpecialAccount = Account:new{}

function SpecialAccount:withdraw(v)
    if v - self.balance >= self:getLimit() then error 'insufficient funds - SpecialAccount' end
    self.balance = self.balance - v
end

function SpecialAccount:getLimit()
    return self.limit or 0
end

local NamedAccount = createClass(Named, SpecialAccount)
local account = NamedAccount:new{name = "Paul"}
print(account:getName())
print(account.balance) -- 0
account:deposit(50)
print(account.balance) -- 50.0
account:withdraw(20.00)
print(account.balance) -- 30.0
--]===]
--[[
function newAccount(initialBalance)
    local self = {balance = initialBalance, Limit = 10000.0}
    
    local extra = function()
        if self.balance > self.Limit then 
            return self.balance * 0.10
        end
        return 0
    end

    local withdraw = function(v)
        self.balance = self.balance - v
    end
    
    local deposit = function(v)
        self.balance = self.balance + v
    end

    local getBalance = function()
        return self.balance + extra()
    end

    return {withdraw = withdraw, deposit = deposit, getBalance = getBalance}
end

local acc1 = newAccount(10000.00)
acc1.deposit(50.0)
print(acc1.getBalance()) -- 150.00
acc1.withdraw(50.00) -- 100.00
print(acc1.getBalance())
--]]
--[[
function newObject(value)
    return function(action, v)
        if action == 'get' then return value 
        elseif action == 'set' then value = v
        else error "invalid action" end
    end
end

local newobject = newObject('kostas')
newobject('set', 5)
print(newobject('get')) -- 5
--]]
--[[
Account = {balance = 0}

function Account:withdraw(v)
    self.balance = self.balance - v
end

function Account:deposit(v)
    self.balance = self.balance + v
end

function Account:getBalance()
    return self.balance
end

function Account:new(o)
    o = o or  {}
    self.__index = self
    setmetatable(o, self)
    return o
end

local acc_1 = Account:new{}
acc_1:deposit(50.0)
print(acc_1:getBalance()) -- 50.0
--]]
--[[
local balances = {}

local Account = {}

function Account:new(o)
    o = o or {}
    self.__index = self
    setmetatable(o, self)
    balances[o] = 0
    return o
end

function Account:withdraw(v)
    balances[self] = balances[self] - v
end

function Account:deposit(v)
    balances[self] = balances[self] + v
end

function Account:getBalance()
    return balances[self]
end

function Account:addToBalances(v)
    balances[self] = v
end

local acc_1 = Account:new{}
acc_1:deposit(100.0)
-- print(acc_1:getBalance()) -- 100.0
acc_1:withdraw(50.0)
-- print(acc_1:getBalance()) -- 50.0


for k, v in pairs(balances) do
    print(k, v)
end


local acc_2 = Account:new{}
acc_2:deposit(50.0)
-- print(acc_2:getBalance()) -- 50.0
acc_2:withdraw(20.0)
-- print(acc_2:getBalance()) -- 30.0

for k, v in pairs(balances) do
    print (k, v)
end
--]]

--[[
-- Exercise 21.1 -- 
local Stack = {ref_table = {}}

function Stack:push(v)
    table.insert(self.ref_table, v)
end

function Stack:pop()
    return table.remove(self.ref_table, #self.ref_table)
end

function Stack:top()
    return self.ref_table[#self.ref_table]
end

function Stack:isEmpty()
    return (#self.ref_table == 0) and true or false
end

function Stack:new(o)
    o = o or {}
    self.__index = self
    setmetatable(o, self)
    return o
end
--]]
--[[
local testStck = Stack:new{}
testStck:push(1)
testStck:push(2)
testStck:push(3)
print(testStck:top())
print(testStck:pop())
print(testStck:top())
print(testStck:pop())
print(testStck:top())
print(testStck:pop())
print(testStck:top())
--]]

--[[
-- Exercise 21.2 -- : 
StackQueue = Stack:new{}

function StackQueue:insertBottom(v)
    table.move(self.ref_table, 1, #self.ref_table, 1, self.ref_table)
    table.insert(self.ref_table, 1, v)
end

local stackqueue = StackQueue:new{}
stackqueue:push(1)
stackqueue:push(2)
stackqueue:push(3)

for k, v in ipairs(Stack.ref_table) do
    print(k, v)
end

stackqueue:insertBottom(8)

print("================================")

for k, v in ipairs(Stack.ref_table) do
    print(k, v)
end

print("================================")

print(stackqueue:pop())
print(stackqueue:top())
print(stackqueue:pop())
print(stackqueue:top())
print(stackqueue:pop())
print(stackqueue:top())
--]]

--[===[
-- Exercise 21.3 -- : Reimplement your Stack class using a dual representation.

local ref_table = {}

local Stack = {}

function Stack:push(v)
    if ref_table[self] == nil  then ref_table[self] = {} end 
    table.insert(ref_table[self], v)
end

function Stack:pop()
    return table.remove(ref_table[self], #ref_table[self])
end

function Stack:top()
    return ref_table[self][#ref_table[self]]
end

function Stack:isEmpty()
    return (#ref_table[self] == 0) and true or false
end

function Stack:new(o)
    o = o or {}
    self.__index = self
    setmetatable(o, self)
    ref_table[self] = {}
    return o
end

local stck = Stack:new{}
stck:push(1)
stck:push(2)
stck:push(3)
print(stck:top())
print(stck:pop())
print(stck:top())
--]===]


-- Exercise 21.4 -- : 
local AccountProxy = {}

-- Internal table mapping proxies to actual Account tables
local accounts = {}

function AccountProxy:new()
 local proxy = {}
 local account = {balance = 0}
 accounts[proxy] = account

--[[
 function proxy.deposit(v)
    if v ~= nil then
        AccountProxy.deposit(proxy, v)
    else error('Attempt to perform arithmetic on a nil value', 2) 
    end
 end

 function proxy.withdraw(v)
    if v ~= nil then 
        AccountProxy.withdraw(proxy, v)
    else error('Attempt to perform arithmetic on a nil value', 2) 
    end
 end

 function proxy.getBalance()
    return AccountProxy.getBalance(proxy)
 end
--]]
 
 setmetatable(proxy, {   
    __index = self,
 })

 return proxy
end

function AccountProxy:withdraw(v)
   accounts[self].balance = (accounts[self].balance or 0) - v
end

function AccountProxy:deposit(v)    
    accounts[self].balance = (accounts[self].balance or 0) + v     
end

function AccountProxy:getBalance()
   return accounts[self].balance or 0
end

-- Example usage
local acc_1 = AccountProxy:new() -- acc_1 is the proxy
 
acc_1:deposit(100.0) 
print(acc_1:getBalance())  -- 100.0
acc_1:withdraw(50.0)
print(acc_1:getBalance())  -- 50.0

--[[
acc_1.deposit(nil)
print(acc_1.getBalance())  -- 100.0
--]]











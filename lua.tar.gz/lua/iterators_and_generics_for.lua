-- Simple Iterator --
--[[
function values(t)
    local i = 0
    return function () i  = i + 1; return t[i]; end
end

-- values => factory, creates the iterator (closure)

a = {1, 3, 5, 7}
iterator, s, j = values(a) -- function, nil, nil
-- print(iterator(), s, j)
-- print(iterator())  -- 1
-- print(iterator()) -- 3, cause inner returned function() keeps the state of the 
                     -- upvalue variable i
--]]
--[[
iterator = nil
iterator  = values(a)


for v in iterator do
    print(v) -- 1 3 5 7
end
--]]
--[[
iterator = nil
iterator = values(a)

while true do
    element = iterator() -- get the element, here iterator is 
                         -- initialized in each loop
    if element ~= nil then
        print(element) -- 1 3 5 7
    else
        break
    end
end
--]]
--[[
-- iterator traverse the words from the standard input --
function allwords()
    local line = io.read()
    local pos = 1

    return function()
        while line do
            word_1, word_2 = string.match(line, "(%w+)()", pos)
            if not word_1 then 
                line = io.read()
                pos = 1
            else pos = word_2 return word_1 end
        end
        return nil
    end
end

local iterator = allwords()

for word in iterator do -- here iterator is not initialized in each loop 
    print(word)
end
--]]

--[[
-- int generic FOR we get in every loop
-- the iterator function(), 
-- the invariant state (next object brings the iterator), remember the iterator
-- was called only once int FOR LOOP, 
-- the control variable(variable controls the iterator)
-- iterator inplementation wth FOR

for var-list in exp-list do -- Usually the expression list has only one element, 
                            -- a call to an iterator factory (allwords()).
    -- block
end 
--]]

-- for k, v in pairs(t) do print(k, v) end  -- k -> control variable, whn nil stops
                                            -- the iteration 


--[[
function testMe()
    local i = 0
    a = {1, 2, 3}

    return function()
        i = i + 1
        return a[i]
    end
end

for var_1, var_2, var_3 in testMe() do  -- 1       nil     nil (1 = value, state, controller)
                                        -- 2       nil     nil (2 = value, state, controller)
                                        -- 3       nil     nil (3 = value, state, controller)
    print(var_1, var_2, var_3)
end

for var_1, var_2, ... , var_n in explist_t do  -- explist_t is the iterator factory (allwords())
    -- block
end

-- is equivalent to 
do
local _f, _s, _var = explist_t  -- iterator factory, state, controller-variable
    while true do
        local var_1, var_2, ..., var_n = _f(_s, _var) -- get the new vars from the iterator 
         _var = _var_n
         if var == nil then break end
    end
end
--]]

-- Stateless Iterators -- 
-- Stateless For Iterators --
--[[
function testMe()
    local i = 0
    a = {1, 2, 3, 4, 5}

    return function()
        i = i + 1
        return a[i]
    end
end

local iter = testMe()

for k in iter do
    print("k = " .. k)
    if  k == 2 then break end
end

for j in iter do
    print("j = " .. j)
end
--]]
--[[
-- Stateless iterator ipairs() --
a = {"one", "two", "three"}
for k, v in ipairs(a) do -- ipairs is the factory-iterator
    -- print(k, v)
end

-- or ipairs as --
function iter(t, i)
    i = i + 1
    local v = t[i]
    if v then return i, v end
    return nil
end

function ipairs(t)
    return iter, t, 0 -- function iter as the iterator, 
                      -- t as the invariant state, 
                      -- zero as the initial value for the control variable.
end

a = {1, 2, 3}
for k in ipairs(a) do
    print(k) -- 1 2 3
end
--]]

--[[
-- pairs The function pairs, which iterates over all elements of a table, 
-- is similar, except that its iterator function is next, which is a 
-- primitive function in Lua
function pairs_1(t)  -- The call next(t, k), where k is a key of the table t, 
                   -- returns a next key in the table, in an arbitrary
                   -- order, plus the value associated with this key as a 
                   -- second return value. The call next(t, nil) returns
                   -- (next = key, t = value, control_value)
                    -- a first pair. When there are no more pairs, next returns 
                    -- nil.
    return next, t, nil 
end

a = {["name"] = "kostas", ["second_name"] = "dimos", ["father_name"] = "george"}

for k, v in pairs_1(a) do    -- father_name     george
                             -- second_name     dimos
                             -- name    kostas
    print(k ,v)
end

-- or --
for k, v in next , a do   -- second_name     dimos
                          -- name    kostas
                          -- father_name     george
    print(k, v)
end
--]]

-- Stateless Iterator, linked lists whr the control var is the current node
-- to return the next node
-- is not running --
--[===[
-- Node structure for the linked list
local Node = {}

-- Function to create a new node
function Node:new(value)
    local newNode = { value = value, next = nil }
    setmetatable(newNode, self)
    self.__index = self
    return newNode
end

-- Iterator function to traverse the linked list
function traverse(list)
    local current = list

    return function()
        local value = current and current.value
        current = current and current.next
        return value
    end
end

-- Example usage:
local a = Node:new(1)
local b = Node:new(2)
local c = Node:new(3)

a.next = b
b.next = c

local iter = traverse(a)

-- Iterate through the linked list
local value
repeat
    value = iter()
    if value then
        print(value)
    end
until not value
--]===]
--[===[
local a, b, c, d = {}, {}, {}, {}

a.next = b
a.value = 1
a.name = "a"

b.next = c
b.value = 2
b.name = "b"

c.next = d
c.value = 3
c.name = "c"

d.next = a
d.value = 4
d.name = "d"

-- print(a, b, c, d)
local myData = {a = a, b = b, c = c, d = d}
--]===]
--[===[
local function getNext(node) 
    return node.next
end

local function traverse(list, node)
    return getNext, list, nil -- iterator - getNext, 
                                -- state = list, 
                                -- current_node = node 
    -- or return getNext, nil, node -- 2nd, 3rd are not necessary, 
                                    -- just to take iterator
    -- or return getNext, nil, list
end

local node = myData.a 
local cnt = 0
local iter = traverse(myData, nil)

if iter ~= nil then     
    while true do
        print(node.name)
        print(node.value)
        print("============")
        node = iter(node)        
        cnt  = cnt + 1
        if cnt == 5 then break end
    end
end
--]===]
--[===[
-- 2nd version  --
function getNext(list, node)
    if node == nil then return list end -- 1st time just take the iterator
    return node.next
end

function traverse(list, node)
    return getNext, list, node
end

local iter = traverse(myData, nil)
local cnt = 0 
local node = myData.a

if iter ~= nil then 
    while true do
        print(node.name)
        print(node.value)
        print("=============")
        node = iter(node.next)
        cnt = cnt + 1
        if cnt == 5 then break end
    end
end
--]===]
--[===[
-- Traversing tables in order --
test_t1 = {["b"] = "kostas", ["a"] = "nikos", ["d"] = "paulos", ["c"] = "yiannis"}
test_t2 = {}

for k, v in pairs(test_t1) do
    table.insert(test_t2, k)
end

table.sort(test_t2, function(a, b)
                        return a < b
                    end)

for k, v in ipairs(test_t2) do
    print (k, test_t1[v])
end
--]===]
--[===[
lines = {
    ["luaH_set"] = 10,
    ["luaH_get"] = 24,
    ["luaH_present"] = 48,
}

function pairsByKeys (t, f)
    local a = {}
    for n in pairs(t) do  -- create a list with all keys
        a[#a + 1] = n
    end

    table.sort(a, f)  -- sort the list
    local i = 0  -- iterator variable
    return function ()  -- iterator function
        i = i + 1
        return a[i], t[a[i]] -- return key, value
    end
end

for name, line in pairsByKeys(lines) do
    print(name, line)
end
--]===]

-- True Operators --
function allWords(f)
    for line in io.lines() do
        word = string.match(line, "%w+")
        f(word)
    end
end

-- allWords(print)

local count  = 0
--[[
allWords(function(w)
            if w == 'kostas' then 
                count = count + 1
                -- if count == 3 then print(count) end
            end
        end)
print(count)
--]]
--[[
-- or --
function allWords_1()
    local tmp = {}
    local cnt = 0
    for line in io.lines do
        line = io.read()
        word = string.match(line, "%w+")
        cnt = cnt + 1
        if cnt == 3 then break end 
    end
    return function()
        return word
    end
end

local cnt = 0

for word in allWords_1() do
    if word == 'kostas' then cnt = cnt + 1 end
    if cnt  == 3 then break end 
end

print(cnt)
 --]]

 -- Exercise 18.1 --
--[[
 function fromTo_1(n, m)
    local i = n - 1
    return function()
        i = i + 1
        if i <= m then
            return i
        end
    end
end

local n = 1
local m = 10

for i in fromTo_1(n, m) do
    -- print(i)
end
--]]
--[[
-- Stateless Iterator --

function fromTo_2(n, m)
    local state  = n - 1
    return function()
        state = state + 1
        if state <= m then
            return state
        end
    end
end

for i in fromTo_2(1, 10) do
    print(i)
end
--]]

-- exercise 18.2 --
--[[
function fromTo_1(n, step, m)
    local i = n - 1
    return function()
        i = i + step
        if i <= m then
            return i
        end
    end
end

local n = 1
local m = 10
local step = 2

for i in fromTo_1(n, step,  m) do
    print(i)
end
--]]
--[[
function fromTo_2(n, step, m)
    local state = n - 1
    return function()
        state = state + step
        if state <= m then return state 
        else return nil end
    end
end

local step = 2

for i in fromTo_2(1, step, 10) do
    if i ~= nil then 
        print(i)
    else break end
end
--]]
--[[
-- Exercise 18.3 --
function allwords ()
    local cnt  = 0
    local flg
    local tmp = {}
    local fp = io.open("test14.txt", "r")
    if fp ~= nil then 
        local line = fp:read() -- current line
        local pos = 1 -- current position in the line
        return function () -- iterator function
            while line do -- repeat while there are lines
                local w, e = string.match(line, "(%w+)()", pos)
                if w then -- found a word?
                    flg = false
                    for i = 1, #tmp do
                        if tmp[i] == w then flg = true pos = e end
                    end
                    if not flg then 
                        cnt = cnt + 1
                        table.insert(tmp, w)
                        pos = e -- next position is after this word
                        return w, cnt -- return the word
                    end
                else line = fp:read() -- word not found; try next line
                    pos = 1 -- restart from first position
                end
            end
            fp:close()
            return nil -- no more lines: end of traversal
        end
    end
end

for word, cnt in allwords() do
    print(word)
    print(cnt) -- 213  -->  98
end 
--]]
--[[
-- Exercise 18.4 --
function getNonEmptySubStrings_1(str)
    return string.gmatch(str, "(%w+)") -- gmatch() is an iterator
end

function getNonEmptySubStrings_2(str)
    local start_str
    local end_str 
    start_str = (start_str == nil) and start_str or 0
    end_str = (end_str == nil) and end_str or 0
    return function ()
        start_str, end_str = string.find(str, "(%w+)", end_str + 1)
        if start_str and end_str then return string.sub(str, start_str, end_str) end
        return nil     
    end
end

str = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac justo nec odio suscipit fermentum.'
for word in getNonEmptySubStrings_2(str) do
    print(word)
end
--]]
--[===[
-- Exercise 18.5 --
function mySort(tmp)
    table.sort(tmp, function(a, b)
                      return a > b
                    end)
    return tmp
end

function getElements(thesis, plithos, sets)
    local tmp = {}
    if thesis + plithos > (#sets + 1) then return tmp end
    while plithos > 0 do
        table.insert(tmp , sets[thesis])
        plithos = plithos - 1
        thesis = thesis + 1
    end
    return tmp
end

function getAllSubsets(sets)
    local tmp = {}
    for i = 1, #sets do
        tmp[i] = {} 
        for j = 1, #sets do
            tmp[i][j] = getElements(j, i ,sets)  
        end
    end
    return tmp
end

local a = {1, 2, 3, 4, 5}
local mySet = getAllSubsets(a)

-- print(table.concat(mySet, ", "))

local str = ''

-- Print the result
for i = 1, #mySet do
    for j = 1, #mySet[i] do
        print(table.concat(mySet[i][j], ', '))
    end
end

--[[
1, 2, 3, 4, 5

{1,1} = 1, {1, 2} = 2, {1, 3} = 3, {1, 4} = 4, {1, 5} = 5

{
    {1},             {2},          {3},            {4},    {5}
    {1, 2},          {2, 3},       {3, 4},         {4, 5}, {}
    {1, 2, 3},       {2, 3, 4},    {3, 4, 5},      {},     {}
    {1, 2, 3, 4},    {2, 3, 4, 5}, {},             {},     {}
    {1, 2, 3, 4, 5}, {},           {},     {},     {}
}
--]]

--]===]
--[===[
function allSubsets(set)
    local n = #set
    local indices = {}
    
    local function getNextIndex(currIndex)
        for i = currIndex, n do
            if not indices[i] then
                return i
            end
        end
        return nil
    end

    local index = getNextIndex(1)  -- Initialize outside the iterator

    return function()
        local subset = {}

        if not index then
            return nil  -- No more subsets
        end

        while index do
            table.insert(subset, set[index])
            indices[index] = true
            index = getNextIndex(index + 1)
        end

        -- Reset indices for the next iteration
        for i = 1, n do
            indices[i] = nil
        end

        return subset
    end
end

-- Example usage:
local mySet = {1, 2, 3}

local iterator = allSubsets(mySet)
local subset = iterator()
while subset do
    print(table.concat(subset, ', '))
    subset = iterator()
end
--]===]
--[[
function permute(arr, start)
    if start == #arr then
        print(table.concat(arr, ", "))
    else
        for i = start, #arr do
            arr[start], arr[i] = arr[i], arr[start]
            permute(arr, start + 1)
            arr[start], arr[i] = arr[i], arr[start]  -- backtrack
        end
    end
end

local inputTable = {1, 2, 3, 4, 5}
permute(inputTable, 1)
--]]

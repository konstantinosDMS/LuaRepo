function testMe()
    print(debug.getinfo(testMe()))
end
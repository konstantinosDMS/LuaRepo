#include <stdio.h>

struct Record {
	int x;
	char myCode[3];
	float value;
}a;

int main() {
	struct Record records[4];
	records[0].x = 1;
	records[0].value = (float)1;
	records[0].myCode[0] = 'a';
	records[0].myCode[1] = 'b';
	records[0].myCode[2] = 'c';
		
	records[1].x = 2;
	records[1].value = (float)2;
	records[1].myCode[0] = 'c';
	records[1].myCode[1] = 'd';
	records[1].myCode[2] = 'e';

	records[2].x = 3;
	records[2].value = (float)3;
	records[2].myCode[0] = 'f';
	records[2].myCode[1] = 'g';
	records[2].myCode[2] = 'h';

	records[3].x = 4;
	records[3].value = (float)4;
	records[3].myCode[0] = 'a';
	records[3].myCode[1] = 'b';
	records[3].myCode[2] = 'c';

	records[4].x = 2;
	records[4].value = (float)5;
	records[4].myCode[0] = 'c';
	records[4].myCode[1] = 'b';
	records[4].myCode[2] = 'e';
}


-- Main Code
local Set = require('Set')
--[===[
local S1 = Set.new({1, 2, 3, 4})
local S2 = Set.new({1, 2, 3, 4, 5})
-- print(getmetatable(S1), getmetatable(S2)) -- table: 0x55cbedd925d0   table: 0x55cbedd925d0
-- for k, v in ipairs(S1) do print(k, v) end

local unionResult = S1 + S2
-- print("Union Result:", Set.tostring(unionResult))
-- for k, v in ipairs(unionResult) do print(k, v) end

local intersectionResult = S1 * S2
-- print("Intersection Result:", Set.tostring(intersectionResult))
-- for k, v in ipairs(intersectionResult) do print(k, v) end

--[[
print(S1 <= S2) --> true
print(S1 < S2) --> true
print(S1 >= S1) --> true
print(S1 > S1) --> false
print(S1 == S2 * S1) --> true
--]]

--[[
print(S1) -- table: 0x560df00b8f70 wthout mt.__tostring = Set.tostring or
          -- {1, 2, 3, 4} wth mt.__tostring = Set.tostring
--]]
--]===]
--[[
S3 = Set.new{}
print(getmetatable(S3))
setmetatable(S3, {}) -- cannot change a protected metatable
--]]
--[[
local S1 = Set.new{1, 2, 3, 4, 5}
for k, v in pairs(S1) do
    print (k, v)
end
--]]

local prototype = {x = 0, y = 0, width = 100, height = 100}
local mt = {}

function new(o)
    setmetatable(o, mt)
    return o
end

--[[
mt.__index = function(_, key)
    return prototype[key]
end
--]]
--[[
mt.__index = prototype

mt.__tostring = function(a)
    return 'a.x = ' .. a.x .. ' a.y = ' .. a.y .. 
           ' a.width = ' .. a.width .. ' a.height = ' .. a.height .. ' a.k = ' .. a.k
end

a = new{x = 10, y = 20}
-- print(a)

a.k = 'kostas'
print(a) -- a.x = 10 a.y = 20 a.width = 100 a.height = 100 a.k = kostas 
--]]
--[[
function setDefault(t, d)
    local mt = {__index = function() return d end}
    setmetatable(t, mt)
end

tab = {x = 10, y = 20}
print(tab.x, tab.z) -- 10      nil
setDefault(tab, 0)
print(tab.x, tab.z) -- 10      0
--]]
--[[
local mt_1 = { __index = function(t) return t. __ end}
function setDefault_1(t, d)
    t.__ = d
    setmetatable(t, mt_1)
end

local key = {}
local mt_2 = {__index = function(t) return t[key] end}
function setDefault_2(t, d)
    t[key] = d
    setmetatable(t, mt_2)
end

mt_1.__tostring = function(a)
    local str = ''
    for k, v in pairs(a) do
        str = str .. ' ' .. v
    end
    return str
end

mt_2.__tostring = function(a)
    local str = ''
    for k, v in pairs(a) do
        str = str .. ' ' .. v
    end
    return str
end
--]]
--[[
t_1 = {1, 2, 3}
setDefault_1(t_1, 5)
print(t_1) -- 1 2 3 5
--]]

--[[
t_2 = {1, 2, 3}
setDefault_1(t_2, 5)
print(t_2) -- 1 2 3 5
--]]
--[[
function track(t)
    local proxy = {}
    local mt = {
        __index = function(_, k)
            print("*access to element " .. tostring(k))
            return t[k]
        end,
        __newindex = function(_, k, v)
            print("*update of element " .. tostring(k) .. " to " .. tostring(v))
            t[k] = v
        end,
        __pairs = function()
            return function(_, k)
                local nextkey, nextval = next(t, k)
                if nextkey ~= nil then print("*traversing element " .. tostring(nextkey)) end
                return nextkey, nextval
            end
        end,
        __len = function() return #t end,
        __tostring = function()
            local str = '{'
            for k, v in pairs(t) do
                str = str .. ' ' .. tostring(v)
                if k < #t then
                    str = str .. ','
                end
            end
            str = str .. ' }'
            return str
        end
    }
    
    setmetatable(proxy, mt)  -- Corrected to set the metatable for the proxy
    return proxy
end

local t = {}
t = track(t)
t[2] = "hello"
t[1] = 'kostas'
print(t)

t = track({10, 20})
print(#t) -- 2
for k, v in pairs(t) do
    print(k, v)  -- *traversing element 1 1       10  *traversing element 2 2       20
end
--]]
--[===[
function readOnly(t)
    local proxy = {}
    local mt = { __index = t, 
                 __newindex = function(t, k, v) error('attempt to update a read-only table', 2) end,
                 __tostring = function() 
                        local str = ''
                        for k, v in pairs(t) do
                            str = str .. ' ' .. v
                        end
                        return str
                    end }
                 setmetatable(proxy, mt)
                 return proxy
end

days = readOnly{"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}
-- print(days[1])
print(days) -- Sunday Monday Tuesday Wednesday Thursday Friday Saturday
days[2] = 'kostas' -- attempt to update a read-only table
--]===]

--[[
-- Exercise 20.1 --

local mt_1 = {}

function new(o)
    setmetatable(o, mt_1)
    return o
end

mt_1.__tostring = function(a)
    local str = ''
    for k, v in pairs(a) do
        str = str .. ' ' .. v
    end
    return str
end

mt_1.__sub = function(a, b)
    local res = {}
    for k, v in pairs(a) do
        local flg = false
        for j, l in pairs(b) do
            if v == l then
                flg = true
                break  -- Move break inside the if condition
            end
        end
        if not flg then
            table.insert(res, v)
        end
    end
    return res
end

local a = new{1, 2, 3, 4, 5}
local b = new{2, 3, 4}
local res = a - b  -- Corrected the way to call the __sub method
for k, v in pairs(res) do
    print(k, v)
end
--]]
--[[
-- Exercise 20.2 --
local mt_2 = {}

function new(o)
    o = o or {}
    setmetatable(o, mt_2)
    return o
end

mt_2.__len = function(a)
                return rawlen(a)
             end

local a = new{1, 2, 3}
print(#a) -- 3
--]]
--[[
-- Exercise 20.3 --
function readOnly (t)
    local proxy = {}
    local mt = {
        __index = function(t, k, v)
                error('attempt to retrieve a read-only table', 2)
        end,
        __newindex = function (t, k, v)
            error("attempt to update a read-only table", 2)
        end
    }
    setmetatable(proxy, mt)
    return proxy
end

local t = {1, 2, 3}
t = readOnly(t)
print(t[1])
--]]
--[[
-- Exercise 20.4 --
function fileAsArray(fileName)
    local proxy = {}
    local mt = {}
    local fd = io.open(fileName, 'r')
    local data = ''
    if fd ~= nil then 
        data = fd:read("a")
        fd:close()
    end
    mt.__index = function(_, key)
       if data then return string.sub(data, key, key) end
    end
    mt.__newindex = function(_, key, value)
        local data_prefix = string.sub(data, 1, key - 1)
        local data_suffix = string.sub(data, key + 1, #data)
        data = data_prefix .. value .. data_suffix
    end
    mt.__tostring = function() return data end
    setmetatable(proxy, mt)
    return proxy
end

local fileName = 'test14.txt'
local file = fileAsArray(fileName)
-- print(file[5])
file[5] = 'O'
print(file)
--]]

--[[
-- Exercise 20.5 --
function fileAsArray(fileName)
    local proxy = {}
    local mt = {}
    local fd = io.open(fileName, 'r')
    local data = ''
    if fd ~= nil then 
        data = fd:read("a")
        fd:close()
    end
    mt.__index = function(_, key)
       if data then return string.sub(data, key, key) end
    end
    mt.__newindex = function(_, key, value)
        local data_prefix = string.sub(data, 1, key - 1)
        local data_suffix = string.sub(data, key + 1, #data)
        data = data_prefix .. value .. data_suffix
    end
    mt.__tostring = function() return data end
    mt.__len = function() return #data end
    mt.__pairs = function()
        local j = 0
        local ww = ''
        return function()
            j = j + 1
            if j < #data then ww = string.sub(data, j, j) return j, ww 
            else return nil end
        end
    end 
    setmetatable(proxy, mt)
    return proxy
end

local fileName = 'test14.txt'
local data = fileAsArray(fileName)
print(#data) -- 1474
for k, v in pairs(data) do
    print(k, v)
end
--]]
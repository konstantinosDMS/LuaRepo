function testMe()
    print('aaaa')
end

for i = 1, 10 do
    testMe()
end
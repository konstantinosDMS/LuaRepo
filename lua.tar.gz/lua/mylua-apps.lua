-- print('Hello World');

-- fuctorial --
--[[  
function fuct(n)
    if n == 1 then
        return 1
    end
    return n * fuct(n-1)
end

print('Give a number:')
numb = io.read("*n")
-- print(numb)
print(fuct(numb))
--]]

-- dofile('lua-norm.lua') 
-- gives on the interactive environment 
-- the variables

--[[
print(b) -- nill
b = nil
print(b) -- nill , after the assgnment lua can claim the 
         -- assigned memory from b = nil 
--]]
--[[
print(type(nil)) -- nill
print(type(true)) -- boolean -- @false{} and @true{},
print(type(10.4 * 3)) -- number
print(type("Hello world")) -- string
print(type(io.stdin)) -- USERDATA, arbitrary C data stored on vars
--]]
--[[
The userdata type allows arbitrary C data to be stored in Lua variables. 
It has no predefined operations in Lua, except assignment and equality test. 
Userdata are used to represent new types created by an application
program or a library written in C; for instance, the standard I/O library 
uses them to represent open files.
We will discuss more about userdata later, when we get to the C API.
--]]
--[[
print(type(print)) -- function
print(type(type)) -- function
print(type({})) -- table
print(type(type(X))) -- string, cause always type always returns string
                   
-- one more variable type on lua: THREAD
--]]

--[[
    false, nill -> false
    zero,empty_string -> true
--]]
--[[
print('' and 1) --> true
print(0 and 1) --> true
print(false and 1) --> false
print(nil and 1) --> nill
print('' or 1) --> --- nothing to display
print(0 or 1) --> 0
print(false or 1) --> true
print(nil or 1) --> true
--]]
--[[
print(4 and 5)  --> 5
print(nil and 13)  --> nill
print(false and 13)  --> false
print(0 or 5)   --> 0
print(false or "hi")  --> "hi"
print(nil or false)  --> false
--]]

-- x = x or v, which is equivalent to if not x then x = v end

-- ((a and b) or c) or simply (a and b or c) equivalent to a?b:c)
--[[
print(not nil) --> true
print(not false) --> true
print(not 0) --> false
print(not not 1) --> true
print(not not nil) --> false
--]]

-- The -e option allows us to enter code directly into the command line, 
-- like here:
-- % lua -e "print(math.sin(12))" --> -0.53657291800043
-- (POSIX systems need the double quotes to stop the shell from interpreting 
-- the parentheses.)
-- lua -i -llib -e "x = 10" -- Therefore, the next call will load the lib 
-- library, then execute the assignment x = 10, and finally present a prompt 
-- for interaction.
--[[
Before running its arguments, the interpreter looks for an environment 
variable named LUA_INIT_5_3, or else, if there is no such variable, LUA_INIT. 
If there is one of these variables and its content is @file-name, then the 
interpreter runs the given file. If LUA_INIT_5_3 (or LUA_INIT) is defined but 
it does not start with an at-sign, then the interpreter assumes that it 
contains Lua code and runs it. LUA_INIT gives us great power when configuring 
the stand-alone interpreter, because we have the full power of Lua in the 
configuration. We can preload packages, change the path, define our 
own functions, rename or delete functions, and so on.
--]]

--[[
-- Exercise 1.1 --  stack overflow on 499984 calls of the function
function fuct(n)
    if n == 1 
        then return 1
    else if n < 1 
            then return 
         end
    end
    return n * fuct(n -1)
end

print(fuct(3))
--]]

--[[
-- Exercise 1.5 --
print(type(nil) == nil) --> false  (false == nill)
--]]

-- Exercise 1.6 --
--[[  
 -- Write a simple script that prints its own name without knowing it in 
 -- advance

function printMyName(n)
    print('My name is ', arg[0])
end

printMyName(arg[0])
--]]

-- Numbers --
--[[
print(4)  --> 4 
print(0.4)  --> 0.4
print(4.57e-3) --> 0.00457
print(0.3e12)  --> 300000000000.0
print(5E+20)  --> 5e+20
--]]
--[[
print(type(3))  --> number
print(type(3.5))  --> number
print(type(3.0))  --> number
--]]
--[[
print(1 == 1.0)  --> true
print(-3 == -3.0)  --> true
print(0.2e3 == 200)  --> true
--]]
--[[
print(math.type(3))  --> integer
print(math.type(3.0))  --> float
--]]
--[[
print(3)  --> 3
print(3.0)  --> 3.0
print(1000)  --> 1000
print(1e3) --> 1000.0
--]]
--[[
print(0xff)  --> 255
print(0x1A3)  --> 419
print(0x0.2)  --> 0.125
print(0x1p-1)  --> 0.5
print(0xa.bp2)  --> 42.75
--]]
--[[
print(string.format("%a", 419))  -- 0x1.a3p+8
print(string.format("%a", 0.1))  --  0x1.999999999999ap-4
--]]
--[[
print(13 + 15)  -- 28 For those operations, it does not matter whether the 
                -- operands are integers or floats with integral values
                -- If both operands are integers, the operation gives an integer result;
print(13.0 + 15.0)  -- 28.0
--]]
--[[
-- In case of mixed operands, Lua converts the integer one to a float 
-- before the operation:
print(13.0 + 25)   --> 38.0
print(-(3 * 6.0))  --> -18.0
--]]
--[[
    Division does not follow that rule, because the division of two integers does not need to be an integer.
(In mathematical terms, we say that the integers are not closed under division.) To avoid different results
between division of integers and divisions of floats, division always operates on floats and gives float
results:
]]
--[[
print(3.0 / 2.0)  --> 1.5
print(3 / 2)  --> 1.5
--]]

--[[
    For integer division, Lua 5.3 introduced a new operator, called floor division and denoted by //. As
its name implies, floor division always rounds the quotient towards minus infinity, ensuring an integral
result for all operands. With this definition, this operation can follow the same rule of the other arithmetic
operators: if both operands are integers, the result is an integer; otherwise, the result is a float (with an
integral value):
]]
--[[
print(3 // 2)  --> 1
print(3.0 // 2)  --> 1.0
print(6 // 2) --> 3
print(6.0 // 2.0) --> 3.0
print(-9 // 2) --> -5
print(1.5 // 0.5)  --> 3.0
--]]
-- modulo operator, if both operands are integers, the result is an integer; 
-- otherwise, the result is a float.
-- a % b == a - ((a // b) * b)

--[[
    For real operands, modulo has some unexpected uses. For instance, 
    x - x % 0.01 is x with exactly two decimal digits, and x - x % 0.001 
    is x with exactly three decimal digits:
--]]
--[[
x = math.pi
print(x - x%0.01) --> 3.14
print(x - x%0.001) --> 3.141
--]]
--[[
local tolerance = 10
function isturnback (angle)
    angle = angle % 360
    return (math.abs(angle - 180) < tolerance)
end

print(isturnback(-180))  --> true
--]]
--[[
local tolerance = 0.17
function isturnback (angle)
    angle = angle % (2*math.pi)
    return (math.abs(angle - math.pi) < tolerance)
end

print(isturnback(-180))  --> true
--]]
--[[
Lua also offers an exponentiation operator, denoted by a caret (^). Like division, it always operates on
floats. (Integers are not closed under exponentiation; for instance, 2-2 is not an integer.) We can write
x^0.5 to compute the square root of x and x^(1/3) to compute its cubic root.
--]]

--[[The == operator tests for equality; the ~= operator is the negation of equality. We can apply these opera-
tors to any two values. If the values have different types, Lua considers them not equal. Otherwise, Lua
compares them according to their types.]]
--[[
print(math.sin(math.pi / 2)) --> 1.0
print(math.max(10.4, 7, -3, 20, 25.4)) --> 20
print(math.huge) --> inf
--]]
--[[
print(math.random())
print(math.random(5))
print(math.random(1,3))
--]]
--[[
-- deterministic state of randomness --
print(math.randomseed(1,3))
print(math.random())
--]]

--[[The math library offers three rounding functions: floor, ceil, and modf. Floor rounds towards minus
infinite, ceil rounds towards plus infinite, and modf rounds towards zero. They return an integer result if
it fits in an integer; otherwise, they return a float (with an integral value, of course). The function modf,
besides the rounded value, also returns the fractional part of the number as a second result.]]

--[[
print(math.floor(3.3))  -- 3
print(math.floor(-3.3)) -- -4
print(math.ceil(3.3))   -- 4
print(math.ceil(-3.3))  -- -3
print(math.modf(3.3))   -- 3  0.3
print(math.modf(-3.3))  -- -3 -0.3
print(math.floor(2^70)) --  1.1805916207174e+21
--]]
--[[
If we want to round a number x to the nearest integer, we could compute the floor of x + 0.5. However,
this simple addition can introduce errors when the argument is a large integral value. For instance, consider
the next fragment:]]
--[[
x = 2^52 + 1
print(string.format("%d %d", x, math.floor(x + 0.5))) --> 4503599627370497 4503599627370498


print(x == math.floor(x)) --> true
--]]
--[[
function floor1(x)
    if x == math.floor(x) then
        return x
    else return math.floor(x + 0.5)
    end
end

-- print(floor1(5.5))

function round2(x)
    local f = math.floor(x)
    if (x == f) or (x % 2.0 == 0.5) then
        return f
    else
        return math.floor(x + 0.5)
    end
end

print(round2(2.5))
print(round2(2.0))
print(round2(2.7))
print(round2(4503599627370497))
 --]]
--[[
 -- When we compute an integer operation that would result 
 -- in a value smaller than mininteger or
 -- larger than maxinteger, the result wraps around.
 print(math.maxinteger)  --> 9223372036854775807
 print(math.mininteger)  --> -9223372036854775808
--]]
--[[
print(math.maxinteger + 1 == math.mininteger) --> true
print(math.mininteger - 1 == math.maxinteger) --> true
print(-math.mininteger == math.mininteger) --> true
print(math.mininteger // -1 == math.mininteger) --> true
--]]
--[[
print(math.maxinteger) --> 9223372036854775807
print(0x7fffffffffffffff) --> 9223372036854775807
print(math.mininteger) --> -9223372036854775808
print(0x8000000000000000) --> -9223372036854775808
--]]
--[[
print(math.maxinteger + 2) --> -9223372036854775807
print(math.maxinteger + 2.0) --> 9.2233720368548e+18
print(math.maxinteger + 2.0 == math.maxinteger + 1.0) --> true
--]]

--[[
-- integer to float add 0.0 to integer
print(-3 + 0.0) --> -3.0
print(0x7fffffffffffffff + 0.0) --> 9.2233720368548e+18
--]]
--[[
print(9007199254740991 + 0.0 == 9007199254740991) --> true
print(9007199254740992 + 0.0 == 9007199254740992) --> true
print(9007199254740993 + 0.0 == 9007199254740993) --> false, In the last line, the conversion rounds the integer 253+1 to the float 253, breaking the equality.
--]]
--[[
print(2^53)
print(2^53 | 0)  -- become integer
--]]
--[[Lua does this kind of conversion only when the number has an exact 
representation as an integer, that is,
it has no fractional part and it is inside the range of integers. Otherwise, 
Lua raises an error: --]]
-- print(3.2 | 0) -- fractional part -- stdin:1: number has no integer representation
-- print(2^64 | 0) -- out of range stdin:1: number has no integer representation
-- print(math.random(1, 3.5))
-- stdin:1: bad argument #2 to 'random'
-- (number has no integer representation)

--[[
-- Another way to convert numbers to integers --
print(math.tointeger(-258.0)) --> -258
print(math.tointeger(2^30)) --> 1073741824
print(math.tointeger(5.01)) --> nil
print(math.tointeger(2^64)) --> nil
--]]
--[[s
-- check if a number can be converted to integer --
function cond2int (x)
    return math.tointeger(x) or x
end

print(cond2int(2^64)) --> 1.844674407371e+19
--]]

-- Exercise 3.1 --
-- print(.0e12) --> 0.0
-- print(.e12)  --> wrong
-- print(0x) --> wrong
-- print(0x1P10) --> wrong
-- print(0.0e) --> wrong
-- print(0.1e1)  --> 1.0
-- print(0x12) --> 0x12 = 18
-- print(0xABFG)  --> wrong
-- print(0x0.1p1)  --> 0.125
--  print(0xA) --> 10
-- print(FFFF)  --> nill, treats FFFF as variable 
--  print(0xFFFFFFFF) -->4294967295

-- Exercise 3.2 --
-- print(math.maxinteger * 2)  --> -2, This behavior is a consequence of how integer overflow is handled 
-- in Lua and many other programming languages that use two's complement representation for integers.
-- it overflows to the min integer on two complement value 
-- print(math.mininteger * 2) --> 0 The result wraps around to 0, as the range of representable integers is 
-- finite, and doubling the most negative integer pushes it beyond the positive limit, causing it to 
-- "wrap" back to 0.
-- print(math.maxinteger * math.maxinteger) --> 1, Due to overflow, the result wraps around within the range
-- of representable integers. The specific value 1 is obtained because of the wrapping behavior.
-- print(math.mininteger * math.mininteger) --> 0, In essence, mathematically, the product of the most negative 
-- integer by itself is a positive value, but due to the constraints of fixed-size integer representation in 
-- computer memory, overflow occurs, and the result wraps around to 0. This behavior is a consequence of the 
-- limitations of representing infinitely large or small mathematical values with a finite number of bits.
--[[
for i = -10, 10 do
    print(i, i % 3)
end
--]]
-- Exercise 3.3 --
--[[
for i = -5,5 do
    print(i, i % 3)
end
--]]
-- Exercise 3.4 --
-- print(2^3^4)  -- > 2.4178516392293e+24
-- print(2^-3^4)  -- > 4.1359030627651e-25

--[[
-- Exercise 3.5 --: 

function fraction(x)
    return (math.log(10, math.exp(1)) / math.log(2, math.exp(1)))  
end

print(fraction(12.7))  --> 3.3219280948874
print(fraction(5.5))   --> 3.3219280948874
--]]
--[[
function coneVolume(height, angle)
    -- Convert angle to radians
    local radianAngle = math.rad(angle)

    -- Calculate radius
    local radius = height * math.tan(radianAngle)

    -- Calculate volume
    local volume = (1/3) * math.pi * radius^2 * height

    return volume
end

-- Example usage
local height = 10
local angle = 30  -- Assuming the angle is given in degrees

local result = coneVolume(height, angle)
print("The volume of the cone is:", result)  -->  The volume of the cone is:      349.06585039887
--]]
--[[
-- Box-Muller transform to generate a standard normal random number
function standardNormalRandom()
    -- Generate two independent random numbers with a uniform distribution in (0, 1)
    local u1 = math.random()
    local u2 = math.random()
    print (u1, u2)
    -- Box-Muller transform
    local z0 = math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2)

    return z0
end

-- Example usage
for i = 1, 10 do
    local randomValue = standardNormalRandom()
    print("Random value with standard normal distribution:", randomValue)
end
--]]
--[[
-- Strings --
a = "one string"
b = string.gsub(a, "one", "another")
print(a)
print(b)
--]]
--[[
a = "hello"
print(#a)
print(#"good bye")
--]]
-- print("Hello" .. "World")

-- Strings are Immutable objects in lua --
--[[
a = "Hello"
print(a .. "World")
print(a)
--]]

-- print("one line\nnext line\n\"in quotes\", 'in quotes'")
--[[
    one line
    next line
    "in quotes", 'in quotes'    
--]]
--[[
print('a backslash inside quotes: \'\\\'')
-- a backslash inside quotes: '\'

print("a simpler way: '\\'")
-- a simpler way: '\'
--]]
--[==[
print("ALO\n123\"")
--[[ 
     ALO
     123" 
--]]
print('\x41LO\10\04923"')
--[[ 
     ALO
     123" 
--]]
print('\x41\x4c\x4f\x0a\x31\x32\x33\x22')
--[[ 
     ALO
     123" 
--]]
--]==]
-- print("\u{3b1} \u{3b2} \u{3b3}") --> α β γ
--[=[
page = [[
<html>
<head>
<title>An HTML Page</title>
</head>
<body>
<a href="http://www.lua.org">Lua</a>
</body>
</html>
]]

print(page)
--]=]
--[[
data = "\x30\x31\x32\x33\x34\x35\z
        \x36\x37\x38\x39"
print(data)
--]]

-- Coersions(εξαηανγκασμοι) --
-- String becomes numbers, numbers becomes Strings
--[==[
a = "Kostas"
b= "Dimos"
print(a..b) --> KostasDimos

a = 10
b = 7
print(a..b)  --> 107
print(a .. b)  --> 107

a = "Kostas"
b = 7
print(a..b) --> Kostas7
--]==]
--[[
print(10 + 7)  --> 17
print("10" + 7)  --> 17
--]]
--[==[
print(tonumber(" -3 ")) --> -3
print(tonumber(" 10e4 "))    --> 100000.0
print(tonumber("10e"))       --> nil
print(tonumber("0x1.3p-4"))  --> 0.07421875
--]==]
--[==[
 -- string --> number, tonumber assumes decimal conversion, tonumber(number, base) --
print(tonumber("100101", 2))  --> 37
print(tonumber("fff", 16))    --> 4095
print(tonumber("-ZZ", 36))    --> -1295
print(tonumber("987", 8))     --> nil

--number-->tostring 
print(tostring(10) == "10") --> true
--]==]
-- print(2 < "15")  -- attempt to compare number with string 
--[==[ 
s = "Kostas"
-- print(#s == string.len(s))  --> true
print(string.rep(s, 4)) -- KostasKostasKostasKostas
print(s:rep(4))  -- KostasKostasKostasKostas
print(string.reverse(s)) -- satsoK
print(s:reverse(s))  -- satsoK
print(string.lower(s))  -- kostas
print(s:lower(s))  -- kostas
print(string.upper(s)) -- KOSTAS
print(s:upper(s))  -- KOSTAS
print(string.sub(s, 1, 4)) -- Kost
print(s:sub(1, 4))  -- Kost
print(string.sub(s, 1, -2)) -- Kosta  prefix
print(string.sub(s, 2, -2))  -- osta suffix
--]==]
--[==[
s = "[in brackets]"  
print(string.sub(s, 2, -2))  --> in brackets
print(string.sub(s, 1, 1)) --> [
print(string.sub(s, -1, -1)) --> ]
--]==]
--[[
s = "Kostas"
s = string.sub(s, 2, -2)
print(s)
--]]
--[[
print(string.char(65, 66))  --> AB
print(string.char())  --> returns an empty string
print(string.byte('ABCD', 1, 3))   --> 65      66      67
--]]
--[==[
print(string.char(97)) --> a 
i = 99; print(string.char(i, i+1, i+2))  --> cde
print(string.byte("abc")) --> 97
print(string.byte("abc", 2))  --> 98
print(string.byte("abc", -1))  --> 99
--]==]

-- which creates a list with the codes of all characters in s
-- (This idiom only works for strings somewhat shorter than 1 MB).
-- Lua limits its stack size, which in turn limits the maximum number 
-- of returns from a function. The default stack limit is one million 
-- entries.
--[[
s = "Kostas"
print(string.byte(s, 1, -1))  --> 75      111     115     116     97      115
--]]
-- string.format() converts number to strings --
-- d for a decimal integer, x for hexadecimal, 
-- f for a floating-point number, s for strings, plus several others. --
--[==[
print(string.format("x = %d y = %d", 10, 20)) --> x = 10 y = 20
print(string.format("x = %x", 200)) --> x = c8
print(string.format("x = 0x%X", 200)) --> x = 0xC8
print(string.format("x = %f", 200)) --> x = 200.000000
tag, title = "h1", "a title"
print(string.format("<%s>%s</%s>", tag, title, tag)) --> <h1>a title</h1>
--]==]
--[[
print(string.format("pi = %.4f", math.pi)) --> pi = 3.1416
d = 5; m = 11; y = 1990
print(string.format("%02d/%02d/%04d", d, m, y)) --> 05/11/1990
print(string.format("%2d/%2d/%4d", d, m, y))  -->  5/11/1990
--]]
--[[
-- regexp --
print(string.find("hello world", "wor")) --> 7  9
print(string.find("hello world", "war")) --> nil
--]]
--[[
print(string.gsub("hello world", "l", "."))  --> he..o wor.d   3
print(string.gsub("hello world", "ll", ".."))  --> he..o world   1
print(string.gsub("hello world", "a", "."))   --> hello world     0
--]]
--[[
x = string.gsub("hello world", "(%w+)", "%1 %1") --> x = "hello hello world world"
print(x)

x = string.gsub("hello world", "%w+", "%0 %0", 1)  --> x = "hello hello world"
print(x)

x = string.gsub("hello world from Lua", "(%w+)%s*(%w+)", "%2 %1")  --> x="world hello Lua from"
print(x)

x = string.gsub("home = $HOME, user = $USER", "%$(%w+)", os.getenv) --> home = /home/konstantinos, user = konstantinos
print(x)

x = string.gsub("4+5 = $return 4+5$", "%$(.-)%$", function (s)  --> x="4+5 = 9"
                                                    return load(s)()
                                                  end)
     
local t = {name="lua", version="5.4"}
x = string.gsub("$name-$version.tar.gz", "%$(%w+)", t) --> x="lua-5.4.tar.gz"
print(x)
--]]

-- String order operators (less than, less equal, etc.) compare UTF-8 strings
-- following the order of their character codes in Unicode
-- The functions reverse, upper, lower, byte, and char do not work for UTF-8 
-- strings, as all of them assume that one character is equivalent to one byte.

-- The functions string.format and string.rep work without problems
-- with UTF-8 strings except for the format option '%c', which assumes 
-- that one character is one byte.
--[[
-- The functions string.len and string.sub work correctly with UTF-8 strings, 
-- with indices referring to byte counts (not character counts)
print(utf8.len("résumé")) --> 6
print(utf8.len("ação"))  --> 4
print(utf8.len("Månen"))  --> 5
print(utf8.len("abc9\x93"))  --> nil  5->position of the first invalid byte
--]]
--[==[
-- utf8.char => string.byte(), utf8.codepoint => string.byte()
print(utf8.char(114, 233, 115, 117, 109, 233)) --> résumé
print(utf8.codepoint("résumé", 6, 7)) --> 109 233
-- codepoint has indices indicate the byte , not the position

-- convert poisition to byte indice into a string
print(utf8.offset("résumé", 3, 1)) --> get the byte on 3rd position of the résumé string
print(utf8.codepoint("résumé", utf8.offset("résumé", 3, 1))) --> calculate the codepoint at
-- 3rd position starting from 1st position on résumé string
print(utf8.char(utf8.codepoint("résumé", utf8.offset("résumé", 3, 1)))) --> calculate the 115 codepoint character = "s"
--]]
--]==]
--[[
s = "Nähdään"
print(utf8.codepoint(s, utf8.offset(s, 5)))  --> 228  30
print(utf8.char(228))  --> ä
--]]
--[[
s = "ÃøÆËÐ"
print(string.sub(s, utf8.offset(s, -2))) --> ËÐ
print(string.sub(s, -2)) --> Ð  , it needs byte indices to work well on utf8
--]]
--[[
-- The last function in the utf8 library is utf8.codes. It allows us to iterate 
-- over the characters in a UTF-8 string:
--> bytes encoding
--> 1       65
--> 2       231
--> 4       227
--> 6       111      
for i, c in utf8.codes("Ação") do
    print(i, c)
end

print(utf8.offset("Ação", 4, 1))  --> 6
--]]
--[[
print(("\u{E9}"))  --> é
print("e\u{301}")  --> é
--]]
--[==[
-- Exercise 4.1 --
data = [=[<![CDATA[
Hello world
]]>]=]

print(data)

data = "<![CDATA[\nHello world\n]]>"
print(data)
--]==]
--[[
-- Exercise 4.2 --
data = "\x31\x32\x33\x34\x35\z
\x36\x37\x38"
print(data)
--]]
--[[
-- Exercise 4.3 --
function insert(s, pos, replc)
    -- match_data = string.match(s, "(%w+)", pos)
    -- print(match_data)
    -- data = string.gsub(s, match_data, replc)
    -- return data
    data_suffix = string.sub(s, pos); -- suffix
    data_prefix = string.sub(s, 1, pos-1); -- prefix
    data = data_prefix .. replc .. data_suffix
    return data    
end
--]]
-- print(insert("hello world", 1, "start: ")) --> start: hello world
-- print(insert("hello world", 7, "small ")) --> hello small world

--[[
-- Exercise 4.4: Redo the previous exercise for UTF-8 strings: --

function insert_utf8(s, pos, replc)
    data_suffix = string.sub(s, utf8.offset(s, pos, 1)); -- suffix
    data_prefix = string.sub(s, 1, utf8.offset(s, pos-1, 1)); -- prefix
    data = data_prefix .. replc .. data_suffix
    return data    
end

print(insert_utf8("ação", 5, "!")) --> ação! 31
print(insert_utf8("Nähdään", 5, "!")) --> Nähd!ään
--]]
--[[
-- Exercise 4.5: Write a function to remove a slice from a string; 
-- the slice should be given by its initial position and its length:

function remove(s, start, plently)
    prefix = s:sub(1, start - 1)
    suffix = s:sub(start + plently, #s)
    return prefix .. " " .. suffix
end

print(remove("hello world", 7, 4)) --> hello d 
--]]
--[[
-- Exercise 4.6: Redo the previous exercise for UTF-8 
-- strings:
function remove_utf8(s, start, plently)
    prefix = s:sub(1, utf8.offset(s, start - 1))
    suffix = s:sub(utf8.offset(s, start + plently), #s)
    return prefix .. suffix
end

print(remove_utf8("ação", 2, 2))  --> ao
--]]
--[[
-- Exercise 4.7: Write a function to check whether a given 
-- string is a palindrome:
function ispali(s)
    s = string.gsub(s,"[%s+%-_]",'')
    return s == string.reverse(s)
end   
--]]
--print(ispali("step on no pets"))  --> true
--print(ispali("banana"))  --> false
--print(ispali("bananab"))  --> true
--print(ispali("step on no  pets"))  --> true
--[[
function ispali_utf8(s)
    tmp = {}
    flg = true
    j = 1
    for i, n in utf8.codes(s) do
        tmp[j] = n
        -- print(tmp[j])
        j = j + 1
    end
    -- print(#tmp)
    for i = 1, #tmp // 2 do
        if tmp[i] ~= tmp[#tmp - i + 1] then
            -- print(i, tmp[i], tmp[#tmp - i + 1])
            flg = false
            break
        end
    end 
    return flg
end   

--print(ispali("step on no pets"))  --> true
--print(ispali("banana"))  --> false
--print(ispali("bananab"))  --> true
--print(ispali("step on no  pets"))  --> true

print(ispali_utf8("açãça"))  --> true
print(ispali_utf8("açãoãça"))  --> true
print(ispali_utf8("açãoã!ça"))  --> false
--]]

-- A table in Lua is essentially an associative array. 
-- A table is an array that accepts not only numbers as
-- indices, but also strings or any other value of the language 
-- (except nil).
--[[
a = {} -- create a table and assign its reference
k = "x"
a[k] = 10 -- new entry, with key="x" and value=10
a[20] = "great" -- new entry, with key=20 and value="great"
print(a["x"]) --> 10
k = 20
print(a[k]) --> "great"
a["x"] = a["x"] + 1 -- increments entry "x"
print(a["x"]) --> 11
--]]
--[[
a = {}
a["x"] = 10
b = a  -- 'b' refers to the same table as 'a'
print(b["x"]) --> 10
b["x"] = 20 --> 20
print(a["x"])
a = nil  -- only 'b' still refers to the table
print(a)  --> nil
b = nil -- no references left to the table
print(b)  --> nil
--]]
--[[
a = {}  -- empty table
-- create 1000 new entries
for i = 1, 1000 do a[i] = i*2 end
print(a[9]) --> 18
a["x"] = 10
print(a["x"])  --> 10
print(a["y"])  --> nil
--]]

-- Note the last line: like global variables, table fields 
-- evaluate to nil when not initialized. Also like global
-- variables, we can assign nil to a table field to delete it. 
-- This is not a coincidence: Lua stores global variables
-- in ordinary tables. (We will discuss this subject further 
-- in Chapter 22, The Environment.)
--[[
a = {}  -- empty table
a.x = 10  -- same as a["x"] = 10
print(a.x)  -- same as a["x"]   --> 10
print(a.y)  -- same as a["y"]   --> nil
--]]

-- a.x with a[x]. The first form represents a["x"], that
-- is, a table indexed by the string "x". The second form 
-- is a table indexed by the value of the variable x.
--[[
a = {}
x = "y"
a[x] = 10
print(a[x]) --> 10
print(a.x) --> nil,  value of field "x" (undefined)
print(a.y) --> 10
--]]
--[[
i = 10; j = "10"; k = "+10"
a = {}
a[i] = "number key"
a[j] = "string key"
a[k] = "another string key"
print(a[i])  --> number key
print(a[j])  --> string key
print(a[k])  --> another string key
print(a[tonumber(j)])  --> number key
print(tonumber(k))  --> 10
print(a[tonumber(k)])  --> number key
--]]
--[[
a = {}
a[2.0] = 10
a[2.1] = 20
--any float value that can be converted to an integer is converted.
print(a[2])  --> 10
print(a[2.1])  --> 20
--]]
--[[
days = {"Sunday", "Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday"}
print(days[4])  --> Wednesday
--Lua also offers a special syntax to initialize a 
-- record-like table, as in the next example:
a = {x = 10, y = 20}
-- This previous line is equivalent to these commands:
a = {}; a.x = 10; a.y = 20
-- The original expression, however, is faster, because 
-- Lua creates the table already with the right size.
--]]
--[[
w = {x = 0, y = 0, label = "console"}
x = {math.sin(0), math.sin(1), math.sin(2)}
w[1] = "another field" -- add key 1 to table 'w'

x.f = w -- add key "f" to table 'x'
print(w["x"]) --> 0
print(w[1]) --> another field
print(x.f[1]) --> another field
w.x = nil -- remove field "x"
--]]
--[[
polyline = {
                color="blue",
                thickness=2,
                npoints=4,
                {x = 0, y = 0},  -- polyline[1]
                {x = -10, y = 0},-- polyline[2]
                {x = -10, y = 1},-- polyline[3]
                {x = 0, y = 1}   -- polyline[4]
            }

print(polyline[1].x, polyline[1].y)  --> 0   0
print(polyline[2].y)  -->  0
print(polyline[4].y)  -->  1
--]]
--[[
opnames = {["+"] = "add", ["-"] = "sub",
           ["*"] = "mul", ["/"] = "div"}
i = 20; s = "-"
a = {[i+0] = s, [i+1] = s..s, [i+2] = s..s..s}
print(opnames[s]) --> sub
print(a[22])  --> ---
--]]
--[[
{x = 0, y = 0} --> {["x"] = 0, ["y"] = 0}
{"r", "g", "b"}  --> {[1] = "r", [2] = "g", [3] = "b"}

a = {[1] = "red", [2] = "green", [3] = "blue",}
-- This flexibility frees programs that generate Lua constructors 
-- from the need to handle the last element as a special case.
--]]
--[[
-- read 10 lines, storing them in a table
a = {}
for i = 1, 10 do
    a[i] = io.read()
end


--This technique only works when the list does not have holes, 
-- which are nil elements inside it. We call such a list without 
-- holes a sequence.
-- print the lines, from 1 to #a
for i = 1, #a do
    print(a[i])
end
--]]
--[[
-- a[#a + 1] = v -- appends 'v' to the end of the sequence
-- Remember that any key with value nil is actually not in the table.) 
-- In particular, a table with no numeric keys is a sequence with length zero.
b = {}
b["x"] = 1
b["y"] = 2
print(#b)  --> 0
--]]
--[[
    a = {}
a[1] = 1
a[2] = nil
a[3] = 1
a[4] = 1
-- does nothing, as a[2] is already nil
It is easy to say that the length of this list is four, and that is has a hole at index 2. However, what can
we say about the next similar example?
a = {}
a[1] = 1
a[10000] = 1
Should we consider a as a list with 10000 elements, with 9998 holes? Now, the program does this:
a[10000] = nil
What is the list length now? Should it be 9999, because the program deleted the last element? Or maybe
still 10000, as the program only changed the last element to nil? Or should the length collapse to one?
Another common proposal is to make the # operator return the total number of elements in the table. This
semantics is clear and well defined, but not very useful or intuitive. Consider all the examples we are
discussing here and think how useful would be such operator for them.
Yet more troubling are nils at the end of the list. What should be the length of the following list?
a = {10, 20, 30, nil, nil}
Remember that, for Lua, a field with nil is indistinct from an absent field. Therefore, the previous table
is equal to {10, 20, 30}; its length is 3, not 5.
]]
--[[
-- table --
t = {10, print, x = 12, k = "hi"}
for k, v in pairs(t) do
    print(k, v)
end

--> 1 10
--> 2 function: 0x420610
--> k hi
--> x 12
--]]
--[[
-- lists -- has only arithmetic indexes --
t = {10, print, 12, "hi"}
for i, v in ipairs(t) do
    print(i,v)
end
--]]
--[[
t = {10, print, 12, "hi"}
for k = 1, #t do
    print(k, t[k])
end
--> 1  10
--> 2  function: 0x420610
--> 3  12
--> 4  hi
--]]
--[==[
-- check the nested tables if they exist like
-- zip = company?.director?.address?.zipcode
-- zip = (((company or {}).director or {}).address or {}).zipcode
E = {}
-- can be reused in other similar expressions
zip = (((company or E).director or E).address or E).zipcode
--[[
Granted, this syntax is more complex than the one with the safe navigation operator. Nevertheless, we
write each field name only once, it performs the minimum required number of table accesses (three, in this
example), and it requires no new operators in the language. In my personal opinion, it is a good enough
substitute.
--]==]
--[[
t = {}
for line in io.lines() do
    table.insert(t, line)
end
print(#t)  --> (number of lines read)
--]]
--[[
a = {1, 2, 3, 4}

function insert_into_table(a)
    table.insert(a, 1, 5)
end

function remove_from_table(a)
    table.remove(a, 1)
end

function print_table(a)
    for i = 1, #a do
        print(a[i])
    end
end

insert_into_table(a)
print_table(a)
print()
remove_from_table(a)
print_table(a)
--]]

-- a = {1, 2, 3, 4}
--[[
table.move(a, 1, #a, 2)
a[1] = "newElement"

for i, v in ipairs(a) do
    print(i, v)
end

print()

table.move(a, 2, #a, 1)
a[#a] = nil

for i, v in ipairs(a) do
    print(i, v)
end
--]]
--[[
c = {}
c = table.move(a, 1, #a, 1, {})
for i = 1, #c do
    print(c[i])
end

print()

b = {6, 6, 6}
d = {}
d = table.move(a, 1, #a, #b + 1, b)
for i = 1, #d do
    print(d[i])
end
--]]

-- Exercise 5.1 --
--[[
a.x = a["x"]
a[x] a = { x = ...}
--]]
-- print(t.sunday, t[sunday], t[t.sunday])
-- sunday = "monday"; monday = "sunday"
-- t = {sunday = "monday", [sunday] = monday} -- monday sunday sunday
-- t = {"monday" = "monday, ["monday"] = "sunday"}
--[[
print(t.sunday == t["sunday"])  -- true
print(t.sunday == "monday") -- true
--]]
--[[
print(t[sunday] == "monday") -- false
print(t["monday"] == t[sunday]) -- true
print(t["monday"] == t.monday) -- true
print(t.monday == "sunday")  -- true
--]]
--[==[
print(t[t.sunday] == t[t["sunday"]])
print(t["monday"] == "sunday")
--]==]
--[[
-- Exercise 5.2 --
a = {1, 2}
a.a = a
print(a.a == a) -- true
a.a.a = a
print(a.a.a == a) -- true
a.a.a.a = a
print(a.a.a.a == a) -- true

a.a.a.a = 3
print(a.a.a.a) -- attempt to index a number value (field 'a')
               -- cause a.a.a.a is a table field
--]]
--[[
-- Exercise 5.4 --
function createEscapeSequenceTable()
    local escapeTable = {
        ["\\a"] = "bell",
        ["\\b"] = "backspace",
        ["\\f"] = "form feed",
        ["\\n"] = "newline",
        ["\\r"] = "carriage return",
        ["\\t"] = "tab",
        ["\\v"] = "vertical tab",
        ["\\'"] = "single quote",
        ['\\"'] = "double quote",
        ["\\\\"] = "backslash",
    }
    return escapeTable
end

-- Example usage
local escapeTable = createEscapeSequenceTable()

-- Accessing values in the table
print(escapeTable["\\n"])  -- Output: newline
print(escapeTable["\\t"])  -- Output: tab
--]]

--[[
-- Exercise 5.4 --
function polynomial1(a, x)
    res = 0
    for i = #a, 1, -1 do
        res = res + a[i] *(x ^ i)
    end
    return res
end

a = {1, 2, 3, 4}
x = 2
print(polynomial1(a, x)) -- 98.0 
--]]
--[[
-- Exercise 5.5 --
function polynomial2(a, x)
    res = 0
    y = x
    for i = 1, #a do
        res = res + a[i] * y
        y = y * x
    end
    return res
end

a = {1, 2, 3, 4}
x = 2
print(polynomial2(a, x)) -- 98.0 
--]]
--[[
-- Exercise 5.6 --
function test_correct_sequence(a)
    for i = 1, #a do
        if a[i] == nil then return false end
    end
    return true
end

print(test_correct_sequence({1,2,3,nil,5,6}))
--]]
--[[
-- Exercise 5.7 --

function move_elements_from_list_to_list(a, pos1, pos2, pos3, b)
    return table.move(a, pos1, pos2, pos3, b)
end

tmp = move_elements_from_list_to_list({1,2,3,4,5,6}, 2, 4, 4, {5,5,5})

for i = 1, #tmp do
    print(tmp[i])
end
--]]
--[[
-- Exercise 5.8 --
function my_concat_implementation (a)
    res = ''
    for i = 1, #a do
        res = res .. a[i]
    end  
    return res
end

print(my_concat_implementation({"hello"," ","kostas"}))

function produce_big_data()
    for i = 1, 10000 do
        res = res .. "kostas"
    end
    return {res}
end

a = {}
a = produce_big_data()
--]]
--[[
print(os.clock())
print(table.concat(a, ' ',#a))
print(os.clock())
--]]
--[[
my_res = ''
for i = 1, #a do
    my_res = my_res .. a[i]
end

data = ''

print(os.clock())
data = my_concat_implementation({my_res, ' ', my_res})
fp = io.open('test.txt', 'a')
fp:write(data)
fp:close()
print(os.clock())
--]]
--[==[
-- Functions --
function f(a)
end

function type(a)
end

print "Hello World" --> print("Hello World")
dofile 'a.lua' --> dofile ('a.lua')
print [[a multi-line 
message]]  --> print([[a multi-line
--                     message]])
f{x=10, y=20} --> f({x=10, y=20})
type{}  --> type({})
--]==]
--[[
-- A function Paradigm --
-- add the elements of sequence 'a'
function add (a)
    local sum = 0
    for i = 1, #a do
        sum = sum + a[i]
    end
    return sum
end
--]]
--[[
function f1(a, b) print(a, b) end

f1() --> nil nil 
f1(3) --> 3 nil 
f1(3, 4)  --> 3, 4
f1(3, 4, 5) --> 3 4 (5->discarded)
--]]
--[[
global_increment = 1

function incrementCounter(n)
    n = n or 1
    global_increment = global_increment + n
    return global_increment
end

print(incrementCounter()) --> 2
print(global_increment(3)) --> 4
--]]
--[[
s, e = string.find("hello Lua users", "Lua")
print(s, e) --> 7 9
--]]
--[[
function findmaximum(a)
    mi = 1
    m = a[mi]
    for i = 1, #a do
        if m < a[i] then 
            mi = i
            m = a[i]
        end
    end
    return m, mi
end

a, b = findmaximum({1, 8, 5, 6, 7})
print(a, b)
--]]

-- These lists appear in four constructions in Lua:
-- multiple assignments, arguments to function calls, 
-- table constructors, 
-- and return statements.
--[[
function foo0 () end -- returns no results
function foo1 () return "a" end -- returns 1 result
function foo2 () return "a", "b" end -- returns 2 results
--]]
--[==[
x, y = foo2() -- x="a", y="b"
print(x, y)
x = foo2() -- x = "a", y = discarded
print(x)
x, y, z = 10, foo2() -- x = 10, y = "a", z = "b"
print(x, y, z)
--]==]
--[[
-- In a multiple assignment, if a function has fewer results 
-- than we need, Lua produces nils for the missing values:
x, y = foo0() -- x = nil, y = nil
x, y = foo1() -- x = "a", y = nil
x, y, z = foo2() -- x = "a", y = "b", z = nil

-- Remember that multiple results only happen when the call is the 
-- last (or only) expression in a list. A
-- function call that is not the last element in the list always 
-- produces exactly one result:
x, y = foo2(), 20 -- x = "a", y = 20 ('b' discarded)
x, y = foo0(), 20, 30 -- x = nil, y = 20 (30 is discarded)
--]]
--[==[
-- When a function call is the last (or the only) argument to 
-- another call, all results from the first call go as
-- arguments. We saw examples of this construction already, 
-- with print. Because print can receive a variable number of 
-- arguments, the statement print(g()) prints all results returned 
-- by g.
print(foo0())  -->
print(foo1())  --> a
print(foo2())  --> a b
print(foo2(), 1) --> a 1 (b is discarded)
print(foo2() .. "x") --> ax (b is discarded)
--]==]
--[[
t = {foo0()} -- t = {} (an empty table)
print(#t) -- 0
t = {foo1()} -- t = {"a"}
print(#t, t[1])  -- 1 a
t = {foo2()} -- t = {"a", "b"}
print(#t, t[1], t[2]) -- 2 a b 
--]]
--[==[
-- As always, this behavior happens only when the call is the 
-- last expression in the list; calls in any other
-- position produce exactly one result:

t = {foo0(), foo2(), 4}  -- t[1] = nil, t[2] = "a", t[3] = 4
print(#t, t[1], t[2], t[3])  -- 3       nil     a       4
--]==]
--[==[
function foo (i)
    if i == 0 then return foo0()
        elseif i == 1 then return foo1()
        elseif i == 2 then return foo2()
    end
end

print(foo(0))  --> no results
print(foo(1))  --> a
print(foo(2)) --> a b
print(foo(3)) --> no results
--]==]
-- We can force a call to return exactly one result by 
-- enclosing it in an extra pair of parentheses:
--[[
print((foo0())) --> nil
print((foo1())) --> a
print((foo2())) --> a
--]]
-- Beware that a return statement does not need parentheses around the returned value; 
-- any pair of parentheses placed there counts as an extra pair. Therefore, a statement 
-- like return (f(x)) always returns one single value, no matter how many values f returns. 
-- Sometimes this is what we want, sometimes not.
--[[
    -- Vararg Functions --
function add (...)
    local s = 0
    for _, v in ipairs{...} do
        s = s + v
    end
    return s
end

print(add(3, 4, 10, 25, 12)) --> 54
--]]
--[==[
local a, b = ... --( takes only the two first arguments) --
function foo (a, b, c)
end
-- or --
function foo (...)
    local a, b, c = ...
end
--]==]
--[[
function id (...) return ... end

for _, v in ipairs{id(1, 2, 3)} do
    print(v)
end
--]]

-- This is a useful trick for 
-- tracing calls to a specific function.
--[[ 
function foo4(...)
    print("calling foo from foo4():", ...)
end

function foo5 (...)
    print("calling foo from foo5():", ...)
    return foo4(...)
end

foo5(1, 2, 3, 4, 5)
--]]
--[==[
function fwrite1 (fmt, ...)
    return io.write(string.format(fmt, ...))
end

fwrite1("The values are %d %d %d\n", 4, 5, 6) -- The values are 4 5 6

function fwrite2(fmt, ...)
    return io.write(string.format(fmt, ...))
end

fwrite2(22, 10, 33, 44) -- 22
--]==]
--[==[
function nonils (...)
    local arg = table.pack(...)
    for i = 1, arg.n do
        if arg[i] == nil then return false, arg.n end
    end
    return true, arg.n
end

print(nonils(2,3,nil)) --> false 3
print(nonils(2,3)) --> true 2
print(nonils()) --> true 0
print(nonils(nil)) --> false 1
--]==]
--[[
print(select(1, "a", "b", "c")) --> a b c
print(select(2, "a", "b", "c")) --> b c
print(select(3, "a", "b", "c")) --> c 
print(select("#", "a", "b", "c")) --> 3
print(select("#", "a", "b", ...))  --> 2
print(select("#", ... ))  --> 0
--]]

--[==[
For few arguments, this second version of add is faster, 
because it avoids the creation of a new table at each call. 
For more arguments, however, the cost of multiple calls to 
select with many arguments outperforms the cost of creating 
a table, so the first version becomes a better choice. (In 
particular, the second version has a quadratic cost, because 
both the number of iterations and the number of arguments
passed in each iteration grow with the number of arguments.)    
--]==]
--[==[
function add1 (...)
    local s = 0
    for i = 1, select("#", ...) do
        s = s + select(i, ...)
    end
    return s
end

print(add1(1, 2, 3))
--]==]
--[[
print(table.unpack{10,20,30}) --> 10 20 30
a,b = table.unpack{10,20,30}  -- a = 10, b = 20, 30 is discarded
--]]
--[[
An important use for unpack is in a generic call mechanism. 
A generic call mechanism allows us to call any function, with 
any arguments, dynamically. In ISO C, for instance, there is no 
way to code a generic call. We can declare a function that takes
a variable number of arguments (with stdarg.h) and we can call a 
variable function, using pointers to functions. However, we 
cannot call a function with a variable number of arguments: each 
call you write in C has a fixed number of arguments, and each 
argument has a fixed type. In Lua, if we want to call a 
variable function f with variable arguments in an array a, we
simply write this:
--]]
--[[
-- f(table.unpack(a))
print(string.find("Hello", "ll"))  --> 3       4

f = string.find
a = {"Hello", "ll"}
print(f(table.unpack(a)))  --> 3       4
--]]

--[[
Usually, table.unpack uses the length operator to know how 
many elements to return, so it works only on proper sequences. 
If needed, however, we can provide explicit limits:
--]]
--[==[
print(table.unpack({"Sun", "Mon", "Tue", "Wed"}, 2, 3)) --> Mon Tue

function unpack (t, i, n)
    i = i or 1
    n = n or #t
    if i <= n then
        return t[i], unpack(t, i + 1, n)
    end
end
 
print(unpack({"Sun", "Mon", "Tue", "Wed"}, 2, 3)) --> Mon Tue
--]==]
-- Lua do tail-call elimination from the stack where functions 
-- are stored This means that Lua is properly tail recursive, 
-- although the concept does not involve recursion directly; 
-- see Exercise 6.6.)
--[==[
    After f calls g, it has nothing else to do. In such situations, the program does not need to return to the
calling function when the called function ends. Therefore, after the tail call, the program does not need to
keep any information about the calling function on the stack. When g returns, control can return directly to
the point that called f. Some language implementations, such as the Lua interpreter, take advantage of this
fact and actually do not use any extra stack space when doing a tail call. We say that these implementations
do tail-call elimination.
--]==]
--[[
function foo6 (n)
    if n > 0 then return foo6(n - 1) end
end

foo6(100000)
--]]
--[[
It will never overflow the stack.
A subtle point about tail-call elimination is what is a tail call. Some apparently obvious candidates fail
the criterion that the calling function has nothing else to do after the call. For instance, in the following
code, the call to g is not a tail call:
--]]

-- The problem in this example is that, after calling g, 
-- f still has to discard any results from g before returning. --
--[[
function f (x)
    g(x)
end
--]]
--[==[
return g(x) + 1  -- must do the addition
return x or g(x) -- must adjust to 1 result
return (g(x))    -- must adjust to 1 result

-- In Lua, only a call with the form return func(args) 
-- is a tail call. However, both func and its
-- arguments can be complex expressions, because Lua evaluates 
-- them before the call. For instance, the next call is a tail 
-- call:
return x[i].foo(x[j] + a*b, i + j)
--]==]
--[==[
-- Exercise 6.2 --
function return_all_values_except_first_one(...)
    a = {}
    cnt = 1
    for _,v in ipairs{...} do
        if cnt ~= 1 then 
            table.insert(a, v)
        end
        cnt = cnt + 1
    end
    return a
end

a = {}
a = return_all_values_except_first_one(1, 2, 3, 4, 5, 6)
for i = 1, #a do
    print(a[i])
end
--]==]
--[==[
-- Exercise 6.3 --
function return_all_values_except_last_one(...)
    a = {}
    cnt = 1
    for _,v in ipairs{...} do
        if cnt ~= select("#", ...) then 
            table.insert(a, v)
        end
        cnt = cnt + 1
    end
    return a
end

a = {}
a = return_all_values_except_last_one(1, 2, 3, 4, 5, 6)
for i = 1, #a do
    print(a[i])
end
--]==]

--[[
local my_t = {a = 5}
print(my_t.a)  --> 5
print(my_t["a"]) --> 5
print(my_t[a])  --> nil
--]]

-- io.read() --> read from the stdin
-- io.output() --> write to the stdout
-- io.input() --> change the stream input
-- io.output() --> change the stream output
-- A call like io.input(filename) opens a stream 
-- over the given file in read mode and sets it as 
-- the current input stream.
-- Because we can call it with multiple arguments, we should 
-- avoid calls like io.write(a..b..c); the call io.write(a, b, c) 
-- accomplishes the same effect with fewer resources, as it avoids 
-- the concatenations.
-- Unlike print, write adds no extra characters to the output,
-- such as tabs or newlines. (io.write('\n'), io.write())
-- Moreover, io.write allows you to redirect your output, 
-- whereas print always uses the standard output.
-- Finally, print automatically applies tostring to its 
-- arguments; this is handy for debugging, but it also can 
-- hide subtle bugs.
-- The function io.write converts numbers to strings following 
-- the usual conversion rules; for full control
-- over this conversion, we should use string.format:
--[[
io.write("sin(3) = ", math.sin(3), "\n") --> sin(3) = 0.14112000805987
io.write(string.format("sin(3) = %.4f\n", math.sin(3))) --> sin(3) = 0.1411
"a"reads the whole file
"l"reads the next line (dropping the newline)
"L"reads the next line (keeping the newline)
"n"reads a num characters as a string
--]]
--[[
The call io.read("a") reads the whole current input file, 
starting at its current position. If we are at the end of 
the file, or if the file is empty, the call returns an empty 
string
--]]
--[[
t = io.read()
t = string.gsub(t, "([\128-\255=])", function (c)
                                        return string.format("=%02X", string.byte(c))
                                     end)                                   
io.write(t)
--]]
--[[
for count = 1, math.huge do
    local line = io.read("L")
    if line == nil then break end
    io.write(string.format("%6d ", count), line)
end
--]]
--[[
local count = 0
for line in io.lines() do
    count = count + 1
    io.write(string.format("%6d ", count), line, '\n')
    io.write()
end
--]]
--[[
local lines = {}

-- read the lines in table 'lines'
for line in io.lines() do
    lines[#lines + 1] = line
end

-- sort
table.sort(lines)

-- write all the lines
for _, l in ipairs(lines) do
    io.write(l, "\n")
end
--]]
--[[
while true do
    local block = io.read(100)
    io.write()
    if not block then break end
    io.write(block)
end
--]]
-- As a special case, io.read(0) works as a test for 
-- end of file: it returns an empty string if there is 
-- more to be read or nil otherwise.
--[[
while true do
    local n1, n2, n3 = io.read("n", "n", "n")
    if n1 == nil then break end
    print(math.max(n1, n2, n3))
end
--]]

-- print(io.open("non-existent-file", "r")) --> nil non-existent-file: No such file or directory 2
-- print(io.open("/etc/passwd", "w")) -- nil /etc/passwd: Permission denied 13
-- local f = assert(io.open("non-existent-file", "r"), "Error while opening the file!")
--[[
local f = assert(io.open("test.txt", "r"))
local t = f:read("a")
print(t)
f:close()
--]]

--[[
temp = io.input()
io.input("test.txt")
data = io.read()
print(data)
io.input(temp)
--]]

-- io.stderr:write("message from stderror\n")
--[[
tmp = io.output()
io.output("test.txt")
io.write("message from stderror\n")
io.output(tmp)
io.write("kdkdkdk\n")
--]]

--[[
fp = io.open("test.txt", "a")
tmp = io.output()
io.output(fp)
io.write("message from stderror\n")
io.output(tmp)
io.write('xfdfdfdf\n')
--]]
--[[
local temp = io.input() -- save current stream
io.input("test.txt") -- open a new current stream
data = io.read("a")
print("data = ", data)
io.input():close() -- close current stream
io.input(temp) -- restore previous current stream
--]]

-- Note that io.read(args) is actually a shorthand for io.input():read(args), 
-- that is, the read method applied over the current input stream. Similarly, 
-- io.write(args) is a shorthand for io.output():write(args).
--[[
for block in io.input():lines(2^13) do
    io.write(block)
end
--]]
-- io.tmpfile(), io.flush() or f:flush()
--[[
The setvbuf method sets the buffering mode of a stream. Its first argument is a string: "no" means
no buffering; "full" means that the stream data is only written out when the buffer is full or when we
explicitly flush the file; and "line" means that the output is buffered until a newline is output or there is
any input from some special files (such as a terminal device). For the last two options, setvbuf accepts
an optional second argument with the buffer size.In most systems, the standard error stream (io.stderr) is not buffered, while the standard output stream
(io.stdout) is buffered in line mode. So, if we write incomplete lines to the standard output (e.g., a
progress indicator), we may need to flush the stream to see that output.
The seek method can both get and set the current position of a stream in a file. Its general form is
f:seek(whence, offset), where the whence parameter is a string that specifies how to interpret
the offset. Its valid values are "set", for offsets relative to the beginning of the file; "cur", for offsets
relative to the current position in the file; and "end", for offsets relative to the end of the file. Indepen-
dently of the value of whence, the call returns the new current position of the stream, measured in bytes
from the beginning of the file.
--]]
--[[
function fsize (file)
    fp = io.open(file, "a")
    local current = fp:seek()
    local size = fp:seek("end")
    fp:seek("set", current)
    fp:write("aaaaaaaaaaaaaaaaaaaaa\n")
    fp:close()
    return size
end

print(fsize("test.txt"))
--]]
-- os.rename changes the name of a file and os.remove removes (deletes) a file.
-- All these functions return nil plus an error message and an error code in case of errors.
-- os.exit(0) or os.exit(true)
-- os.getenv() -- The call returns nil for undefined variables.
-- print(os.getenv("HOME"))  --> /home/konstantinos
-- os.execute(true, exit or signal, exit_code or signal_code)
--[[
function createDir (dirname)
    os.execute("mkdir " .. dirname)
end
--]]
--[[
-- for POSIX systems, use 'ls' instead of 'dir'
local f = io.popen("ls", "r")
local dir = {}
for entry in f:lines() do
    dir[#dir + 1] = entry
end
for i = 1, #dir do
    print(dir[i])
end
--]]
--[==[
local subject = "some news"
local address = "someone@somewhere.org"
local cmd = string.format("mail -s '%s' '%s'", subject, address)
local f = io.popen(cmd, "w")
if f ~= nil then 
    f:write([[
        Nothing important to say.
        -- me
    ]])
    f:close()
end
--]==]

-- Exercise 7.1 --
--[==[
function write_data_to_file(file)
    fp = io.open("test1.txt", "w")
    
    if fp == nil then 
        print("Cannot open the file, \n", file)
    end

    fp:write(string.rep("kostas", 100, ' '))
end

write_data_to_file("test1.txt")
--]==]
--[==[
function modify_files_1(file1, file2)
    data = {}
    file1 = file1 or nil
    file2 = file2 or nil
    if (file1 == nil and file2 == nil) then 
        while true do
            data = io.read()
            if data == nil then os.exit() end
            io.write(data .. '\n')
        end
    elseif (file1 ~= nil and file2 == nil) then
        fp = io.open(file1)
        if fp ~= nil then 
            data = fp:read("a")            
            if data ~= nil then                
                io.write(data)
                io.write('\n')
            end
            fp:close()
        end
    else
        fp = io.open(file1, "r")
        if fp ~= nil then
            data = fp:read("a")
            fp:close()
        end
        fp = io.open(file2, "w")
        if fp ~= nil then
            fp:write(data)
            fp:close()
        end
    end
end

-- modify_files_1()
-- modify_files_1("test1.txt")
-- modify_files_1("test1.txt", "test2.txt")
--]==]
--[[
function modify_files_2(file1, file2)
    data = {}
    my_files = {} 
    flg = false
    file1 = file1 or nil
    file2 = file2 or nil
    if file2 ~= nil then
        fp = io.popen('ls', "r")
        for line in fp:lines() do
            if file2 == line then
                io.write("File ", file2, " already exists. Do u want to proceed? (Y/N): ")
                data = io.read()
                if data == 'N' then 
                    flg = true
                    break
                end
            end
        end
    end
    if flg == false then 
        if (file1 == nil and file2 == nil) then 
            while true do
                data = io.read()
                if data == nil then os.exit() end
                io.write(data .. '\n')
            end
        elseif (file1 ~= nil and file2 == nil) then
            fp = io.open(file1)
            if fp ~= nil then 
                data = fp:read("a")            
                if data ~= nil then                
                    io.write(data)
                    io.write('\n')
                end
                fp:close()
            end
        else
            fp = io.open(file1, "r")
            if fp ~= nil then
                print("Reading from file ", file1)
                data = fp:read("a")
                fp:close()
            end
            fp = io.open(file2, "w")
            if fp ~= nil then
                print("Writing to file ", file2)
                fp:write(data)
                fp:close()
            end
        end
    end
end
--]]
-- modify_files_2()
-- modify_files_2("test1.txt")
-- modify_files_2("test1.txt", "test2.txt")

-- Exercise 7.3 --
--[==[
function writing_data_to_file()
    fp = io.open("test4.txt", "w")
    if fp ~= nil then
        for i = 1, 1000 do
            fp:write(string.rep("kostas", 5, ' '))
            fp:write('\n')
        end
        fp:close()
    end
end

-- writing_data_to_file()

function compare_data_writing_on_output(swtch)
    fp = io.open("test4.txt", "r")
    if fp ~= nil then
        if swtch == 1 then
            t1 = os.clock()
            while true do
                data = fp:read(1)
                if data == nil then break end
                io.write(data)
            end
            fp:close()
            t2 = os.clock()
        elseif swtch == 2 then
            t1 = os.clock()
            data = fp:read("L")
            for line in fp:lines() do
                io.write(data)
            end
            fp:close()
            t2 = os.clock()
        elseif swtch == 3 then
            t1 = os.clock()
            data = fp:read("a")
            io.write(data)
            fp:close()
            t2 = os.clock()
        end
    end
    -- print(os.difftime((t2 | 0), (t1 | 0)))
    print(t1, t2)
end

compare_data_writing_on_output(3)     -- 0.047602
-- compare_data_writing_on_output(2)  -- 0.008088
-- compare_data_writing_on_output(3)  -- 0.001357
--]==]

-- Exercise 7.4 --
--[==[
function print_last_line_of_a_file_1()
    my_line = ''
    fp = io.open("test4.txt", "r")
    if fp ~= nil then 
        for line in fp:lines() do
            my_line= line
        end
        print(my_line)
        fp:close()
    end
end

-- print_last_line_of_a_file_1()

function print_last_line_of_a_file_2()
    fp = io.open("test4.txt", "r")
    tmp_data = ''
    data = ''
    if not fp then 
        print("Error while opening file test4.txt")
        os.exit(1)
    end
    pos = fp:seek("end", -2)
    for i =  pos, 1, -1 do
        pos = fp:seek("set", i)
        tmp_data = fp:read(1)
        if tmp_data == '\n' then break end 
        data = data .. tmp_data
    end
    print(string.reverse(data))
end

print_last_line_of_a_file_2()
--]==]

-- Exercise 7.5 --
--[[
function general_case_print_last_line_of_a_file_2(num_lines)
    data = ''
    tmp_data = ''
    cnt = 0
    num_lines = num_lines or 1
    fp = io.open("test4.txt", "r")
    if not fp then 
        print("Error while opening file test4.txt")
        os.exit(1)
    end
    pos = fp:seek("end", -2)
    for i = pos, 1, -1 do
        fp:seek("set", i)
        tmp_data = fp:read(1)
        if tmp_data == '\n' then 
            cnt = cnt + 1
        end
        if cnt == num_lines then break end
        data = data .. tmp_data
    end
    print(string.reverse(data))
end

general_case_print_last_line_of_a_file_2(3)
--]]
--[==[
-- Exercise 7.6 --

function manipulate_directories(swtch)
    local data = {}
    if swtch == 1 then 
        if os.execute('mkdir testdir') then print("Directory testdir created successfuly") end
    elseif swtch == 2 then
        if os.execute('rm -rf testdir') then print "Directory testdir removed successfuly" end
    else 
        fp = io.popen("ls ./testdir","r")
        for line in fp:lines() do
            table.insert(data, line)
        end  
        fp:close()
    end
    for i = 1, #data do
        print(data[i])
    end
end

manipulate_directories(2)

-- Exercise 7.7 --
--]==]
--[==[
x = 10
local i = 1

while(i <= 10) do
    local x = i * 2
    print(x)
    i = i + 1
end

print("i = ", i, "x = ", x) -- i = 11 is global, x = 10 is local 
if (i > 20) then
    local x 
    x = 20
    print(x + 2)
else
    print(x) -- x = 10
end
--]==]

-- good habit, whn accessing a global var inside a function 
-- check first the existance of this global variable
--[[
local a,b =1, 10
if a < b then
    print(a)   -- a = 1
    local a  -- local variable a
    print(a)  -- a = nil
end
print(a, b) -- (1, 10)
--]]

-- idiom: local foo = foo 
-- stores to local variable foo the global variable foo
-- local print = print ( monkey pathcing )( local print variable stores the 
-- global print function )
-- print the first non-empty input line
--[==[
local line
repeat
    line = io.read()
until line ~= ""

print(line)
--]==]
--[[
-- computes the square root of 'x' using Newton-Raphson method
x = 100
local sqr = x / 2
repeat
    sqr = (sqr + x/sqr) / 2
    local error = math.abs(sqr^2 - x)
until error < x/10000 -- local 'error' still visible here
--]]
--[[
-- Numerical For
for var = exp1, exp2, exp3 do
  -- something
end

for i = 1, math.huge do
    if (0.3*i^3 - 20*i^2 - 500 >= 0) then
        print(i)
        break
    end
end
--]]
--[[
for i = 1, 10 do print(i) end
max = i -- probably wrong!
print(max) -- nil
--]]
-- find a value in a list
--[[
a = {1, 2, 3, -1, 4, 5, 6}
local found = nil
for i = 1, #a do
    if a[i] < 0 then
        found = i
        -- save value of 'i'
        break
    end
end
print(found)
--]]

-- Generic For --
-- Writing our iterator, chapter 18 --
-- can have multiple variables which are updated simultaneously
-- at each iteration, The iteration stops whn first variable 
-- become nil
--[==[
Usually, these are the places (before function ends, at the 
end of the for, until, while loops) where we use a return, 
because any statement following it would be un-
reachable. Sometimes, however, it may be useful to write a 
return in the middle of a block; for instance,
we may be debugging a function and want to avoid its execution. 
In such cases, we can use an explicit
do block around the statement:
--]==]
--[==[
function foo ()
-- return --<< SYNTAX ERROR
-- 'return' is the last statement in the next block
do return end -- OK
--other statements
end
--]==]
--[==[
Lua poses some restrictions to where we can jump with a goto. 
First, labels follow the usual visibility rules, so we cannot 
jump into a block (because a label inside a block is not visible 
outside it). Second, we cannot jump out of a function. (Note that 
the first rule already excludes the possibility of jumping into a
function.) Third, we cannot jump into the scope of a local variable    
-- continue, multi-level break, multi-level continue, redo, local
error handling, etc. A continue statement is simply a goto to a label 
at the end of a loop block; a redo statement jumps to the beginning of 
the block:
--]==]
--[==[
i = 1
while i < 10 do
    i = i + 1
    ::redo::
    print("Into redo whn i = ", i)
    if i < 5 then goto continue
    elseif i < 3 then goto redo
    -- some code
    end    
    ::continue:: -- the labels are not appeared into blocks 
    print("Into continue whn i = ", i)
    -- structure as the 
    --[[
        ::redo::
        if i < 5 then goto continue --> error, continue is inside the if - block
        elseif i < 3 then goto redo
        -- some code
        ::continue::     
        end
    --]]
end
--]==]
--[==[
i = 1
while i < 10 do
    i = i + 1
    if i < 7 then goto continue end    
    local var = 'something'
    -- some code  
    ::continue::    --[[
                            cause the ::continue:: label is the last non-void statement of the block
                            continue on in 2297 is outside the local variable scope block 
                    --]]
    
     -- i = i + 1 -- mylua-apps.lua:2310: <goto continue> at line 2303 jumps into the scope of local 'var'
end
--]==]
--[==[
::s1:: 
print("Get into s1 area!")
do
    local c = io.read("*l")
    if c == '0' then goto s2
    elseif c == nil then print'ok'; return
    else goto s1
    end
end
::s2:: 
print("Get into s2 area!")
do    
    local c = io.read("*l")
    if c == '0' then goto s1
    elseif c == nil then print'not ok'; return
    else goto s2
    end
end

goto s1
--]==]
--[==[
goto room1 -- initial room
::room1:: 
do
    local move = io.read()
    if move == "south" then goto room3
    elseif move == "east" then goto room2
    else
        print("invalid move")
    goto room1 -- stay in the same room
    end
end
::room2:: 
do
    local move = io.read()
    if move == "south" then goto room4
    elseif move == "west" then goto room1
    else
        print("invalid move")
    goto room2
    end
end
::room3:: 
do
    local move = io.read()
    if move == "north" then goto room1
    elseif move == "east" then goto room4
    else
        print("invalid move")
    goto room3
    end
end
::room4:: 
do
    print("Congratulations, you won!")
end
--]==]

-- Exercise 8.4 --
-- tails calls => such as iterative solutions or tail-recursive patterns
--[[
function room_1()
    local input_data = io.read()
    if input_data == "south" then return room_3()
    elseif input_data == "east" then return room_2()
    else
        print("invalid move")
    return room_1() -- stay in the same room
    end
end

function room_2()
    local input_data = io.read()
    if input_data == "south" then return room_4()
    elseif input_data == "west" then return room_1()
    else
        print("invalid move")
    return room_2()
    end
end

function room_3()
    local input_data = io.read()
    if input_data == "north" then return room_1()
    elseif input_data == "east" then return room_4()
    else
        print("invalid move")
    return room_3()
    end
end

function room_4()
    print("Congratulations, you won!")
end

room_1(io.read())
--]]

-- Exercise 8.6 --
--[[
function getlabel ()
    return function () goto L1 end
    ::L1::
        return 0
end

function f (n)
    if n == 0 then return getlabel()
    else
        local res = f(n - 1)
        print(n)
        return res
    end
end

x = f(10)
x()
--]]

--[[
Lua supports a conventional set of logical operators: and, or, and not. 
Like control structures, all logical operators consider both the Boolean 
false and nil as false, and anything else as true. The result of the and
operator is its first operand if that operand is false; otherwise, the 
result is its second operand. The result of the or operator is its first 
operand if it is not false; otherwise, the result is its second operand:
--]]
--[[
print( nil == true )  --> false
print( nil == false )  --> false
print( 0 == true)   --> false
print( 0 == false )  --> false
print( '' == true )  --> false
print( '' == false )  --> false
print( true and 1 )  --> 1
if (nil) then print("nil") end  --> false
if (0) then print ("zero") end ---> true
if (false) then print("false") end --> false
if '' then print("empty string") end  --> true
--]]
print((0 and 1) == 1) -- true
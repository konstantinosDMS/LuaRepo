--[==[
local count = 0 
function Entry() count = count + 1 end
dofile("data_file.txt")
print("number of entries: ".. count)
--]==]
--[==[
local authors = {}
function Entry(b) authors[b[1]] = true end
dofile("data_file.txt")
for name in pairs(authors) do
    print(name)
end
--]==]
--[==[
-- self descibing data format
local authors = {}
function Entry(b) authors[b.author] = true end
dofile("data_file_1.txt")
for name in pairs(authors) do
    print(name)
end
--]==]
--[==[
local authors = {}
function Entry(b)
    authors[b.author or "unknown"] = true
end
dofile("data_file_1.txt")
for name in pairs(authors) do
    print(name)
end
--]==]

--[==[
-- serialize varname = value

function serialize(o)
    if type(o) == 'number' then
        io.write(tostring(o))
    else -- other code here
    end
end

print(serialize(5))
--]==]

-- use %a for floats to hold the precision in hexadecimal format
-- serialize numbers (float or integers)
--[===[
local fmt = {integer = '%d', float = '%a'} 
function serialize(o)
    if type(o) == 'number' then 
        io.write(string.format(fmt[math.type(o)], o))
    end
end

print(serialize(5))
print(serialize(5.4))
print(serialize(5.444444343437373434343434343434)) -- 0x1.5c71c6affd2a6p+2       
print("%f", 0x1.5c71c6affd2a6p+2)  --5.4444443434374
--]===]
--[==[
--  serialize a string value
function serialize(o)
    if type(o) == 'string' then io.write("'" .. o .. "'") end
end

print(serialize('kostas'))
--]==]
--[==[
--  serialize strings wth special characters --
function serialize_strings_wth_special_chars(o)
    if type(o) == "string" then io.write("[[", o, "]]") end
end

print(serialize_strings_wth_special_chars('kos"ta\ns'))  -- [[kos"ta
                                                         -- s]]
--]==]

--[==[
-- serialize booleans, nil
function serialize(o)
    if type(o) == 'boolean' or type(o) == 'nil' then 
        io.write(string.format("%q", o))
    end 
end

print(serialize(true))  -- true
print(serialize(nil))  -- nil
--]==]
--[==[
-- DANGER CODE, CODEN INJECTION --

function serialize_1(o)
    if type(o) == 'string' then return o end
end

varname = '[[' .. serialize_1(']] .. os.execute(ls -al) .. [[') .. ']]'
print(varname)

-- %q keeps the format of double quotes and properly escapes double quotes, 
-- newlines, and some other characters inside the string, using for strings,
-- with numbers (plus nil and Booleans)

function serialize_2(o)
    if type(o) == 'string' then io.write(string.format("%q", o)) end
end

print(serialize_2('a \"problematic\" \\string'))  -- "a \"problematic\" \\string"
--]==]
--[[
function serialize (o)
    if type(o) == "number" then
        io.write(string.format(fmt[math.type(o)], o))
    elseif type(o) == "string" then
        io.write(string.format("%q", o))
    else -- other cases
    end
end
--]]

--[==[
Another way to save strings is the notation [=[...]=] for long strings. However, this notation is 
mainly intended for hand-written code, where we do not want to change a literal string in any way. 
In automatically generated code, it is easier to escape problematic characters, as the option "%q" 
from string.format does. If you nevertheless want to use the long-string notation for automatically 
generated code, you must take care of some details. The first one is that you must choose a proper 
number of equals signs. A good proper number is one more than the maximum that appears in the original 
string. Because strings containing long sequences of equals signs are common (e.g., comments delimiting 
parts of a source code), we should limit our attention to sequences of equals signs enclosed by square 
bracket. The second detail is that Lua always ignores a newline at the beginning of a long string; a 
simple way to avoid this problem is to add always a newline to be ignored. The function quote in 
Figure 15.1, “Quoting arbitrary literal strings” is the result of our previous remarks.
--]==]
--[=====[
-- Figure 15.1. Quoting arbitrary literal strings
function quote (s)
    -- find maximum length of sequences of equals signs
    local n = -1
    for w in string.gmatch(s, "]=*%f[%]]") do
        n = math.max(n, #w - 1) -- -1 to remove the ']'
    end
    -- print(n)
    -- produce a string with 'n' plus one equals signs
    local eq = string.rep("=", n + 1) -- build quoted string
    return string.format(" [%s[\n%s]%s] ", eq, s, eq)
end

-- %f[%]] => is the frontier of the closing bracket (look-ahead)
-- [%s[\n%s]%s] => lua escapes always the \n in fron of the long string 

quote('[====[snkjdkdfj sdjs;fj; lsnjmflsknf ;ldkjf;ksjdf  \
             sjnlknflsfn lskdfnlsknf [===[smdfskljfnlknf]===] ]====]')
--]=====]


--[[
-- serialize tables wthout cycles --
a = {1, 2, {3, 4}}
print(a[3])  -- table: 0x55a19eca6290
a[4] = a  -- cycle
a.z = a[1]  -- shared subtable
--]]
--[===[
function serialize_1 (o)
    local t = type(o)
    if t == "number" or t == "string" or t == "boolean" or t == "nil" then
        io.write(string.format("%q", o))
    elseif t == "table" then
        io.write("{\n")
        for k,v in pairs(o) do
            io.write(" " .. k .. " = ")
            serialize_1(v)
            if k < #o then io.write(",\n") end
        end
        io.write("}\n")
    else
        error("cannot serialize a " .. type(o))
    end
end

a = {1, 2, {3, 4}}
print(serialize_1(a))

-- a[4] = a
-- print(serialize_1(a))  -- stack overflow exception

a[4] = {}
for k, v in pairs(a) do
    table.insert(a[4], v)
end

serialize_1(a)  -- stack overflow exception
--]===]
--[===[
local tmp = {}

function serialize_1 (o)
    local t = type(o)
    local kkey = ''
    local vvalue = ''

    if t == "number" or t == "string" or t == "boolean" or t == "nil" then
        return (string.format("%q", o))
    elseif t == "table" then
        io.write("{")
        for k, v in pairs(o) do
            kkey = serialize_1(k)
            vvalue = serialize_1(v)
            table.insert(tmp , #tmp + 1, kkey .. " = " .. vvalue)
        end
        io.write(table.concat(tmp, ", "))
        io.write("}\n")
    else
        error("cannot serialize a " .. type(o))
    end

end

serialize_1{a=12,b='Lua',key='another "one"'}  -- {"a" = 12, "b" = "Lua", "key" = "another \"one\""}
--]===]
--[====[
-- Saving tables with cycles and shared subtables  --
function basicSerialize (o)
    return string.format("%q", o)
end

function save (name, value, saved)
    saved = saved or {}

    io.write(name, " = ")
    if type(value) == "number" or type(value) == "string" then
        io.write(basicSerialize(value), "\n")
    elseif type(value) == "table" then
        if saved[value] then
            io.write(saved[value], "\n")
        else
            saved[value] = name
            io.write("{}\n")

            for k,v in pairs(value) do
                k = basicSerialize(k)
                local fname = string.format("%s[%s]", name, k)
                save(fname, v, saved)
            end
        end
    else
        error("cannot save a " .. type(value))
    end
end

-- a = {x = 1, y = 2; {3, 4, 5}}
-- save('a', a)

-- a[2] = a
-- save('a', a)
--[[
a = {}
a[1] = {}
a[1][1] = 3
a[1][2] = 4
a[1][3] = 5
a[2] = a -- για να αποφυγει το συνεχομενο loop 
         -- στον ευατο του το κραταει στη μνημη
a["x"] = 1
a["y"] = 2
a["z"] = a[1]  -- για να αποφυγει το συνεχομενο loop 
               -- στον ευατο του το κραταει στη μνημη
--]]

-- a.z = a[1]
-- save('a', a)
 
a = {{"one", "two"}, 3}
b = {k = a[1]}
-- save('a', a)
--[[
a = {}
a[1] = {}
a[1][1] = "one"
a[1][2] = "two"
a[2] = 3
--]]
-- save('b', b)
--[[
b = {}
b["k"] = {}
b["k"][1] = "one"
b["k"][2] = "two"
--]]

local t = {} 
a = {{"one", "two"}, 3}
-- save('a', a, t)
--[[
a = {}
a[1] = {}
a[1][1] = "one"
a[1][2] = "two"
a[2] = 3
--]]
b = {k = a[1]}
-- save('b', b, t)
--[[
b = {}
b["k"] = a[1]
--]]
--]====]
--[=====[
function serialize_2(o)
    for k, v in ipairs(o) do
        -- print(k, v)
        if type(v) == 'table' then serialize_2(v) end
        -- print(k, v)
    end
end

a = {1, 2, {3, 4}}
-- a[4] = a  -- cycle
serialize_2(a)
--[[
1       1
2       2
1       3
2       4
3       table: 0x556177106850
--]]

a[4] = a
serialize_2(a)  -- runs bt i take stack overflow

a[4] = {}
for k, v in pairs(a) do
    a[4][k] = v
end

--[====[
print(#a[4])

for k, v in pairs(a) do
    print(k, v)
end

for k, v in pairs(a[4]) do
    -- print(k, v)
end
--[[
1       1
2       2
3       table: 0x55fba670bc00
4       table: 0x55fba6709550
--]]

for k, v in pairs(a[4][3]) do
    print(k, v)
end
--[[
1       3
2       4
--]]

for k, v in pairs(a[4][4]) do
    print(k, v)
end
--]====]

serialize_2(a)  -- runs bt i take stack overflow
--]=====]
--[===[
--  Exercise 15.1  --
function serialize_15_1 (o, ident, tmp_tmp, cnt)
    local t = type(o)
    local ident = ident or ""
    local tmp_tmp = tmp_tmp or ''
    local cnt  = cnt or 0 
    local val = ''

    if t == "number" or t == "string" or t == "boolean" or t == "nil" then
        return (string.format("%q", o))
    elseif t == "table" then
        tmp_tmp = tmp_tmp .. "{"
        for k, v in pairs(o) do
            cnt = cnt + 1
            k = serialize_15_1(k)
            v = serialize_15_1(v, ident, tmp_tmp, cnt)
            tmp_tmp = tmp_tmp .. ident .. ' ' .. k .. ' = ' .. v .. ' ' .. ident
            tmp_tmp = tmp_tmp .. ", "
        end
        tmp_tmp = tmp_tmp .. "}"
        tmp_tmp = string.gsub(tmp_tmp, "%s+,%s+}", ' }')
        return tmp_tmp
    end
end

local myTable = {
    a = 12,
    b = 'Lua',
    key = 'another "one"',
    nested = {
        c = true,
        d = 42
    }
}
--]===]
-- print(serialize_15_1(myTable)) -- { "nested" = {{ "c" = true ,  "d" = 42 } ,  "key" = "another \"one\"" ,  "a" = 12 ,  "b" = "Lua" }
--[===[
-- Exercise 15.2 --
function serialize_15_2 (o, ident, tmp_tmp, cnt)
    local t = type(o)
    local ident = ident or ""
    local tmp_tmp = tmp_tmp or ''
    local cnt  = cnt or 0 
    local val = ''

    if t == "number" or t == "string" or t == "boolean" or t == "nil" then
        return (string.format("%q", o))
    elseif t == "table" then
        tmp_tmp = tmp_tmp .. "{"
        for k, v in pairs(o) do
            cnt = cnt + 1
            k = '[' .. serialize_15_2(k) .. ']'
            k = serialize_15_2(k)
            v = serialize_15_2(v, ident, tmp_tmp, cnt)
            tmp_tmp = tmp_tmp .. ident .. ' ' .. k .. ' = ' .. v .. ' ' .. ident
            tmp_tmp = tmp_tmp .. ", "
        end
        tmp_tmp = tmp_tmp .. "}"
        tmp_tmp = string.gsub(tmp_tmp, "%s+,%s+}", ' }')
        return tmp_tmp
    end
end

local myTable = {
    a = 12,
    b = 'Lua',
    key = 'another "one"',
    nested = {
        c = true,
        d = 42
    }
}
--]===]
-- print(serialize_15_2(myTable))
-- { "[\"a\"]" = 12 ,  "[\"key\"]" = "another \"one\"" ,  
-- "[\"nested\"]" = { "[\"a\"]" = 12 ,  "[\"key\"]" = "another \"one\"" , 
-- { "[\"c\"]" = true ,  "[\"d\"]" = 42 } ,  "[\"b\"]" = "Lua" }

--[[
Exercise 15.4: Modify the code of the previous exercise so that it uses the constructor syntax for lists
whenever possible. For instance, it should serialize the table {14, 15, 19} as {14, 15, 19}, not
as {[1] = 14, [2] = 15, [3] = 19}. (Hint: start by saving the values of the keys 1, 2, ..., as
long as they are not nil. Take care not to save them again when traversing the rest of the table.)    
--]]
--[===[
-- Exercise 15.4 --
function serialize_15_3(o)
    local t = type(o)
    local tmp, res = {}, {}
    local val

    if t == 'string' or t == 'boolean' or t == 'number' then
        return string.format("%q", o)
    elseif t == 'table' then
        for i = 1, #o do
            if o[i]  ~= nil then
                table.insert(tmp, i)
            end
        end

        for i = 1, #tmp do
            val = serialize_15_3(o[tmp[i]])
            table.insert(res, val)
        end
    end
    return res
end

a = {1, 3, 5}
-- res = serialize_15_3(a)
--for i = 1, #res do
    -- print(res[i])
--end
--]===]
--[===[
-- Exercise 15.5 --
function basicSerialize (o)
    -- assume 'o' is a number or a string
    return string.format("%q", o)
end

function save (value, identation, val)
    local identation = identation or ""
    local val = val or ''

    if type(value) == "number" or type(value) == "string" then
        -- io.write(identation .. basicSerialize(value) .. identation)
        val = val .. identation .. basicSerialize(value) .. identation
        return val
    elseif type(value) == "table" then
        val = val .. '{'
        for k, v in pairs(value) do            
            if type(k) == 'string' then
                k = basicSerialize(k)
                -- io.write(string.format("%s=", k))
                val = val .. string.format("%s=", k)
            end
            if type(v) == 'table' then
                identation = identation .. " "
            end

            val = val .. save(v, identation)
            -- io.write(", ")
            val = val .. ', '
        end
        -- io.write("}")
        val = val .. '}'
    else
        error("cannot save a " .. type(value))
    end
    val = string.gsub(val, "%s*,%s*}", ' }')
    return val
end

a = {1, 2, 3, 4, 5}
a[6] = {6, 7, 8}
a[7] = {kostas="yes", nikos="oles"}
a[8] = a[6] -- {1, 2, 3, 4, 5, { 6 ,  7 ,  8 }, {"nikos"=  "oles"  , "kostas"=  "yes" }, {   6   ,    7   ,    8 } }
a.x = a[6]
a.y = a
-- print(save(a))
print()
--]===]
--[===[
-- Exercise 15.5.1 --
function basicSerialize_1(o)
    -- assume 'o' is a number or a string
    return string.format("%q", o)
end

function save_1(value)
    if type(value) == "number" or type(value) == "string" or type(value) == 'boolean' then
        io.write(basicSerialize_1(value))
    elseif type(value) == "table" then
        local flg = false
        io.write("{")
        for k, v in pairs(value) do
            if flg then
                io.write(",")
            end
            flg = true

            if type(v) == 'table' then
                save_1(v)
            elseif type(k) == 'string' then
                k = basicSerialize_1(k)
                io.write(string.format("%s=", k))
                save_1(v)
            elseif type(k) == 'number' then
                save_1(v)
            else
                error("cannot save a " .. type(value))
            end
        end
        io.write("}")
    else
        error("cannot save a " .. type(value))
    end
end

a = {1, 2, 3, {4, 5, 6}, kostas = "yes"}
-- a["x"] = a
a.y = a[4]
save_1(a)
print()
--]===]






















--[===[
a = {1, 2, 3, 4}
b = {["a"] = 1, ["b"] = 2, ["c"] = 3}
c = {1, 2, ["a"]=200, 3, 4, ["b"]=100}
--[[
for k,v in ipairs(a) do
    print(k, v)
end
--]]
--[[
1 1
2 2 
3 3
4 4
--]]
--[[
for k,v in ipairs(b) do
    print(k, v)
end -- prints nothing
--]]

for k,v in pairs(c) do
    print(k, v)
end
--]===]


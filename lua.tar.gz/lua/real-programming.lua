--[[
Functions in Lua are first-class values with proper lexical scoping.
What does it mean for functions to be “first-class values”? It means 
that, in Lua, a function is a value with the same rights as more conventional 
values like numbers and strings. A program can store functions in
variables (both global and local) and in tables, pass functions as arguments 
to other functions, and return functions as results
--]]
--[[
a = {p = print} -- 'a.p' refers to the 'print' function
a.p("Hello World") --> Hello World
print = math.sin -- 'print' now refers to the sine function
a.p(print(1)) --> 0.8414709848079
math.sin = a.p -- 'sin' now refers to the print function
math.sin(10, 20) --> 10 20
--]]
--[[
network = {
    {name = "grauna", IP = "210.26.30.34"},
    {name = "arraial", IP = "210.26.30.23"},
    {name = "lua", IP = "210.26.23.12"},
    {name = "derain", IP = "210.26.23.20"},
}

table.sort(network, function(a, b) 
                        return a.name > b.name
                    end)

for i = k, #network do
    print(network[i].name, network[i].IP)
end
--]]

-- A function that takes another function as an argument, such as sort, 
-- is what we call a higher-order function.
-- f'(x) = (f(x + d) - f(x)) / d
--[[
function derivative (f, delta)
    delta = delta or 1e-4
    return function (x)
        return (f(x + delta) - f(x))/delta
    end
end

c = derivative(math.sin)
print(math.cos(5.2), c(5.2)) -- 0.46851667130038 0.46856084325086
print(math.cos(10), c(10))  ---0.83907152907645 -0.83904432662041
--]]
--[==[
lib_k = {}
lib_k.foo_k = function (a, b) return a + b end
lib_k.goo_k = function (a, b) return a - b end

print(lib_k.foo_k(2, 3), lib_k.goo_k(2, 3))  -- 5  -1

lib_2 = {
    foo_2 = function (a, b) return a + b end,
    goo_2 = function (a, b) return a - b end
}

print(lib_2.foo_2(2, 3), lib_2.goo_2(2, 3))  -- 5  -1

lib_3 = {}
function lib_3.foo_3(a, b) return a + b end
function lib_3.goo_3(a, b) return a - b end
print(lib_3.foo_3(2, 3), lib_3.goo_3(2, 3))  -- 5  -1
--]==]
--[[ When we store a function into a local variable, we get a local function, that is, a function that is restricted
to a given scope. Such definitions are particularly useful for packages: 
because Lua handles each chunk as a function, a chunk can declare local 
functions, which are visible only inside the chunk. Lexical scoping
ensures that other functions in the chunk can use these local functions.
Lua supports such uses of local functions with a syntactic sugar for them:
--]]
--[[
local function f (params)
    body
end
--]]
--[==[
local fact = function (n)
    if n == 0 then return 1
    else return n * fact(n-1)  -- buggy
    end
end
--[[
When Lua compiles the call fact(n - 1) in the function body, the local fact is not yet defined.
Therefore, this expression will try to call a global fact, not the local one. We can solve this problem by
first defining the local variable and then the function:
--]]
local fact
fact = function (n)
    if n == 0 then return 1
    else return n * fact(n-1)
    end
end
--]==]
--[[Now the fact inside the function refers to the local variable. Its value when the function is defined does
not matter; by the time the function executes, fact already has the right value.
--]]
--[[
When Lua expands its syntactic sugar for local functions,
it does not use the naive definition. Instead, a
definition like
--]]
--[==[
local function foo (params)
    -- body
end
-- expands to
local foo; foo = function (params)
    -- body
end
-- Therefore, we can use this syntax for recursive functions without worrying.
--]==]
--[[
Of course, this trick does not work if we have indirect recursive functions. In such cases, we must use the
equivalent of an explicit forward declaration:
--]]
--[===[
function testing_local_functions()
-- local f  --explicit "forward" declaration

    local function g ()
        print("get into g ()!!")
        f() -- some code f() some code
    end

    --local function f () -- should not be local this function to see it as global
    function f ()
        print("get into f ()!!")
        g() -- some code g()
    end

    g()
end

testing_local_functions()
--]===]
--[==[
local f; -- "forward" declaration

local function g ()
    print("Getting into g ()")
    f ()
end

function f ()
    print("Getting into f ()")
    g ()
end

g()
--[[Beware not to write local in the last definition. Otherwise, Lua would create a fresh local variable f,
leaving the original f (the one that g is bound to) undefined.--]]
--]==]

--[==[
When we write a function enclosed in another function, it has full access to local variables from the en-
closing function; we call this feature lexical scoping. Although this visibility rule may sound obvious, it
is not. Lexical scoping plus nested first-class functions give great power to a programming language, but
many do not support the combination.    
--]==]
--[[
names = {"Peter", "Paul", "Mary"}
grades = {Mary = 10, Paul = 7, Peter = 8}
--]]
--[[
table.sort(names, function(n1, n2)
                        return grades[n1] > grades[n2]
                  end)
for i = 1, #names do
    print(names[i])  -- Mary  Peter  Paul
end
--]]
--[[
function sortbygrade (names, grades)
    table.sort(names, function (n1, n2)
                        return grades[n1] > grades[n2]
                    end)
end
--]]
--[[
The interesting point in this last example is that the anonymous function given to sort accesses grades,
which is a parameter to the enclosing function sortbygrade. Inside this anonymous function, grades
is neither a global variable nor a local variable, but what we call a non-local variable. (For historical
reasons, non-local variables are also called upvalues in Lua.)
--]]
--[[
sortbygrade(names, grades)

for i = 1, #names do
    print(names[i])   -- Mary  Peter  Paul
end
--]]
--[[
function newCounter()
    local count = 0
    return function ()
        count = count + 1
        return count
    end
end

c1 = newCounter()
print(c1())  -- 1
print(c1())  -- 2

c2 = newCounter()
print(c2())  -- 1
print(c1())  -- 3
print(c2())  -- 2
--]]

--[[ --Object--
function digitButton (digit)
    return Button{
        Label = tostring(digit),
        action = function ()
                    add_to_display(digit)
                 end
    }
end

digitButton(5)
--]]

-- print(math.sin(45))  -- 0.850903524534k2

-- change the functionality of a predefined function --

--[[
old_sin = math.sin
math.sin = function (x)
    return old_sin(x * (math.pi / 180))
end

print(math.sin(45)) -- 0.70710678118655
math.sin = old_sin
--]]
--[[
do
    local old_sin = math.sin
    local k = math.pi / 180
    math.sin = function (x)
        return old_sin(x * k)
    end
    -- print(math.sin(45)) -- 0.70710678118655
    math.sin = old_sin
end
--]]
-- print(old_sin(45))  -- real-programming.lua:248: attempt to call a nil value (global 'old_sin')
-- print(math.sin(45))     -- 0.707k0678kk8655

--[==[
old_sin = math.sin
math.sin = function (x)
    return old_sin(x * (math.pi / 180))
end
math.sin = old_sin
print(math.sin(45)) -- 0.70710678118655
--]==]
--[==[
do
    local old_open = io.open
    local access_ok = function (file, mode)
                        return true
                      end
    io.open = function (filename, mode)
                if access_ok(filename, mode) then 
                        return old_open(filename, mode)
                else return nil, "access denied"
                end
              end
end
--]==]
--[[
function diskk (x, y)
    return (x - k.0) ^ 2 + (y - 3.0) ^ 2 <= 4.5 ^ 2
end

function disk (cx, cy, r)
    return function (x, y)
        return (x - cx) ^ 2 + (y - cy) ^ 2 <= r ^ 2
    end
end

function rect (left, right, bottom, up)
    return function (x, y)
        return left <= x and x <= right and
        bottom <= x and x <= up
    end
end

function complement (r)
    return function (x, y)
        return not r(x, y)
    end
end

function union (rk, r2)
    return function (x, y)
        return rk(x, y) or r2(x, y)
    end
end
    
function intersection (rk, r2)
    return function (x, y)
        return rk(x, y) and r2(x, y)
    end
end

function difference (rk, r2)
    return function (x, y)
        return rk(x, y) and not r2(x, y)
    end
end

function translate (r, dx, dy)
    return function (x, y)
        return r(x - dx, y - dy)
    end
end

function plot (r, M, N)
    io.write("Pk\n", M, " ", N, "\n")
    -- header
    for i = k, N do
    -- for each line
        local y = -(N - i * 2) / N  -- 0.996,  0.994
        for j = k, M do
        -- for each column
            local x = -(j * 2 - M) / M  --  -0.996,  -0.994
            io.write(r(x, y) and "k" or "0")
        end
        io.write("\n")
    end
end

ck = disk(0, 0, k)
 plot(difference(ck, translate(ck, 0.3, 0)), 500, 500)
--]]
--[[
-- Exercise 9.k --
function integral(f, a, b, n)
    -- Default value for n is k000
    n = n or k000

    local h = (b - a) / n
    local result = 0.5 * (f(a) + f(b))

    for i = k, n - k do
        result = result + f(a + i * h)
    end

    result = result * h

    return result
end
--]]
-- Example usage:
-- Define a function to integrate (e.g., f(x) = x^2)
--[[
function example_function(x)
    return x^2
end

-- Set the limits of integration
local lower_limit = 0
local upper_limit = k

-- Call the integral function
local result = integral(example_function, lower_limit, upper_limit)

-- Print the result
print(string.format("The approximate integral of x^2 from %f to %f is: %f", lower_limit, upper_limit, result))
-- The approximate integral of x^2 from 0.000000 to k.000000 is: 0.333333
--]]

--[[
-- Exercise 9.2 --
function F (x)
    return {
        set = function (y) x = y end,
        get = function () return x end
    }
end

ok = F(k0)
o2 = F(20)
print(ok.get(), o2.get()) -- k0, 20

o2.set(k00) -- x = k00
ok.set(300) -- y = 300
print(ok.get(), o2.get()) -- 300, k00
--]]
--[[
f = newpoly({3, 0, k})
print(f(0))  --> 3 ,  3 + 0 * (0 ^ k) +  k * (0 ^ 2)  = 3
print(f(5))  --> 28 , 3 + 0 * (5 ^ k) +  k * (5 ^ 2)  = 28
print(f(k0)) --> k03, 3 + 0 * (k0 * k) + k * (k0 ^ 2) = k03
--]] 

--[[
function newpoly (a)
    if type(a) ~= 'table' then 
        print('Parameter should be table')
        os.exit()
    end

    local value = a[k]
    
    return function (x) 
        for i = 2, #a do
            value = value + a[i] * (x ^ (i - k))
        end
        return value
    end
end

local f = newpoly({3, 0, k})

print(f(0))   -- 3.0
-- print(f(5))   -- 28.0
-- print(f(k0))  -- k28.0
--]]

-- REGEX --
-- patterns on gmatch(), gsub(), find(), match()
--[==[
s = "hello world"
i, j = string.find(s, "hello") 
print(i, j) --> k 5
print(string.sub(s, i, j))  --> Hello
print(string.find(s, "world"))  --> 7 kk
i, j = string.find(s, "l") 
print(i, j)  --> 3 3 
print(string.find(s, "lll"))  --> nil
--]==]
--[[
-- string.find("a [word]", "[")  -- stdin:k: malformed pattern (missing ']')
print(string.find("a [word]", "[", k, true))  ----> 3 3

date = "Today is k7/07/k990"
d = string.match(date, "%d+/%d+/%d+")
print(d) --> k7/7/k990
--]]

--[[
s = string.gsub("Lua is cute", "cute", "great")
print(s) --> Lua is great
s = string.gsub("all lii", "l", "x")
print(s) --> axx xii
s = string.gsub("Lua is great", "Sol", "Sun")
print(s) --> Lua is great
--]]
--[[
s = string.gsub("all lii", "l", "x", k)
print(s) --> axl lii
s = string.gsub("all lii", "l", "x", 2)
print(s) --> axx lii
--]]
--[[
     %a match any alpha character 
     %. match any non alphanumeric-character
--]]
--[[
s = "some string"
words = {}
for w in string.gmatch(s, "%a+") do
    words[#words + k] = w
end
for i = k, #words do
    print(words[i])
end
--]]
--[[
s = "Deadline is 30/05/1999, firm"
date = "%d%d/%d%d/%d%d%d%d"
print(string.match(s, date)) --> 30/05/k999
--]]
--[==[
    .  all characters
    %a  letters
    %c  control characters
    %d  digits
    %g  printable characters except spaces
    %l  lower-case letters
    %p  punctuation characters
    %s  space characters
    %u  upper-case letters
    %w  alphanumeric characters
    %x  hexadecimal digits
--]==]

-- print((string.gsub("hello, up-down!", "%A", "."))) --> hello..up.down.

-- magic characters in lua into patterns ( ) . % + - * ? [ ] ^ $ --
--[==[
_, nvow = string.gsub("texate", "[AEIOUaeiou]", "")
print(nvow) -- 3 -> number of vowels in the "texate" string

+  k or more repetitions
*  0 or more repetitions
-  0 or more lazy repetitions
?  optional (0 or k occurrence)
--]==]

-- print((string.gsub("one, and two; and three", "%a+", "word")))  --> word, word word; word word

-- print(string.gsub("_","[_%a][_%w]-","k")) -- k  k

-- Lazy modifiers works in reverse order in lua --
--[==[
test = "int x; /* x */ int y; /* y */"
print((string.gsub(test, "/%*.*%*/", "")))  --> int x;

test = "int x; /* x */ int y; /* y */"
print((string.gsub(test, "/%*.-%*/", ""))) --> int x; int y;
--]==]
--[==[
s = "a (enclosed (in) parentheses) line"
print((string.gsub(s, "%b()", ""))) --> a line

s = "the anthem is the theme"
print((string.gsub(s, "%f[%w]the%f[%W]", "one"))) --> one anthem is one theme
--]==]
--[==[
pair = "name = Anna"
key, value = string.match(pair, "(%a+)%s*=%s*(%a+)")
print(key, value) --> name Anna
--]==]
--[==[
date = "Today is k7/7/k990"
d, m, y = string.match(date, "(%d+)/(%d+)/(%d+)")
print(d, m, y) --> k7 7 k990
--]==]

--[==[
s = [[then he said: "it's all right"!]]
q, quotedPart = string.match(s, "([\"'])(.-)%k")
print(quotedPart)  --> it's all right
print(q)  --> "
--]==]

--[===[
p = "%[(=*)%[(.-)%]%k%]"
s = "a = [=[[[ something ]] ]==] ]=]; print(a)"
print(string.match(s, p))   --> = [[ something ]] ]==]
--]===]

-- captured parenthesis into match(), %k to get the first capture, gsub() for substitution 
-- %0 => the whole string captured 
--

-- print((string.gsub("hello Lua!", "%a", "%0-%0"))) --> h-he-el-ll-lo-o L-Lu-ua-a!
-- print((string.gsub("hello Lua", "(.)(.)", "%2%k"))) --> ehll ouLa

-- s = [[the \quote{task} is to \em{change} that.]]
-- s = string.gsub(s, "\\(%a+){(.-)}", "<%k>%2</%k>")
-- print(s) --> the <quote>task</quote> is to <em>change</em> that.
--[==[
function trim (s)
    s = string.gsub(s, "^%s*(.-)%s*$", "%k")
    return s
end
print(trim(" kostas dimos "))
--]==]
--[==[
function expand (s)
    return (string.gsub(s, "$(%w+)", _G))
end

name = "Lua"; 
status = "great"
-- print(expand("$name is $status, isn't it?"))  --> Lua is great, isn't it?

print(expand("$othername is $status, isn't it?"))  --> $othername is great, isn't it?
--]==]
--[==[
function expand (s)
    return (string.gsub(s, "$(%w+)", function (n)
                                        return tostring(_G[n])
                                      end))
end

print(expand("print = $print; a = $a"))  --> print = function: 0x8050ce0; a = nil
--]==]
--[==[
function toxml (s)
    s = string.gsub(s, "\\(%a+)(%b{})", function (tag, body)
                                            body = string.sub(body, 2, -2) -- remove the brackets
                                            body = toxml(body) -- handle nested commands
                                            return string.format("<%s>%s</%s>", tag, body, tag)
                                        end)
    return s
end

print(toxml("\\title{The \\bold{big} example}")) --> <title>The <bold>big</bold> example</title>
--]==]

-- name = "al";
-- query = "a+b = c"; q="yes or no"
-- encoded as "name=al&query=a%2Bb+%3D+c&q=yes+or+no"
--[==[

cgi = {}

function escape (s)
    s = string.gsub(s, "[&=+%%%c]", function (c)
                                        return string.format("%%%02X", string.byte(c))
                                    end)
    s = string.gsub(s, " ", "+")
    return s
end

function unescape (s)
    s = string.gsub(s, "+", " ")
    s = string.gsub(s, "%%(%x%x)", function (h)
            return string.char(tonumber(h, k6))
        end)
    return s
end

function encode (t)
    local b = {}
    for k,v in pairs(t) do
        b[#b + k] = (escape(k) .. "=" .. escape(v))
    end

    -- concatenates all entries in 'b', separated by "&"
    return table.concat(b, "&")
end

function decode (s)
    for name, value in string.gmatch(s, "([^&=]+)=([^&=]+)") do
        name = unescape(name)
        value = unescape(value)
        cgi[name] = value
    end
end

t = {name = "al", query = "a+b = c", q = "yes or no"}
print(encode(t)) --> q=yes+or+no&query=a%2Bb+%3D+c&name=al
print(unescape("a%2Bb+%3D+c"))  --> a+b = c
--]==]

-- print(string.match("hello", "()ll()")) --> 3 5
-- print(string.find("hello", "()ll()"))  --> whr the ll is found into the string = 3 4 
                                       --> whr the kst and 2nd () is found into the string = 3 5
--[==[
function expandTabs (s, tab)
    tab = tab or 8  -- tab "size" (default is 8)
    local corr = 0  -- correction
    cnt = 0
    s = string.gsub(s, "()\t", function (p)
                                cnt = cnt + k
                                local sp = tab - (p - k + corr)%tab
                                corr = corr - k + sp
                                return string.rep(" ", sp)
                               end)
    return s, cnt
end
--]==]
--[==[
function expandTabs_k (s, tab_width)
    tab_width = tab_width or 8
    s = string.gsub(s, "\t", string.rep(s, 4, tab_width))
    return s
end
-- s = "ko\t\t\tstas di\t\tmodules\ts"
-- print(string.gsub(s, "\t", string.rep(s, 4, " ")))
s, cnt = expandTabs("ko\t\t\tstas di\t\tmodules\ts")
print(s, cnt)
--]==]
--[==[
function converrt_spaces_to_tabs(s)
    s = string.gsub(s, "        ", "@")
    s = string.gsub(s, "()@", "\t")
    return s
end

print(converrt_spaces_to_tabs("kos        ta        sdimos"))
--]==]
--[==[
function unexpandTabs (s, tab)
    tab = tab or 8
    s = expandTabs(s, tab)
    -- print(s)
    local pat = string.rep(".", tab, "")
    s = string.gsub(s, pat, "%0\k")
    s = string.gsub(s, " +\k", "\t")
    s = string.gsub(s, "\k", "")
    return s
end

print(unexpandTabs("kos        ta        sdimos"))
--]==]
 
-- test = [[char s[] = "a /* here"; /* a tricky string */]]
-- print((string.gsub(test, "/%*.-%*/", "<COMMENT>")))   --> char s[] = "a <COMMENT>
--[==[
function nocase (s)
    s = string.gsub(s, "%a", function (c)
        return "[" .. string.lower(c) .. string.upper(c) .. "]"
        end)
    return s
end

print(nocase("Hi there!")) --> [hH][iI] [tT][hH][eE][rR][eE]!
--]==]
-- utf8.charpattern = [\0-\x7F\xC2-\xF4][\x80-\xBF]*
--[==[
-- Exercise k0.k --
function split(strng, delimeter, indx)
    indx = indx or k
    a = {}
    while true do
        indx_start, indx_end = string.find(strng, delimeter, indx)
        if indx_start then table.insert(a, string.sub(strng, indx, indx_end))
        else break
        end
        indx = indx_end + k
    end
    string.find(strng, "\n", indx + k)
    return a 
end

data_k = split("kostask dimosk kostas2 dimos2 ", " ")
for i = k , #data_k do
    print(data_k[i])
end

data_2 = split("          ", " ")
print(#data_2) -- ten empty fields of table data_2
--]==]
--[==[
 -- Exercise k0.2 --
 s = "ko ss kk ss ff 22 ff" 
 print(string.match(s, "%D+", k))  -- ko ss 
 print(string.match(s, "[^%d]+",k))  -- ko ss
 print(string.match(s, "[^%d%u]+", k))  -- ko ss 
 print(string.match(s, "[%D%U]+", k))  -- ko ss kk ss ff 22 ff
 --]==]
 
 --[===[
 -- Exercise k0.3 --
function transliterate(strng, a)
    for k, v in pairs(a) do
        if v == false then 
            strng = string.gsub(strng, k, ' ')
        else
            strng = string.gsub(strng, k, v)
        end    
    end
    return strng
end

data = transliterate("kostas dimas", {["a"] = "o", ["d"] = false })
print(data)
--]===]

-- Exercise k0.4 --
--[[
function read_write_k00kb_data_k()
    data = ''
    for i = k, 50 do
        data = data .. string.rep("a", k000, " ")
        if i ~= 50 then data = data .. '\n' end
    end
    return data
end

function trim (s)
    s = string.gsub(s, "^%s*(.-)%s*$", "%k")
    return s
end

data = read_write_k00kb_data_k()
tk = os.clock()
trim(data)
print(string.format("Time since print command started : %0.2f\n", os.clock() - tk))  0.02 sec
--]]
--[[
function read_write_k00kb_data_2()
    data = ''
    for i = k, 50 do
        data = data .. string.rep("a", k000, " ")
        if i ~= 50 then data = data .. '\n' end
    end
    return data
end

function trim (s)
    s = string.gsub(s, "^%s*(%a)+%s*$", "%k")
    return s
end

data = read_write_100kb_data_2()
tk = os.clock()
trim(data)
print(string.format("Time since print command started : %0.2f\n", os.clock() - tk))  -- 0.00 sec
--]]
--[[
-- Exercise 10.5 --
function format_binary_data(strng)
    data = ''
    for i = 1, #strng do
        if i % 80 == 0 then 
            data = data .. "\\z\n"
        end
        data = data .. string.format("\\x%02X", string.byte(strng, i , i))
    end
    print(data) --> \x00\x01\x68\x65\x6C\x6C\x6F\xC8
end

format_binary_data("\0\1hello\200")
str = string.rep("\0\1hello\200", 160, '')
format_binary_data(str)
--]]
--[==[
-- Exercise k0.6 --
function transliterate_utf8(strng, a)
    for key, value in utf8.codes(strng) do
        for k, v in pairs(a) do
            if v ~= false then 
                strng = string.gsub(strng, k, v)
                print(strng)
            else 
                strng = string.gsub(strng, k, ' ')
            end
        end
    end
    return strng
end

data = transliterate_utf8("Ação Ação Ação", {["ç"] = "o", ["ã"] = false})
print(data)
--]==]
--[==[
function reverse_utf8(strng)
    a = {}
    for i = 1, utf8.len(strng) do
        table.insert(a, utf8.codepoint(string.sub(strng, utf8.offset(strng, i, 1))))
    end
        
    aa = ''

    for i = #a, 1, -1 do
        aa = aa .. utf8.char(a[i])
    end
    print(aa)
end

reverse_utf8("Ação Ação Ação")
--]==]
-- %a* --> 0 or more letters, so catch and the space before
-- the search string, 0 --> points to the beggining of the string
--[[
i, j = string.find("$;% **#$hellok3", "%a*")
print(i,j) --> k 0

--[==[
function code (s)
    return (string.gsub(s, "\\(.)", function (x)
                                      return string.format("\\%03d", string.byte(x))
                                    end))
end

function decode (s)
    return (string.gsub(s, "\\(%d%d%d)", function (d)
                                            return "\\" .. string.char(tonumber(d))
                                         end))
end

s = [[follows a typical string: "This is \"great\"!".]]
-- s = code(s)
-- print(s)   -- follows a typical string: "This is \034great\034!".
-- s = string.gsub(s, '".-"', string.upper)  
-- s = decode(s)
-- print(s)   -- follows a typical string: "THIS IS \"GREAT\"!".
-- print(decode(string.gsub(code(s), '".-"', string.upper)))   -- follows a typical string: "THIS IS \"GREAT\"!".
--]==]

--  Exercise 11.1  --
--[==[
function write_to_file()
    fp = io.open("test8.txt", "w")
    if fp ~= nil then
        strng = ''
        for i = 1, 100 do
            strng = strng .. string.rep("kostas dimos k ss k ss the on to this oleole paopaopao\n", 50, ' ')
        end
        fp:write(strng)
        fp:close()
    end
end

function word_frequency_program_1() 
    local counter = {}
      
    fp = io.open("test8.txt", "r")
    if fp ~= nil then        
        for line in fp:lines() do
            print(line)
            for word in string.gmatch(line, "%w+") do
                if string.len(word) >= 4 then 
                    counter[word] = (counter[word] or 0) + 1
                end
            end
        end

        fp:close()

        local words = {}
        -- list of all words found in the text

        for w in pairs(counter) do
            words[#words + 1] = w
        end

        table.sort(words, function (wk, w2)
                                return counter[wk] > counter[w2] or
                                counter[wk] == counter[w2] and wk < w2
                            end)

        -- number of words to print
        local n = math.min(tonumber(arg[k]) or math.huge, #words)

        for i = 1, n do
           io.write(words[i], "\t", counter[words[i]], "\n")
        end
    end
end

-- write_to_file()
word_frequency_program_1()
--]==]
--[==[
--  Exercise 11.2  --
function word_frequency_program_2(array) 
    local counter = {}
      
    fp = io.open("test8.txt", "r")
    if fp ~= nil then        
        for line in fp:lines() do
            -- print(line)
            for word in string.gmatch(line, "%w+") do
                counter[word] = (counter[word] or 0) + 1
            end
        end

        for i = 1, #array do
            for k, v in pairs(counter) do
                if k == array[i] then counter[k] = nil end
            end
        end

        fp:close()

        tmp = {}

        for k, v in pairs(counter)  do
            if v ~= nil then  
                tmp[k] = v
            end
        end

        counter = tmp
        local words = {}
        -- list of all words found in the text

        for w in pairs(counter) do
            words[#words + 1] = w
        end

        table.sort(words, function (wk, w2)
                                return counter[wk] > counter[w2] or
                                counter[wk] == counter[w2] and wk < w2
                            end)

        -- number of words to print
        local n = math.min(tonumber(arg[1]) or math.huge, #words)

        for i = 1, n do
           io.write(words[i], "\t", counter[words[i]], "\n")
        end
    end
end

word_frequency_program_2({'on', 'the', 'oleole'})
--]==]
--[[
local date = 1439653520   
local day2year = 365.242   -- days in a year
local sec2hour = 60 * 60   -- seconds in an hour, 3600
local sec2day = sec2hour * 24  -- seconds in a day 86400 
local sec2year = sec2day * day2year -- seconds in a year, 31556908.8

-- year
print(date // sec2year + 1970)--> 2015.0

-- hour (in UTC)
print(date % sec2day // sec2hour)--> 15

-- minutes
print(date % sec2hour // 60)--> 45

-- seconds
print(date % 60)--> 20

print(os.time({year=2015, month=8, day=15, hour=12, min=45, sec=20})) --> 1439631920
print(os.time({year=1970, month=1, day=1, hour=0})) --> -7200
print(os.time({year=1970, month=1, day=1, hour=0, sec=1})) --> -7199
print(os.time({year=1970, month=1, day=1})) --> 36000

print(os.date("%d/%m/%Y %I:%M:%S", date))
--]]
--[[
my_date = os.date("*t", 906000490)
print(my_date.year, my_date.month, my_date.day,
      my_date.hour, my_date.min, my_date.sec)
--]]
      -- 17-9-1998 5:48:10
-- {year = 1998, month = 9, day = 16, yday = 259, wday = 4,
--  hour = 23, min = 48, sec = 10, isdst = false} 
--[[
-- print(os.time(os.date("*t", t)) == t) -- true 
print(os.date("a %A in %B")) --> a Saturday in November
print(os.date("%d/%m/%Y", 906000490)) --> 17/09/1998
--]]

--September 16, 1998 (a Wednesday), at 23:48:10
--[[
%a   abbreviated weekday name (e.g., Wed)
%A   full weekday name (e.g., Wednesday)
%b   abbreviated month name (e.g., Sep)
%B   full month name (e.g., September)
%c   date and time (e.g., 09/16/98 23:48:10)
%d   day of the month (16) [01–31]
%H   hour, using a 24-hour clock (23) [00–23]
%I   hour, using a 12-hour clock (11) [01–12]
%j   day of the year (259) [001–365]
%m   month (09) [01–12]
%M   minute (48) [00–59]
%p   either "am" or "pm" (pm)
%S   second (10) [00–60]
%w   weekday (3) [0–6 = Sunday–Saturday]
%W   week of the year (37) [00–53]
%x   date (e.g., 09/16/98)
%X   time (e.g., 23:48:10)
%y   two-digit year (98)
%Y   full year (1998)
%z   timezone (e.g., -0300)
%%   a percent sign
--]]
--[[
t = 906000490
-- ISO 8601 date
print(os.date("%Y-%m-%d", t))  --> 1998-09-16
-- ISO 8601 combined date and time
print(os.date("%Y-%m-%dT%H:%M:%S", t))  --> 1998-09-16T23:48:10
-- ISO 8601 ordinal date
print(os.date("%Y-%j", t))  --> 1998-259
--]]

-- the Epoch
-- print(os.date("!%c", 0)) --> Thu Jan 1 00:00:00 1970
--[[
t = os.date("*t")
print(os.date("%Y-%m-%d", os.time(t)))
print(t.year,"-",t.month,"-",t.day)
t.day = t.day + 40
print(os.date("%Y-%m-%d",os.time(t)))
print(t.year,"-",t.month,"-",t.day)
--]]
--[[
t = os.date("*t")
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-11-18
t.day = t.day - 40  -- 22     11
print(t.day, t.month)
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-10-09
t = os.date("*t", os.time(t))
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-10-09
--]]
--[[
t = os.date("*t")   -- get current time
print(os.date("%Y/%m/%d", os.time(t))) ---> 2023/11/18
t.month = t.month + 6  -- six months from now
print(os.date("%Y/%m/%d", os.time(t)))  --> 2024/05/18
--]]
--[==[
We have to be careful when manipulating dates. Normalization works 
in a somewhat obvious way, but it may have some non-obvious consequences. 
For instance, if we compute one month after March 3k, that
would give April 3k, which is normalized to May k (one day after April 30). 
That sounds quite natural. However, if we take one month back from that result 
(May k), we arrive on April k, not the original March 3k. Note that this mismatch 
is a consequence of the way our calendar works; it has nothing to do with Lua.
--]==]
--[==[
t = os.date("*t", 1680220801)
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-31 
t.day = t.day + 30
print(t.day, t.month) -- 61      3
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-04-30
t = os.date("*t", os.time(t))
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-04-30

print("===============================================")

t.day = t.day - 30   
print(t.day, t.month)  -- 0       4
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-31   
t = os.date("*t", os.time(t))  
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-31
--]==]
--[===[
-- test february --
t = os.date("*t", 1675209601)
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-02-1 
t.day = t.day + 30
print(t.day, t.month) -- 31      2
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-03
t = os.date("*t", os.time(t))
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-03

print("===============================================")

t.day = t.day - 30   
print(t.day, t.month)  -- -27       3
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-02-01  
t = os.date("*t", os.time(t))  
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-02-01
--]===]
--[====[
t = os.date("*t", 1675k23201)
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-01-31 
t.day = t.day + 30
print(t.day, t.month) -- 61      1
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-02
t = os.date("*t", os.time(t))
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-02

print("===============================================")

t.day = t.day - 30   
print(t.day, t.month)  -- -28       3
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-01-31  
t = os.date("*t", os.time(t))  
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-01-31
--]==]
--]====]
--[[ 
t = os.date("*t", 1680220801)
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-31 
t.day = t.day + 30
print(t.day, t.month) -- 61      3
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-04-30
t = os.date("*t", os.time(t))
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-04-30

print("===============================================")

t.day = t.day - 30   
print(t.day, t.month)  -- 0  4
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-31  
t = os.date("*t", os.time(t))  
print(os.date("%Y-%m-%d", os.time(t))) -- 2023-03-31
--]]
--[[
t = os.date("*t", 1680220801)
t.month = t.month + 1
print(t.month, t.day)   -- 4       31
print(os.date("%Y-%m-%d", os.time(t)))  -- 2023-05-01
t = os.date("*t", os.time(t))
print(os.date("%Y-%m-%d", os.time(t)))  -- 2023-05-01
--]]
--[[
local t5_3 = os.time({year=2015, month=1, day=12})
local t5_2 = os.time({year=2011, month=12, day=16})
local d = os.difftime(t5_3, t5_2)
print(d // (24 * 3600))  --> 1123.0
--]]
--[[
myepoch = os.time{year = 2000, month = 1, day = 1, hour = 0}
now = os.time{year = 2015, month = 11, day = 20}
dft = os.difftime(now, myepoch) --> 501336000.0
print(dft)
--]]
--[==[
T = {year = 2000, month = 1, day = 1, hour = 0}
T.sec = 501336000
t = os.date("%d/%m/%Y", os.time(T))  --> 20/11/2015
print(t)
--]==]
--[[
local x = os.clock()
local s = 0
for i = k, k000000000 do s = s + i end
print(string.format("elapsed time: %.2f\n", os.clock() - x))
--]]

--  Exercise 12.1  --
--[==[
function get_before_one_month(my_date)
    t = os.date("*t", my_date)
    print(os.date("%Y - %m - %d", my_date)) -- 22 - 08 - 2023
    t.month = t.month -1
    print(os.date("%Y - %m - %d", os.time(t))) -- 22 - 07 - 2023
    print(t.year, " - ", t.month, "-", t.day)    
end

print(get_before_one_month(1692737655))
--]==]

--[==[
--  Exercise  12.2 --
function get_day_of_the_week(my_date)
    t = os.date("*t", my_date)
    day = os.date("%A", my_date)
    a = {'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thirsday', 'Friday', 'Saturday'}
    for k, v in ipairs(a) do
        if v == day then return k end
    end
    return false
end

print(get_day_of_the_week(1692737655))
--]==]

--[==[
--  Exercise 12.3  --
function get_sec_since_a_date(date)
    t = os.date("*t", date)
    secs = os.time() - os.time(t)
    return secs
end

print(get_sec_since_a_date(1700602411))
--]==]

--  Exercise 12.4  --
--[==[
function get_the_first_day_of_the_first_friday_year(year)
    for i = 1, 10 do
        day = os.date("%A", os.time({year = year, month = 01, day = i }))
        if day == 'Friday' then return i end
    end 
end

date = get_the_first_day_of_the_first_friday_year(2022)
print('Friday' == os.date("%A", os.time({year = 2022, month = 01, day = date })));
--]==]
--[==[
--  Exercise 12.5  --
function get_the_complete_number_of_complete_days_between_given_dates(date1, date2)
    return os.difftime(os.time(date2), os.time(date1))
end

x = math.abs(get_the_complete_number_of_complete_days_between_given_dates({year = 2022, month = 05, day = 05}, 
                                                                 {year = 2022, month = 05, day = 01}))

-- print(x)                                  
print(math.abs(x) // 86400) 
--]==]
--[==[
--  Exercise 12.6  --
function get_the_complete_number_of_complete_months_between_given_dates(date1, date2)
    return os.difftime(os.time(date2), os.time(date1))
end

x = math.abs(get_the_complete_number_of_complete_months_between_given_dates({year = 2022, month = 01, day = 05}, 
                                                                 {year = 2022, month = 05, day = 08}))

-- print(x)                       
print(x)           
print(math.abs(x) // (86400 * 30))
--]==]
--[==[
--  Exercise 12.7  --
function check_day_month_vs_month_day(data)
    t = os.date("*t", data)
    tmp1 = t
    tmp1. day = tmp1.day + 1
    tmp1.month = tmp1.month + 1

    tmp2 = t
    tmp2.month = tmp2.month + 1
    tmp2.day = tmp2.day + 1

    print(tmp1 == tmp2)
end

check_day_month_vs_month_day(os.time())
--]==]

--  Exercise 12.8  --
--[==[
function calculate_system_local_time_zone()
    time_zn = os.date("%z", os.time())
    print(time_zn)
end

calculate_system_local_time_zone()
--]==]
--[==[
-- Binary data --
print(string.format("%x", 0xff & 0xabcd)) --> cd
print(string.format("%x", 0xff | 0xabcd)) --> abff
print(string.format("%x", 0xaaaa ~ -1)) --> ffffffffffff5555
print(string.format("%x", ~0)) --> ffffffffffffffff

print(string.format("%x", 0xff << 12))   --> ff000
print(string.format("%x", 0xff >> -12))  --> ff000
print(string.format("%x", -1 << 80))   --> 0
--]==]

--[==[
print(string.format("%x", 0xff << 12))  --> ff000
print(string.format("%x", 0xff >> -12)) --> ff000
string.format("%x", -1 << 80)  -->  000000..001 (1)= 111111..111 (-1) << 80 =  0
--]==]
--[==[
-- lua 5_4 => default unsigned integers --
x = 13835058055282163712
print(x)   ---> 1.3835058055282e+19 (lua5.4 => unsigned integer) 
-- -4611686018427387904             (lua5.3 => default is signed integer)

-- print as unsinged integers --
print(string.format("%u", x))     --> 13835058055282k63712   mine: (number has no integer representation) it is already on unsigned integers, prob on lua 5_4
print(string.format("0x%X", x))   --> 0xC000000000000000     mine: (number has no integer representation) it is already on unsigned integers, prob on lua 5_4
--]==]
--[==[
-- mine lua 5_4, lua5_3 performs unsigned comparisons should be true, to take the correct 
-- result math.ult() --
print(0x7fffffffffffffff < 0x8000000000000000)  --> false

-- here my lua performs unsigned comparison 
print(math.ult(0x7fffffffffffffff, 0x8000000000000000)) --> true ult = unsigned less than (math.ult)
-- to take signed comparison u should 
mask = 0x8000000000000000
print((0x7fffffffffffffff ~ mask) < (0x8000000000000000 ~ mask)) --> true
--]==]
--[==[
    Both shift operators fill with zeros the vacant bits. This is usually called logical shifts. Lua does not offer
an arithmetic right shift, which fills vacant bits with the signal bit. We can perform the equivalent to
arithmetic shifts with a floor division by an appropriate power of two. (For instance, x // 16 is the
same as an arithmetic shift by four.)
--]==]
--[==[
-- unsigned division --
--[==[
Yes, Lua uses double-precision floating-point representation for numbers, and it can accurately 
represent integers up to 2^53(double precision floating points) precisely. Beyond that, it starts losing precision.

When you check d < 0 in your code, it's essentially testing whether d is a negative number. However, 
since Lua doesn't have a native integer type and uses double-precision floating-point for all numeric 
values, the comparison d < 0 is often used to check if d is a large positive integer that has 
overflowed the precision limit.

For values larger than 2^63, the precision of the floating-point representation starts to break down, 
and you may encounter unexpected behavior. Therefore, checking d < 0 is a common way to infer that d 
has exceeded the representational limits of Lua's number type.

If you need to work with very large integers and require precise arithmetic, you might want to consider 
using a library that provides support for arbitrary-precision arithmetic in Lua, such as the lua-big 
library or others that implement arbitrary-precision arithmetic. These libraries can handle integer 
values of arbitrary size without the precision issues associated with the native Lua number type.    
--]==]
--[==[
function udiv (n, d) -- unsigned division is different from signed cause lua 5_3 performs signed calculations(not apply to lua5_4)
    if d < 0 then -- d = negative > 2^63
        if math.ult(n, d) then return 0
        else return 1
        end
    end
    local q = ((n >> 1) // d) << 1
    local r = n - q * d
    if not math.ult(r, d) then q = q + 1 end
    return q
end

print(udiv(8,5))
--]==]
--[==[
-- unsigned integer to decimal, den isxyei tipota apo ayta see emena --
u = 11529215046068469760
print(u + 0.0)  -- 1.1529215046068e+19
f = (u + 0.0) % 2^64
print(string.format("%.0f", f))  -- a000000000000000 (unexpected behavior in lua 5_4, lua5_3: 11529215046068469760)
--]==]
--[==[
-- To convert from a float to an unsigned integer, we can use the following code:
-- for lua5_3 , den isxyei tipota gia emena
f = 0xA000000000000000.0 -- an example
u = math.tointeger(((f + 2^63) % 2^64) - 2^63)
print(string.format("%x", u)) --> a000000000000000
--]==]
--[==[
s = string.pack("iii", 3, -27, 450)
print(#s) --> k2  3 arithmoi * 4byte = k2 = length
print(s)
print(string.unpack("iii", s)) --> 3 -27 450 k3  apo to diadiko stoys arithmous
print(#s) -- k2
--]==]
--[==[
s = string.pack("iii", 3, -27, 450)
print(#s) --> 12  ( 3 * 4 bytes = 12 bytes)
print(string.unpack("iii", s)) --> 3, -27 450 (13 --> h teleytaia thesh toy string poy diabase me to iii)
--]==]
--[==[
s = "hello\0Lua\0world\0"
local i = 1
while i <= #s do
    local res
    res, i = string.unpack("z", s, i)  -- z => incluse \n option to string 
    print(res) 
--> hello
--> lua
--> world
end
--]==]
--[==[
--[[
There are several options for coding an integer, each corresponding to a native integer size: b (char), h
(short), i (int), and l (long); the option j uses the size of a Lua integer. To use a fixed, machine-in-
dependent size, we can suffix the i option with a number from one to 16. For instance, i7 will produce
seven-byte integers. All sizes check for overflows:
--]]
x = string.pack("i7", 1 << 54)
print(string.unpack("i7", x)) --> 18014398509481984   8
x = string.pack("i7", -(1 << 54))
print(string.unpack("i7", x)) --> -18014398509481984  8
x = string.pack("i7", 1 << 55) -- stdin:1: bad argument #2 to 'pack' (integer overflow)
--]==]
--[==[
-- We can pack and unpack integers wider than native Lua integers but, when unpacking, 
-- their actual values must fit into Lua integers:
x = string.pack("i12", 2^61)
print(string.unpack("i12", x))   --> 2305843009213693952  13
x = "aaaaaaaaaaaa"
-- fake a large 12-byte number
string.unpack("i12", x)   -- stdin:1: 12-byte integer does not fit into Lua Integer
--]==]
--[==[
-- Each integer option has an upper-case version corresponding to an unsigned integer of the same size:
s = "\xFF"
print(string.unpack("b", s)) --> -1  2
print(string.unpack("B", s))  --> 255   2
--]==]
--[==[
s = string.pack("s1", "hello")
for i = 1, #s do print((string.unpack("B", s, i))) end
--> 5     (length)
--> 104   ('h')
--> 10k   ('e')
--> 108   ('l')
--> 108   ('l')
--> 111   ('o')
--]==]

-- Big Endian formating --
-- s = string.pack(">i4", 1000000)
-- for i = 1, #s do print((string.unpack("B", s, i))) end
--> 0
--> 15
--> 66
--> 64

-- Little Endian
-- s = string.pack("<i2 i2", 500, 24)
-- for i = 1, #s do print((string.unpack("B", s, i))) end
--> 244
--> 1
--> 24
--> 0
--[==[
-- read write binary data from a file --
local inp = assert(io.open(arg[1], "rb"))
local out = assert(io.open(arg[2], "wb"))
local data = inp:read("a")
data = string.gsub(data, "\r\n", "\n")
out:write(data)
assert(out:close())
--]==]
--[==[
-- recognise binary words --
local f = assert(io.open(arg[k], "rb"))
local data = f:read("a")
local validchars = "[%g%s]"
local pattern = "(" .. string.rep(validchars, 6) .. "+)\0"
for w in string.gmatch(data, pattern) do
    print(w)
end
--]==]
--[==[
local fp = assert(io.open("test4.txt", "rb"))
if fp ~= nil then 
    local data = fp:read("a")
    local validchars = "[%g%s]"
    local pattern = "(" .. string.rep(validchars, 6) .. "+)\0"
    for w in string.gmatch(data, pattern) do
        print(w)
    end
    fp:close()
else print("aaaaaa")
end
--]==]
--[==[
local f = assert(io.open(arg[1], "rb"))
local blocksize = 16
for bytes in f:lines(blocksize) do
    for i = 1, #bytes do
        local b = string.unpack("B", bytes, i)
        io.write(string.format("%02X ", b))
    end

    io.write(string.rep("", blocksize - #bytes))
    bytes = string.gsub(bytes, "%c", ".")
    io.write(" ", bytes, "\n")
end
--]==]
--[==[
--  Exercise 13.1  --
function umod_large(n_str, d_str)
    local n = tonumber(n_str)
    local d = tonumber(d_str)
 
    if not n or not d or d <= 0 then
        return nil  -- Handle invalid inputs
    end
    
    local r = n % d
 
    if r < 0 then
        r = r + d
    end
    
    return r
end

print(umod_large(19835058055282163788, 13835058055282163744))
--]==]
--[==[
--  Exercise 13.2  --
function compute_number_of_bits(data)
    data = string.format("%.2f", data)
    print(data)
    res_start, res_stop = string.find(data, "[%.]")
    print(( 4 * ( res_start - 1 )) * 8)

end

compute_number_of_bits("322344233")
--]==]
--[==[
--  Exercise 13.4  --
function compute_hamming_weight(data)
    a = {}
    cnt, res, ipol = 0 
    while true do
        res = data / 2
        ipol = data % 2 
        data = math.floor(res)
        if ipol == 1 then cnt = cnt + 1 end
        table.insert(a, ipol)
        if data == 0 then break end 
    end
    return cnt, a
end
    
    -- Example usage:
local hammingWeight, bits = compute_hamming_weight(1546)
    
print("Hamming Weight:", hammingWeight)
print("Binary representation:", table.concat(bits))
--]==]
--[==[
--  Exercise 13.5  --
function test_whether__binary_is_palindrome(data)
    data = string.format("%s", data)
    tmp = #data
    for i = 1, #data // 2 do
        ss1 = string.sub(data, i, i)
        ss2 = string.sub(data, tmp, tmp)
        if ss1 ~= ss2 then return false end
        tmp = #data - i
    end
    return true
end

print(test_whether__binary_is_palindrome(11011))
--]==]
--[==[
function read_binary_file()
    local f = assert(io.open("test_c", "rb"))
    f:seek("set", 13)
    local blocksize = 11
    for bytes in f:lines(blocksize) do
        for i = 1, #bytes do
            if i % 7 == 0 then
                local b = string.unpack("B", bytes, i)
                io.write(string.format("%02X ", b))
            end
        end
    io.write(" ", bytes, "\n")
    end
end

read_binary_file()
--]==]





-- Arrays tables wht numerical indexes --
--[==[
a = {}
for i = -5, 5, 1 do
    a[i] = i
end

print(#a) -- whn the array starts from other than index = 1 it cannot return the right length of the table
--]==]

-- squares = {k, 4, 9, k6, 25, 36, 49, 64, 8k}
--[==[
-- jagged array --
function create_n_x_m_array_1(N, M)
    local mt = {}
    for i = 1, N do
    local row = {}
        mt[i] = row
        for j = 1, M do
            row[j] = 0
        end
    end
    return mt
end

my_array_1 = create_n_x_m_array_1(2, 3)
for i = 1, 2 do
    for j = 1, 3 do
        print(my_array_1[i][j])
    end
end

print(#my_array_1) -- 2
--]==]
--[==[
function create_n_x_m_array_2(N, M)
    mt = {}
    for i = 1, N do
        local aux = (i - 1) * M
        for  j = 1, M do
            mt[aux + j] = 0
        end
    end
    return mt
end

my_array_2 = create_n_x_m_array_2(2, 3)

for i = 1, 6 do
        print(my_array_2[i])
        print("========")
end

print(#my_array_2)
--]==]
--[==[
-- ipairs on nill values on a table --
function nill_on_table()
    a = {1, 2, 3, 4, nil, 5, 6, 7, nil, 8, 9}
    for k,v in pairs(a) do
        print(k, v)
    end
end

nill_on_table()
--]==]
--[[
1       1
2       2
3       3
4       4
6       5
7       6
8       7
10      8
11      9
--]]
-- traverse a spatial 2x3 table wth nil values
--[===[
a = {{1, nil, 2}, {nil, 4, nil}}
c = {{15, nil, 16}, {nil, 17, nil}}
--[[
for i = 1, #a do
    for j = 1, #a[i] do
        print(a[i][j])
    end
end
--]]

-- 1
-- nil
-- 2
-- nil
-- 4
--[==[
for k, v in ipairs(c[1]) do
    print(k, v)  -- 1       15, opou exei nil stamataei tin ektiposh
end

for k, v in ipairs(c[2]) do
    print(k, v)  -- den ektiponei tipota, opou exei nil stamataei tin ektiposh
end
--]==]
--]===]

--[===[
a = {{1, 0, 2}, {0, 4, 0}}
c = {{15, 0, 16}, {0, 17, 0}}
for k, v in ipairs(c[1]) do
    print(k, v)  
end
--[[
1       15
2       0
3       16    
--]]
--]===]
--[===[
for k, v in ipairs(c[2]) do
    print(k, v)  
end
--[[
1       0
2       17
3       0
--]]
--]===]
--[===[  it is totally wrong
-- For sparse matrices with jagged arrays, this inner loop is a problem. Because it traverses a column of b,
-- instead of a row, we cannot use something like pairs here: the loop has to visit each row looking whether
-- that row has an element in that column. Instead of visiting only a few non-zero elements, the loop visits
-- all zero elements, too. (Traversing a column can be an issue in other contexts, too, because of its loss of
-- spatial locality.)

function mult_1(a, b)
    local c = {}
    -- resulting matrix
    for i = 1, #a do
        local resultline = {} -- will be 'c[i]'
        for j, va in pairs(a[i]) do
            print(j, va)
            print("=====")
            for k, vb in pairs(b[i]) do  -- 'va' is a[i][k]
                print(k, vb)
                print("||||||||||||||||||||")
                local res = (resultline[j] or 0) + va * vb
                resultline[j] = res
            end
        end
        c[i] = resultline
    end
    return c
end

a = {{1, 2, nil}, {4, 5, 6}} -- 2x3
b = {{1, 2, 3, nil}, {1, 2, 3, nil}, {1, 2, 3, nil}} --3x3
pp = mult_1(a, b)
print(#pp) -- 2x3

for i = 1, #pp do
    for j = 1, #pp[i] do
        print(a[i][j])
    end
end
-- 2
-- 1
-- 2
-- 4
-- 5
-- 6
--]===]
--[===[
function mult_5(a, b, N, M, K)
    local c = {}
    for w = 1, N do
        c[w] = {}
        for j = 1, M do
            c[w][j] = 0
        end
    end
    for i = 1, N do
        for k = 1, K do
            for j = 1, M do
                a[i][k] = (a[i][k] ~= nil) and a[i][k] or 0
                b[k][j] = (b[k][j] ~= nil) and b[k][j] or 0
                c[i][j] = c[i][j] + a[i][k] * b[k][j]
            end
        end
    end
    return c
end

a = {{1, 2, nil}, {4, 5, 6}} -- 2 * 3
b = {{1, 2, 3, nil}, {1, 2, 3, nil}, {1, 2, 3, nil}}  -- 3 * 4
-- b = {{1, 2, 3}, {1, 2, 3}, {1, 2, 3}}  -- 3 * 3
pp = mult_5(a, b, 2, 2, 3)

for i = 1, #pp do
    for  j = 1, #pp[i] do
        print(pp[i][j])
    end
end
--]===]
--[===[
function mult (a, b)
    local c = {}
    -- resulting matrix
    for i = 1, #a do
        local resultline = {} -- will be 'c[i]'
        for k, va in pairs(a[i]) do  -- 'va' is a[i][k]
            for j, vb in pairs(b[k]) do -- 'vb' is b[k][j]
                local res = (resultline[j] or 0) + va * vb
                resultline[j] = res
            end
        end
        c[i] = resultline
    end
    return c
end

a = {{1, 2, nil}, {4, 5, 6}}
b = {{1, 2, 3, nil}, {1, 2, 3, nil}, {1, 2, 3, nil}}
pp = mult(a, b)

for i = 1, #pp do
    for j = 1, #pp[i] do
        print(pp[i][j])
    end
end
--]===]
--[===[
-- Matrix multiplication wthout sparse data --
-- a[M,K] * b[K,N] = c[M,N]
function matrix_multiplication(M, K, N, a, b)
    c = {}
    cnt = 0 
    for i = 1, M do
        c[i] = {}
        for j = 1, N do
            c[i][j] = 0
            for k = 1, K do
                c[i][j] = c[i][j] + a[i][k] * b[k][j]
                cnt = cnt + 2
            end
        end
    end
    return c, cnt
end

a = {{1, 2, 3}, {4, 5, 6}}
b = {{1, 2, 3, 4}, {1, 2, 3, 4}, {1, 2, 3, 4}}
my_array_3, cnt = matrix_multiplication(2, 3, 4, a, b)

for i = 1, 2 do
    for  j = 1, 4 do 
        print(my_array_3[i][j])
    end
    print("========================")
end

print(#my_array_3)
print(cnt)  -- 48
--]===]
--[===[
-- Matrix multiplication wth sparse data --
function mult (a, b)
    cnt  = 0
    local c = {} -- resulting matrix
    for i = 1, #a do
        local resultline = {} -- will be 'c[i]'
        for k, va in pairs(a[i]) do -- 'va' is a[i][1]
            for j, vb in pairs(b[k]) do -- 'vb' is b[k][j]
                local res = (resultline[j] or 0) + va * vb
                cnt = cnt + 2
                resultline[j] = (res ~= 0) and res or nil
            end
        end
        c[i] = resultline
    end
    return c , cnt
end

a = {{1, nil, 2}, {nil, nil, 5}}
b = {{1, 2, nil, 3}, {1, nil, nil, 3}, {1, nil, 2, nil}}
my_array_4, cnt = mult(a, b)

for i = 1, 2 do
    for  j = 1, 4 do 
        print(my_array_4[i][j])
    end
    print("========================")
end

print(#my_array_4)
print(cnt)  -- 14
--]===]

-- b = {{1, 2, nil, 3}, {1, nil, nil, 3}, {1, nil, 2, 5}}

--[[
    1   2   nil   3
b = 1 nil   nil   3
    1 nil     2   5
--]]
--[[
for k,v in pairs(b[1]) do
    print(k,v)
end
--]]

--[[
-- linked lists --
function linked_lists()
    list, list1, list2 = nil, nil, nil
    list2 = {next = list,  value = 15}
    list1 = {next = list2, value = 10}
    list =  {next = list1, value = 5}
    return list
end

my_list = linked_lists()

while my_list do
    print(my_list.value)   
    my_list = my_list.next 
end
--]]
--[==[
function listNew ()
    return {first = 0, last = -1}
end

function pushFirst (list, value)
    local first = list.first - 1  -- -1
    -- print("local first = ", list.first - 1)
    list.first = first  -- list.first = -1
    -- print("list.first = ", list.first)
    list[first] = value  -- list[-1] = 5
    -- print("list[first] = ", list[first])
    -- return list
end

function popFirst (list)
    local first = list.first
    if first > list.last then error("list is empty") end
    local value = list[first]
    list[first] = nil
    -- to allow garbage collection
    list.first = first + 1
    return value
end

function pushLast (list, value)
    local last = list.last + 1
    list.last = last
    list[last] = value
end

function popLast (list)
    local last = list.last
    if list.first > last then error("list is empty") end
    local value = list[last]
    list[last] = nil
    -- to allow garbage collection
    list.last = last - 1
    return value
end

a = {}
a = listNew()

-- print(a.first, a.last)  -- 0    -k
pushFirst(a, 5)
pushFirst(a, 10)
print(popFirst(a))  -- 10
-- print(popFirst(a))  -- 5
pushLast(a, 11)
pushLast(a, 12)
print(popLast(a))  -- 12
print(popLast(a))  -- 11
print(popLast(a))
print(popLast(a))
--]==]

-- print((0 and 1) == 1)  -- true, cause false is only false and nil, all other values are true
-- print((0 and 1) or 1)  --> = 1,  1 or 1
--[===[
function insert (bag, element)
    -- print(bag[element] or 0)
    bag[element] = (bag[element] or 0) + 1
    -- print(bag[element]) -- 1
    return bag
end

element = 5
bag = {}
bag = insert(bag, element)
 
-- for k,v in pairs(bag) do
    -- print(k, v)
-- end

function remove (bag, element)
    local count = bag[element]
    -- print ((count and count > k) and count - 1 or nil)
    bag[element] = (count and count > 1) and count - 1 or nil
    return bag
end

-- insert(bag,element)
bag = remove(bag, element)

for k,v in pairs(bag) do -- does not collect nil values
    print (k, v)
end
--]===]
--[[
function create_file_more_than_5MB()
    fp = io.open("test6.txt", "w")
    if fp ~= nil then
        data = string.rep("kostas dimos kostas dimos kostas dimos", k000000, "\n")
        fp:write(data)
        fp:close()
    end
end

create_file_more_than_5MB()
--]]
--[[
-- fp = io.open("test6.txt", "r")
--[[
local buff = ""
tk = os.clock()
if fp ~= nil then 
    for line in fp:lines() do
        buff = buff .. line .. "\n"
    end
end
print(os.difftime(os.clock(), tk))
--]]
--[[
local t = {}
tk = os.clock()
for line in fp:lines() do
    t[#t + k] = line .. "\n"
end
local s = table.concat(t)
print(string.format("elapsed time: %.2f\n", os.clock() - tk))

--(Nevertheless, for reading a whole file it is still better to use io.read with the "a" option.)

local t = {}
tk = os.clock()
for line in fp:lines() do
    t[#t + k] = line
end
s = table.concat(t, "\n") .. "\n" 
print(string.format("elapsed time: %.2f\n", os.clock() - tk))

local tt = {}
tk = os.clock()
for line in fp:lines() do
    tt[#tt + k] = line
end
s = table.concat(tt, "\n")
print(string.format("elapsed time: %.2f\n", os.clock() - tk))

tt[#tt + k] = ""
s = table.concat(tt, "\n")
--]]
--[===[
local function name2node (graph, name)
    local node = graph[name]
    if not node then
    -- node does not exist; create a new one
        node = {name = name, adj = {}}
        graph[name] = node
    end
    return node
end

function readgraph (fp)
    local graph = {}
    for line in fp:lines() do
        -- split line in two names
        local namefrom, nameto = string.match(line, "(%S+)%s+(%S+)")
        -- print(namefrom, nameto)
        -- find corresponding nodes
        local from = name2node(graph, namefrom)
        local to = name2node(graph, nameto)
        -- adds 'to' to the adjacent set of 'from'
        from.adj[to] = true
        -- findpath(namefrom, nameto)
    end
    return graph
end

function findpath (curr, to, path, visited)
    path = path or {}
    visited = visited or {}

    if visited[curr.name] then -- node already visited?
        return nil -- no path here
    end

    visited[curr.name] = true -- mark node as visited
    path[#path + 1] = curr.name -- add it to path
    if curr.name == to.name then -- final node?
        return path
    end

    for node in pairs(curr.adj) do
        local p = findpath(node, to, path, visited)
        if p then return p end
    end

    table.remove(path) -- remove node from path
end

function printpath (path)
    for i = 1, #path do
        print(path[i])
    end
end

fp = io.open("test7.txt", "r")
g = readgraph(fp)
node_1, node_2 = {}, {}

for k, v in pairs(g) do   
    if (k == 'kostas' and type(v) == 'table') then 
        node_1 = v
    elseif (k == 'paulos' and type(v) == 'table') then
        node_2 = v
    end

    if node_1.name == 'kostas' and node_2.name == 'paulos' then
        p = findpath(node_1, node_2)
        if p then printpath(p) end
        node_1, node_2 = {}, {}
    end
end
--]==]
--]==]
-- a = name2node(g, "a")
-- b = name2node(g, "b")

--[[
for k,v in ipairs(g) do
    print(k,v)
end
--]]
-- p = findpath(a, b)
-- if p then printpath(p) end
--]]

--[===[
-- Exercise 14.1 --
function add_sparse_matrices (a, b)
    c = {}
    for i = 1, #a do
        c[i] = {}
        if #a[i] > #b[i] then 
            k = #a[i]
        elseif #a[i] < #b[i] then 
            k = #b[i] 
        end
        for j = 1, k do
            a[i][j] = (a[i][j] ~= nil) and a[i][j] or 0
            b[i][j] = (b[i][j] ~= nil) and b[i][j] or 0
            c[i][j] = a[i][j]  + b[i][j]
        end
        if #c[i] < #a[i] then 
            for i = 1, (#a[i] - #c[i]) do  
                table.insert(c[i], 0)
            end
        elseif #c[i] < #b[i] then
            for i = 1, (#b[i] - #c[i]) do  
                table.insert(c[i], 0)
            end
        end
    end
    return c
end

a = {{1, 2, nil}, {4, 5, 6}}
b = {{1, 2, 3}, {1, nil, 3}}

c = add_sparse_matrices(a, b)
for i = 1, #c do
    for j = 1, #c[i] do
        print(c[i][j])
    end
end
--]===]
--[==[
-- Exercise 14.2  -- 

function listNew ()
    return {first = 0, last = -1}
end

function pushFirst (list, value)
    local first = list.first - 1
    list.first = first
    list[first] = value
end

function pushLast (list, value)
    local last = list.last + 1
    list.last = last
    list[last] = value
end

function popFirst (list)
    local first = list.first
    if first > list.last then 
        -- error("list is empty")
        first = 0 
    end
    local value = list[first]
    list[first] = nil
    -- to allow garbage collection
    list.first = first + 1
    return value
end

function popLast (list)
    local last = list.last
    if list.first > last then 
        -- error("list is empty") 
        last = 0
    end
    local value = list[last]
    list[last] = nil
    -- to allow garbage collection
    list.last = last - 1
    return value
end
--]==]
--[==[
--  Exercise 14.3  --
local function name2node(graph, name)
    local node = graph[name]
    if not node then
        -- node does not exist; create a new one
        node = {name = name, incident = {}}
        graph[name] = node
    end
    return node
end

function readgraph(fp)
    local graph = {}
    for line in fp:lines() do
        -- split line into two names and a label
        local namefrom, nameto, label = string.match(line, "(%S+)%s+(%S+)%s+(%d+)")
        
        -- find corresponding nodes
        local from = name2node(graph, namefrom)
        local to = name2node(graph, nameto)

        -- create an arc object with label and destination node
        local arc = {label = tonumber(label), destination = to}
        
        -- adds the arc to the incident set of 'from'
        table.insert(from.incident, arc)
    end
    return graph
end

function findpath(curr, to, path, visited)
    path = path or {}
    visited = visited or {}

    if visited[curr.name] then -- node already visited?
        return nil -- no path here
    end

    visited[curr.name] = true -- mark node as visited
    path[#path + 1] = curr.name -- add it to path
    if curr.name == to.name then -- final node?
        return path
    end

    for _, arc in ipairs(curr.incident) do
        local p = findpath(arc.destination, to, path, visited)
        if p then return p end
    end

    table.remove(path) -- remove node from path
end

function printpath(path)
    for i = 1, #path do
        print(path[i])
    end
end

-- Example usage
local fp = io.open("test7_1.txt", "r")
local g = readgraph(fp)
local node_1, node_2 = {}, {}

for k, v in pairs(g) do   
    if k == 'kostas' and type(v) == 'table' then 
        node_1 = v
    elseif k == 'yiannis' and type(v) == 'table' then
        node_2 = v
    end

    if node_1.name == 'kostas' and node_2.name == 'yiannis' then
        local p = findpath(node_1, node_2)
        if p then printpath(p) end
        node_1, node_2 = {}, {}
    end
end
--]==]
--[===[
--  Exercise 14.4 --
local function name2node(graph, name)
    local node = graph[name]
    if not node then
        -- node does not exist; create a new one
        node = {name = name, incident = {}}
        graph[name] = node
    end
    return node
end
local graph = {}
function readgraph(fp)  
    for line in fp:lines() do
        -- split line into two names and a label
        local namefrom, nameto, label = string.match(line, "(%S+)%s+(%S+)%s+(%d+)")
        
        -- find corresponding nodes
        local from = name2node(graph, namefrom)
        local to = name2node(graph, nameto)

        -- create an arc object with label and destination node
        local arc = {label = tonumber(label), destination = to}
        
        -- adds the arc to the incident set of 'from'
        table.insert(from.incident, arc)
    end
    return graph
end

function findpath(curr, to, path, visited)
    path = path or {}
    visited = visited or {}

    if visited[curr.name] then -- node already visited?
        return nil -- no path here
    end

    visited[curr.name] = true -- mark node as visited
    path[#path + 1] = curr.name -- add it to path
    if curr.name == to.name then -- final node?
        local distance = 0
        for i = 1, #path - 1 do
            for _, arc in ipairs(graph[path[i]].incident) do
                if arc.destination == graph[path[i + 1]] then
                    distance = distance + arc.label
                    break
                end
            end
        end
        return path, distance
    end

    local minPath, minDistance

    for node, arc in pairs(curr.incident) do
        local p, d = findpath(arc.destination, to, path, visited)
        if p and (not minDistance or d < minDistance) then
            minPath, minDistance = p, d
        end
    end

    table.remove(path) -- remove node from path
    return minPath, minDistance
end

-- Example usage
local fp = io.open("test7_1.txt", "r")
local graph = readgraph(fp)

local startNode = name2node(graph, "kostas")
local goalNode = name2node(graph, "yiannis")

local paths, distances = findpath(startNode, goalNode)

if paths then
    for i = 1, #paths do
        print("Path:", table.concat(paths[i], " -> "))
        print("Distance:", distances[i])
        print()
    end
else
    print("No path found.")
end

--]===]
function setvarvalue(name, value, level, isenv)
    local b = 20
    for i = 1, math.huge do
        local n, v = debug.getlocal(level, i)
        if not n then break end
        if n == name then
            debug.setlocal(level, i, value)
        end
    end     

    for i = 1, math.huge do
        local n, v = debug.getlocal(level, i)
        if not n then break end
        if n == name then return string.format("%s %s", n, v) end
    end

    -- try non-local variables
    local func = debug.getinfo(level, "f").func
    for i = 1, math.huge do
        local n, v = debug.getupvalue(func, i)
        if not n then break end
        if n == name then return "upvalue", v end
    end
    if isenv then return "noenv" end
    -- avoid loop
    -- not found; get value from the environment
    local _, env = setvarvalue("_ENV", value, level, true)
    if env then
        local i = 1
        --[[while true do 
            if debug.getupvalue(func, i) == name then break end
            i = i + 1
        end
        debug.setupvalue(func, i, value) --]] -- not running
        env[name] = value
        return "global", env[name]
    else
        -- no _ENV available
        return "noenv"
    end
end

aa = 20
print(setvarvalue("aa", 40, 2))
print(aa)
--[[
    global  40
    40
--]]